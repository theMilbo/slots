/*!
	gameModule : expand v.2
	date   : 2017:04:15
*/
game.expand=true;
if(game.debug==true){console.info("expand.js LOADED");}
expand.prototype.data={
	reelPower:[],
	light:[],
	mask:[],
	timer:0,
	time:700,
	reels:0,
	updateWild:false,
};
expand.prototype.sound={
	base:{
		3:'sound_symbol_12',
		4:'sound_symbol_12',
		5:'sound_symbol_12',
	},
	feature:{
		2:'sound_symbol_12',	
		3:'sound_symbol_12',
		4:'sound_symbol_12',
		5:'sound_symbol_12',
	}
};
expand.prototype.ssddqq=-1;
/*--------------------------------------------------------------------------------------------*/ 
expand.prototype.init = function() {
console.log('expand init');
expand.stage = new PIXI.Container();
expand.stage.name = 'expandStage';
expand.stage.position.x = 0;
expand.stage.position.y = 0;
expand.stage.zIndex = 50;
game.stage.addChild(expand.stage);
//---------------------------
for(var i=0;i<5;i++){
	expand.data.light[i]=new PIXI.Sprite(game.texture['light']);
	expand.data.light[i].x=reels.position[i+1].x+reels.config.symbol.width/2-150/2;
	expand.data.light[i].y=reels.position[0].topY-32;
	expand.stage.addChild(expand.data.light[i]);
}
//---------------------------
for(var i=0;i<3;i++){
	expand.data.mask[i]=[];
	for(var e=0;e<4;e++){
		expand.data.mask[i][e] = new PIXI.Graphics();
		expand.data.mask[i][e].zIndex = 99;
		expand.data.mask[i][e].position.x = reels.position[e+2].x;
		if(i==0){
			expand.data.mask[i][e].position.y = reels.position[0].topY;
		}else if(i==1){
			expand.data.mask[i][e].position.y = reels.position[0].downY-reels.config.symbol.height*3;
		}else {
			expand.data.mask[i][e].position.y = reels.position[0].downY-reels.config.symbol.height;
		}
		expand.data.mask[i][e].beginFill(0x000000);
		expand.data.mask[i][e].alpha=0.5;
		expand.data.mask[i][e].drawRect(0, 0, reels.config.symbol.width,reels.config.symbol.height);
		expand.data.mask[i][e].visible=false;
		expand.stage.addChild(expand.data.mask[i][e]);
	}
}
}
/*--------------------------------------------------------------------------------------------*/ 
expand.prototype.render = function() {
//console.log(game.action+' render')
if(game.config.freeSpin!=this.ssddqq){
	if(game.config.freeSpin==false){
		reels.reSpinConfig.treggers[1]=[];
		reels.reSpinConfig.treggers[2]=[];
		reels.reSpinConfig.treggers[3]=[];
		reels.reSpinConfig.treggers[4]=[];
	}else{
		reels.reSpinConfig.treggers[1]=[2,3,4,5];
		reels.reSpinConfig.treggers[2]=[3,4,5];
		reels.reSpinConfig.treggers[3]=[4,5];
		reels.reSpinConfig.treggers[4]=[5];
	}
	this.ssddqq=game.config.freeSpin;
	console.log('ddd');
}
//-------------------------	
if(game.config.freeSpin==true){
	if(reels.winAnimationStatus=='playAll' && this.data.updateWild==false){
		this.data.updateWild=true;
		for(var i=0;i<freeSpin.data.xWin.length;i++){
			for(var s=0;s<reels.symbolsToAnimation.length;s++){
				if(
					freeSpin.data.xWin[i][0]==reels.symbolsToAnimation[s]['reel']
					&&
					freeSpin.data.xWin[i][1]==reels.symbolsToAnimation[s]['row']
					){
					reels.symbolsToAnimation[s]['symbol']="symbol_13_anim_"+freeSpin.data.xWin[i][2];
					var ss=new PIXI.extras.MovieClip(game.texture[reels.symbolsToAnimation[s]['symbol']]['animFrames']);
					reels.symbolsToAnimation[s].animFrames.textures=ss.textures;
				}
			}
		}
	}else if(this.data.updateWild==true && game.action=='spin'){
		this.data.updateWild=false;
	}
}
if(game.config['betInfo']['lines']!=expand.data.reels){
	if(expand.data.mask[0]!=undefined){
		expand.data.reels=game.config['betInfo']['lines'];
		if(game.config['betInfo']['lines']<40){
			expand.data.mask[0][3].visible=true;
			expand.data.mask[1][3].visible=true;
			expand.data.mask[2][3].visible=true;
			expand.data.light[4].visible=false;
		}else{
			expand.data.mask[0][3].visible=false;
			expand.data.mask[1][3].visible=false;
			expand.data.mask[2][3].visible=false;
			expand.data.light[4].visible=true;
		}
		if(game.config['betInfo']['lines']<20){
			expand.data.mask[0][2].visible=true;
			expand.data.mask[1][2].visible=true;
			expand.data.mask[2][2].visible=true;
			expand.data.light[3].visible=false;
		}else{
			expand.data.mask[0][2].visible=false;
			expand.data.mask[1][2].visible=false;
			expand.data.mask[2][2].visible=false;
			expand.data.light[3].visible=true;
		}
		
		if(game.config['betInfo']['lines']<10){
			expand.data.mask[0][1].visible=true;
			expand.data.mask[1][1].visible=true;
			expand.data.mask[2][1].visible=true;
			expand.data.light[2].visible=false;
		}else{
			expand.data.mask[0][1].visible=false;
			expand.data.mask[1][1].visible=false;
			expand.data.mask[2][1].visible=false;
			expand.data.light[2].visible=true;
		}
		
		if(game.config['betInfo']['lines']<5){
			expand.data.mask[0][0].visible=true;
			expand.data.mask[1][0].visible=true;
			expand.data.mask[2][0].visible=true;
			expand.data.light[1].visible=false;
		}else{
			expand.data.mask[0][0].visible=false;
			expand.data.mask[1][0].visible=false;
			expand.data.mask[2][0].visible=false;
			expand.data.light[1].visible=true;
		}
	}
}
if(game.config.freeSpin==false && this.sound.base!=reels.winLinesSettings.sound.symbol_12){
	reels.winLinesSettings.sound.symbol_12=this.sound.base;
}else if(game.config.freeSpin==true && this.sound.feature!=reels.winLinesSettings.sound.symbol_12){
	reels.winLinesSettings.sound.symbol_12=this.sound.feature;
}
}
/*--------------------------------------------------------------------------------------------*/ 
expand.prototype.sortStage = function() {
	expand.FSAS.children.sort(function(a,b) {
		a.zIndex = a.zIndex || 0;
		b.zIndex = b.zIndex || 0;
		return   a.zIndex-b.zIndex
	});
}
/*--------------------------------------------------------------------------------------------*/ 
expand.prototype.answersWork = function() {
	
}
/*===============================================================================================*/
expand.prototype.removeChild = function(name) {
//console.info(game.stage);
//console.info('-----------------------');
for (var i = expand.stage.children.length - 1; i >= 0; i--) {	
	if(expand.stage.children[i].name==name){
		//console.info(game.stage.children[i]);
		expand.stage.removeChild(expand.stage.children[i]);
	}
}
//console.info('-----------------------');
//console.info(game.stage);
}
/*--------------------------------------------------------------------------------------------*/
function expand() {}
var expand = new expand(); 