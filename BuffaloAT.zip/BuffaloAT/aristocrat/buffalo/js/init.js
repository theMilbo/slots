/*--------------------------------------------------------------------------------------------*/
init.prototype.start  = function(data) {
console.log(data);
var gameJs = document.createElement("script");
	gameJs.type = "text/javascript";
	gameJs.src ="aristocrat/_engine/game.js?v="+data['sessionId'];
	document.getElementsByTagName("head")[0].appendChild(gameJs);
	gameJs.onload = function() {
		game.init(data);
	}
}
/*--------------------------------------------------------------------------------------------*/
function init() {}
var init = new init(); 