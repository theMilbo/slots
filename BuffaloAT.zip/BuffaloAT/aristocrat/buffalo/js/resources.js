if(game.debug==true){console.info("resources.js LOADED");}
//>>>>>>>>>>>>>>>>> IMAGES
for(i=1;i<(game.config['symbolsDifferent']*1)+1;i++){
	game.loadResource({name:'symbol_'+i,file:'images/symbol_'+i+'.'+game.config['imgType'],type:'image',width:174,height:130});
	game.loadResource({name:'symbol_'+i+'_anim_1',file:'images/symbol_'+i+'_anim.'+game.config['imgType'],type:'movieClip',width:174,height:130});

}
game.loadResource({name:'symbol_13_anim_2',file:'images/symbol_13_anim_2.'+game.config['imgType'],type:'movieClip',width:174,height:130});
game.loadResource({name:'symbol_13_anim_3',file:'images/symbol_13_anim_3.'+game.config['imgType'],type:'movieClip',width:174,height:130});


game.loadResource({type:'image',name:'background',file:'images/_'+game.config['template']+'/background.'+game.config['imgType']});


game.loadResource({name:'dialog_box',file:'images/_'+game.config['template']+'/dialog_box.'+game.config['imgType'],type:'image'});
game.loadResource({type:'image',name:'coinAnim',file:'images/coin_anim.'+game.config['imgType']});
game.loadResource({type:'image',name:'more_info',file:'images/_'+game.config['template']+'/more_info.'+game.config['imgType']});
game.loadResource({type:'image',name:'paytable_1',file:'images/_'+game.config['template']+'/paytable_1.'+game.config['imgType']});
game.loadResource({type:'image',name:'paytable_2',file:'images/_'+game.config['template']+'/paytable_2.'+game.config['imgType']});


game.loadResource({type:'image',name:'light',file:'images/light.'+game.config['imgType']});
game.loadResource({name:'coin_anim',file:'images/coin_anim.'+game.config['imgType'],type:'movieClip',width:80,height:80});


/*--------------------------------------------------------------------------------------------*/
//GAMBLE
game.loadResource({name:'gamble_background',file:'images/gamble/gamble.'+game.config['imgType'],type:'image',width:1280,height:720});
game.loadResource({name:'gamble_card_main',file:'images/gamble/card.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_win_anim',file:'images/gamble/win_anim.'+game.config['imgType'],type:'movieClip',width:173,height:251});

game.loadResource({name:'gamble_card_club_1',file:'images/gamble/card_club_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_card_club_2',file:'images/gamble/card_club_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_card_spade_1',file:'images/gamble/card_spade_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_card_spade_2',file:'images/gamble/card_spade_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_card_diamond_1',file:'images/gamble/card_diamond_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_card_diamond_2',file:'images/gamble/card_diamond_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_card_heart_1',file:'images/gamble/card_heart_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_card_heart_2',file:'images/gamble/card_heart_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_button_1',file:'images/gamble/button_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_button_2',file:'images/gamble/button_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_button_3',file:'images/gamble/button_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_button_4',file:'images/gamble/button_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_club_1',file:'images/gamble/club_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_club_2',file:'images/gamble/club_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_club_3',file:'images/gamble/club_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_club_4',file:'images/gamble/club_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_spade_1',file:'images/gamble/spade_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_spade_2',file:'images/gamble/spade_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_spade_3',file:'images/gamble/spade_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_spade_4',file:'images/gamble/spade_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_diamond_1',file:'images/gamble/diamond_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_diamond_2',file:'images/gamble/diamond_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_diamond_3',file:'images/gamble/diamond_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_diamond_4',file:'images/gamble/diamond_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_heart_1',file:'images/gamble/heart_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_heart_2',file:'images/gamble/heart_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_heart_3',file:'images/gamble/heart_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'gamble_heart_4',file:'images/gamble/heart_4.'+game.config['imgType'],type:'image'});
/*--------------------------------------------------------------------------------------------*/
//>>>>>>>>>>>>>>>>> SOUNDS
game.loadResource({type:'audio',name:'sound_background',file:'sounds/background.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_click',file:'sounds/click.'+game.config['soundType']});
//--------------- reel 
game.loadResource({type:'audio',name:'sound_reel_stop',file:'sounds/reel_stop.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_respin',file:'sounds/respin.'+game.config['soundType']});

//--------------- scatters 
game.loadResource({type:'audio',name:'sound_scatter_1',file:'sounds/scatter_1.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_scatter_2',file:'sounds/scatter_2.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_scatter_3',file:'sounds/scatter_3.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_scatter_4',file:'sounds/scatter_4.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_scatter_5',file:'sounds/scatter_5.'+game.config['soundType']});
//------------------ GAMBLE
game.loadResource({type:'audio',name:'sound_gamble_lose',file:'sounds/gamble_lose.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_gamble_win',file:'sounds/gamble_win.'+game.config['soundType']});
//------------------ sound_winSound_1 
game.loadResource({type:'audio',name:'sound_symbol_1',file:'sounds/winLines/buffalo.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_symbol_12',file:'sounds/winLines/scatter_win.'+game.config['soundType']});

game.loadResource({type:'audio',name:'sound_winSound_1',file:'sounds/winLines/win x5,10.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_2',file:'sounds/winLines/win x15.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_3',file:'sounds/winLines/win x20.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_4',file:'sounds/winLines/win x25.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_5',file:'sounds/winLines/win x30.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_6',file:'sounds/winLines/win x35.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_7',file:'sounds/winLines/win x40.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_8',file:'sounds/winLines/win x45.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_9',file:'sounds/winLines/win x50,55.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_10',file:'sounds/winLines/win x60.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_11',file:'sounds/winLines/win x70,75,80,85.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_12',file:'sounds/winLines/win x100,125.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_13',file:'sounds/winLines/win x130.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_14',file:'sounds/winLines/win x150.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_15',file:'sounds/winLines/win x200.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_16',file:'sounds/winLines/win x230,250.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_17',file:'sounds/winLines/win x300,320.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_18',file:'sounds/winLines/win x345,400.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_19',file:'sounds/winLines/win x490.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_20',file:'sounds/winLines/win x500.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_21',file:'sounds/winLines/win x800 coin shower.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_22',file:'sounds/winLines/win x800+coin shower.'+game.config['soundType']});
game.loadResource({type:'audio',name:'sound_winSound_23',file:'sounds/winLines/win x1140 coin shower.'+game.config['soundType']});