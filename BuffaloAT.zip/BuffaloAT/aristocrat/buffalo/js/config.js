if(game.debug==true){console.info("config.js LOADED");}
var BACKGROUND_COLOR="rgb(12,1,43)";
var FREE_SPIN_BACKGROUND_COLOR="rgb(12,1,43)";
var FREE_SPIN_IMAGES=true;
var SCATTER_SOUND=false;
var SOUND_BIG_ON=true;
var SOUND_BIG_NUMBER=8;
var CREDIT_BORDER=false;
game.config['symbolsDifferent']=13;
game.reelPower=true;
/*--------------------------------------------------------------------------------------------*/
config.prototype.loadResource  = function() {
game.loadResource({type:'language',name:'language',code:game.config['language'],engine:true});
game.loadResource({type:'script',name:'engine',engine:true});
game.loadResource({type:'script',name:'loading',engine:true});	
game.loadResource({type:'script',name:'interface',engine:true});
game.loadResource({type:'script',name:'buttons',engine:true});
game.loadResource({type:'script',name:'reels',engine:true});
game.loadResource({type:'script',name:'gamble',engine:true});
game.loadResource({type:'script',name:'freeSpin',engine:true});
game.loadResource({type:'script',name:'payTable',engine:true});
game.loadResource({type:'script',name:'expand',engine:false});
game.loadResource({type:'script',name:'resources',engine:false});	
if(game.config['template']=='mobile'){
	game.loadResource({type:'script',name:'settingMobile',engine:true});
}else if(game.config['template']=='standard'){
	game.loadResource({type:'script',name:'settingStandard',engine:true});
}
}
/*--------------------------------------------------------------------------------------------*/
config.prototype.init  = function() {
reels.config.reelPower=true;
reels.config.symbol={
	width:174,
	height:130,
	rows:4,
};
reels.reSpinConfig['activ']=true;
reels.config['scatters']=['symbol_12'];
reels.winLinesSettings['symbolsToAnimationAlways']=['symbol_1','symbol_12','symbol_13'];
reels.winLinesSettings['sound']={
	'priority':[],
	'symbol_1':{
		2:'sound_symbol_1',	
		3:'sound_symbol_1',
		4:'sound_symbol_1',
		5:'sound_symbol_1',
	},
	'symbol_12':{
		3:'sound_symbol_12',
		4:'sound_symbol_12',
		5:'sound_symbol_12',
	}
};
reels.winLinesSettings['soundTable']={
	1:5,
	2:15,
	3:20,
	4:25,
	5:30,
	6:35,
	7:40,
	8:45,
	9:55,
	10:60,
	11:70,
	12:100,
	13:130,
	14:150,
	15:200,
	16:230,
	17:300,
	18:345,
	19:590,
	20:500,
	21:800,
	22:950,
	23:1140
};
if(game.config['template']=='mobile'){
	reels.position={
		1:{x:178,y:596},
		2:{x:367,y:596},
		3:{x:556,y:596},
		4:{x:745,y:596},
		5:{x:934,y:596},
	};
}else if(game.config['template']=='standard'){
	reels.position={
		1:{x:178,y:566},
		2:{x:367,y:566},
		3:{x:556,y:566},
		4:{x:745,y:566},
		5:{x:934,y:566},
	};
}
}
/*--------------------------------------------------------------------------------------------*/
config.prototype.start  = function() {
game.resources.audio['sound_background'].play();
game.resources.audio['sound_background'].loop=true;
buttons.add();
reels.init();
game.interface();
expand.init();	
}
/*--------------------------------------------------------------------------------------------*/
function config() {}
var config = new config();