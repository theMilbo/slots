/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_a926 = ["#e27a00", "#fefb00", "#dfb827", "config", "prototype", "png", "mp3", "center", "bold", "text", "action", "init", "containers", "language", "buttons", "texture", "resources", "", "error", "canvas", "getElementById", "width", "height", "autoDetectRenderer", "stage", "Container", "extend", "interface", "template", "deviceDetect", "checkRatio", "mask", "Graphics", "zIndex", "name", "x", "position", "y", "beginFill", "alpha", "drawRect", "visible", "addChild", "languageBase", "loadResource", "script", "game.loading()", "onkeydown", "event", "keyCode", "mobile", "onclick", "fullScreen", "touchstart", "addEventListener", "loading", "normal", "loadingStage", "removeChild", "start", "restore", "drawGameScene", "sortStage", "loadingComplete", "gameInit", "sessionId", "send", "load", "engine", "ERROR <br> ", "game.actionExit()", "dialogBox", "render", "freeSpin", "on", "autoPlay", "length", "children", "current", "content", "response", "restoreMessage", "game.actionSpin()", "expand", "expand.restore : undefined", "info", "actionBeforeError", "container", "disableAll", "baseTexture", "dialog_box", "topY", "background", "elements", "Sprite", "spin_OR_gamble", "status", "messageBoxButton", "undefined:buttons.status:spin_OR_gamble", "button1_1", "button1_2", "button1_3", "button1_4", "click", "ok", "#000000", "add", "close", "textKey", "buttonText_messageBoxButton", "buttonOnclick", "string", "type", "textAlign", "#da1e1e", "textSize", "disableExclusion", "textColor", "style", "size", "px PartnerLightCondensed", "color", "align", "dialogBoxText_", "regex", "\x0A", "replace", "textAdd", "ratio", "4x3", "16x9", "log", "device", "iPhone", "iPad", "body", "#gameDiv", "transform", "scale(", ",", ")", "css", "scrollTo", "px", "%", "changeBet", "actionButtonChangeBet  ", " ", "lines", "betInfo", "indexOf", "betSettings", "plus", "bet", "bets", "linePlus", "state", "disable", "lineMinus", "betLinePlus", "betLineMinus", "statusUpdate", "totalBet", "reelsCost", "reelCost", "textUpdate", "betPerLine", "getCash", "denomination", "0.01", "toFixed", "key", "Text", "Ox", "Oy", "right", "left", "return", "gamble", "0", "not found : ", "stringify", "sort", "actionExit", "debug", "actionButtonExit", "wait...", "gameClose", "location", "exitUrl", "refreshBalance", "gameRefreshBalance", "ping", "gamePing", "&", "param", "responseText", "POST", "json", "serverMathematics", "ajax", "responseStatus", "onMessage", "fail_answer_from_server", "fail_connect_to_server", "response_from_server : ", "actionAuto", "actionSound", "sound", "mute", "audioManager", "unmute", "actionStop", "spin", "stopForse", "autoPlayLeft", "stop", "spinStopForse", "winLines", "winLinesStop", "timer", "wait", "actionSpin", "cashWinCollectedAll", "values", "actionButtonSpin", "PayTable", "balance", "error_fail_balance", "game.dialogBox()", "gameInfo", "textId", "win", "freeGame", "{current}", "data", "{total}", "total", "sound_spin", "audio", "play", "spinStart", "gameSpin", "gameSpinAdd", "fail", "success", "cmd", "session", "dateTime", "md5", "hash", "error hash", "pingInterval", "linesTotal", "betMin", "betMax", "reels", "symbols", "getSymbols", "reelSet", "answersWork", "gameTakeWin", "gameGamble", "gamePick", "game", "toLowerCase", ".answersWork()", "function not found : ", "splice", "inProcess", "push", "createElement", "text/javascript", "src", "/_language/", "code", "/_", ".js", "/", "systemName", "appendChild", "head", "getElementsByTagName", "onload", "resourcesLoad", "onerror", "en", "&language=", "&language=en", "href", "fail_load_language", "version", "/_engine/", ".js?", "/_template/", "/js/", "afterFunction", "fail_load_script : ", "file", "Loader", "loaders", "complete", "once", "image", "movieClip", "files", "createMovieClip", "fromImage", "Texture", "getAudio", "font", "appendTo", "<style>@font-face {\x09font-family: \'", "\';\x09src: url(\'", "/_fonts/", "\');}</style>", "symbol_1_anim_1", "animFrames", "frame", "Rectangle", "getSoudDuration", "duration", "Android", "userAgent", "display", "minus", "exit", "resize", "focus"];

console.log(_$_a926);

TEXT_GRADIENT = [_$_a926[0], _$_a926[1], _$_a926[2]];
game[_$_a926[4]][_$_a926[3]] = {
    width: 1280,
    height: 720,
    imgType: _$_a926[5],
    soundType: _$_a926[6],
    reels: {},
    balance: 0.00,
    win: 0.00,
    lastWin: 0.00,
    animationSpeed: 0.3,
    sound: true,
    fullScreen: false,
    freeSpin: false,
    textId: 1,
    restore: false,
    dialogBox: {
        textSize: 30,
        textColor: TEXT_GRADIENT,
        textAlign: _$_a926[7],
        fontWeight: _$_a926[8]
    },
    autoPlay: {
        on: false,
        wait: 60,
        timer: 0,
        left: 1,
        values: [1, 10, 25, 50, 75, 100]
    },
    regex: /<br\s*[\/]?>/gi,
    loading: -1
};
game[_$_a926[4]][_$_a926[9]] = {};
game[_$_a926[4]][_$_a926[10]] = _$_a926[11];
game[_$_a926[4]][_$_a926[12]] = {};
game[_$_a926[4]][_$_a926[13]] = {};
game[_$_a926[4]][_$_a926[14]] = {};
game[_$_a926[4]][_$_a926[15]] = {};
game[_$_a926[4]][_$_a926[16]] = {
    resources: 0,
    resourcesLoad: 0,
    image: {},
    movieClip: {},
    audio: {},
    script: {},
    json: {},
    language: {},
    font: {},
    inProcess: _$_a926[17],
    wait: []
};
game[_$_a926[4]][_$_a926[18]] = _$_a926[17];
game[_$_a926[4]][_$_a926[11]] = function(_0x661D) {
    canvas = document[_$_a926[20]](_$_a926[19]);
    renderer = new PIXI[_$_a926[23]](this[_$_a926[3]][_$_a926[21]], this[_$_a926[3]][_$_a926[22]], {
        view: canvas,
        transparent: true,
        forceCanvas: true
    });
    this[_$_a926[24]] = new PIXI[_$_a926[25]]();
    this[_$_a926[3]] = $[_$_a926[26]]({}, _0x661D, this[_$_a926[3]]);
    if (this[_$_a926[3]][_$_a926[27]] == undefined) {
        this[_$_a926[3]][_$_a926[27]] = this[_$_a926[3]][_$_a926[28]]
    }
    //67
    this[_$_a926[29]]();
    this[_$_a926[30]]();
    this[_$_a926[31]] = new PIXI[_$_a926[32]]();
    this[_$_a926[31]][_$_a926[33]] = 99;
    this[_$_a926[31]][_$_a926[34]] = _$_a926[31];
    this[_$_a926[31]][_$_a926[36]][_$_a926[35]] = 0;
    this[_$_a926[31]][_$_a926[36]][_$_a926[37]] = 0;
    this[_$_a926[31]][_$_a926[38]](0x000000);
    this[_$_a926[31]][_$_a926[39]] = 0.65;
    this[_$_a926[31]][_$_a926[40]](0, 0, this[_$_a926[3]][_$_a926[21]], this[_$_a926[3]][_$_a926[22]]);
    this[_$_a926[31]][_$_a926[41]] = false;
    game[_$_a926[24]][_$_a926[42]](this[_$_a926[31]]);
    game[_$_a926[44]]({
        type: _$_a926[13],
        name: _$_a926[43],
        code: game[_$_a926[3]][_$_a926[13]],
        engine: true
    });
    game[_$_a926[44]]({
        type: _$_a926[45],
        name: _$_a926[3],
        engine: false,
        afterFunction: _$_a926[46]
    });
    document[_$_a926[47]] = function(_0x69A2) {
        _0x69A2 = _0x69A2 || window[_$_a926[48]];
        game[_$_a926[49]](_0x69A2[_$_a926[49]])
    };
    if (game[_$_a926[3]][_$_a926[28]] == _$_a926[50]) {
        document[_$_a926[20]](_$_a926[19])[_$_a926[51]] = function() {
            engine[_$_a926[52]](true);
            game[_$_a926[30]]()
        };
        document[_$_a926[54]](_$_a926[53], function(_0x69A2) {
            engine[_$_a926[52]](true);
            game[_$_a926[30]]()
        })
    }

};
game[_$_a926[4]][_$_a926[55]] = function() {
    if (game[_$_a926[3]][_$_a926[55]] == -1) {
        game[_$_a926[3]][_$_a926[55]] = 0;
        config[_$_a926[44]]()
    }
    //117
    if (game[_$_a926[18]] == _$_a926[17]) {
        var _0x69D7 = 1; //122
        if (game[_$_a926[10]] == _$_a926[56]) {
            game[_$_a926[58]](_$_a926[57]);
            _0x69D7 = 0;
            config[_$_a926[59]]();
            reels[_$_a926[11]]();
            if (game[_$_a926[3]][_$_a926[60]] == true) {
                game[_$_a926[60]]()
            }
            //128
            game[_$_a926[61]]();
            game[_$_a926[62]]()
        } else {
            if (game[_$_a926[10]] == _$_a926[63]) {
                config[_$_a926[11]]();
                game[_$_a926[10]] = _$_a926[64];
                game[_$_a926[66]]({
                    cmd: _$_a926[64],
                    session: game[_$_a926[3]][_$_a926[65]]
                }, false)
            } else {
                if (game[_$_a926[16]][_$_a926[45]][_$_a926[55]][_$_a926[67]] == true && game[_$_a926[16]][_$_a926[45]][_$_a926[68]][_$_a926[67]] == true) {
                    loading[_$_a926[11]]()
                }

            }

        }
        //123
        if (_0x69D7 == 1) {
            requestAnimationFrame(game[_$_a926[55]])
        }

    } else {
        game[_$_a926[71]]({
            text: _$_a926[69] + game[_$_a926[18]],
            onclick: _$_a926[70],
            type: _$_a926[18]
        })
    }
    //121
    renderer[_$_a926[72]](game[_$_a926[24]])
};
game[_$_a926[4]][_$_a926[61]] = function() {
    if (game[_$_a926[18]] == _$_a926[17]) {
        reels[_$_a926[72]]();
        if (game[_$_a926[3]][_$_a926[73]] == true) {
            freeSpin[_$_a926[11]]()
        }
        //157
        if (game[_$_a926[3]][_$_a926[75]][_$_a926[74]] == true) {
            game[_$_a926[75]]()
        }
        //160
        buttons[_$_a926[11]]();
        renderer[_$_a926[72]](game[_$_a926[24]]);
        requestAnimationFrame(game[_$_a926[61]])
    } else {
        requestAnimationFrame(game[_$_a926[61]]);
        if (game[_$_a926[31]][_$_a926[41]] == false) {
            game[_$_a926[71]]({
                text: _$_a926[69] + game[_$_a926[18]],
                onclick: _$_a926[70],
                type: _$_a926[18]
            })
        }
        //168
        buttons[_$_a926[11]]();
        renderer[_$_a926[72]](game[_$_a926[24]])
    }

};
game[_$_a926[4]][_$_a926[58]] = function(_0x6B15) {
    for (var _0x6687 = game[_$_a926[24]][_$_a926[77]][_$_a926[76]] - 1; _0x6687 >= 0; _0x6687--) {
        if (game[_$_a926[24]][_$_a926[77]][_0x6687][_$_a926[34]] == _0x6B15) {
            game[_$_a926[24]][_$_a926[58]](game[_$_a926[24]][_$_a926[77]][_0x6687])
        }

    }

};
game[_$_a926[4]][_$_a926[60]] = function() {
    if (game[_$_a926[80]][_$_a926[79]][_$_a926[73]][_$_a926[78]] != undefined) {
        freeSpin[_$_a926[60]]()
    }
    //190
    this[_$_a926[71]]({
        text: game[_$_a926[13]][_$_a926[81]],
        onclick: _$_a926[82]
    });
    if (game[_$_a926[83]] == true) {
        try {
            expand[_$_a926[60]]()
        } catch (err) {
            console[_$_a926[85]](_$_a926[84])
        }

    }

};
game[_$_a926[4]][_$_a926[71]] = function(_0x6B4A) {
    if (_0x6B4A == undefined) {
        game[_$_a926[10]] = game[_$_a926[86]];
        this[_$_a926[31]][_$_a926[41]] = false;
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[41]] = false;
        buttons[_$_a926[88]] = false;
        return
    }
    //204
    if (this[_$_a926[12]][_$_a926[71]] == undefined) {
        if (reels[_$_a926[36]][0] == undefined) {
            reels[_$_a926[36]][0] = {
                height: 300,
                topY: 200
            }
        }
        //212
        this[_$_a926[12]][_$_a926[71]] = {
            container: _$_a926[17],
            elements: {},
            width: game[_$_a926[15]][_$_a926[90]][_$_a926[89]][_$_a926[21]],
            x: 1280 / 2 - game[_$_a926[15]][_$_a926[90]][_$_a926[89]][_$_a926[21]] / 2,
            y: reels[_$_a926[36]][0][_$_a926[22]] / 2 - game[_$_a926[15]][_$_a926[90]][_$_a926[89]][_$_a926[22]] / 2 + reels[_$_a926[36]][0][_$_a926[91]]
        };
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]] = new PIXI[_$_a926[25]]();
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[34]] = _$_a926[71];
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[36]][_$_a926[35]] = 0;
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[36]][_$_a926[37]] = 0;
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[33]] = 500;
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[41]] = false;
        game[_$_a926[24]][_$_a926[42]](this[_$_a926[12]][_$_a926[71]][_$_a926[87]]);
        this[_$_a926[12]][_$_a926[71]][_$_a926[93]][_$_a926[92]] = new PIXI[_$_a926[94]](game[_$_a926[15]][_$_a926[90]]);
        this[_$_a926[12]][_$_a926[71]][_$_a926[93]][_$_a926[92]][_$_a926[35]] = this[_$_a926[12]][_$_a926[71]][_$_a926[35]];
        this[_$_a926[12]][_$_a926[71]][_$_a926[93]][_$_a926[92]][_$_a926[37]] = this[_$_a926[12]][_$_a926[71]][_$_a926[37]];
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[42]](this[_$_a926[12]][_$_a926[71]][_$_a926[93]][_$_a926[92]]);
        if (buttons[_$_a926[96]][_$_a926[95]] != undefined) {
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[97]] = {
                display: true,
                state: _$_a926[56]
            }
        } else {
            console[_$_a926[85]](_$_a926[98])
        }
        //236
        buttons[_$_a926[96]][_$_a926[56]][_$_a926[97]] = {
            display: true,
            state: _$_a926[56]
        };
        buttons[_$_a926[106]]([{
            name: _$_a926[97],
            textures: [0, _$_a926[99], _$_a926[100], _$_a926[101], _$_a926[102]],
            onclick: _0x6B4A[_$_a926[51]],
            clickAudio: _$_a926[103],
            text: {
                key: _$_a926[104],
                color: _$_a926[105],
                size: 20,
                x: 0,
                y: 0,
                bold: _$_a926[17]
            },
            zIndex: 31,
            x: 640 - 60,
            y: this[_$_a926[12]][_$_a926[71]][_$_a926[37]] + game[_$_a926[15]][_$_a926[90]][_$_a926[89]][_$_a926[22]] - 60,
            w: 120,
            h: 35
        }], this[_$_a926[12]][_$_a926[71]][_$_a926[87]])
    }
    //211
    if (_0x6B4A[_$_a926[9]] == _$_a926[17] && _0x6B4A[_$_a926[51]] == _$_a926[107]) {
        this[_$_a926[31]][_$_a926[41]] = false;
        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[41]] = false
    } else {
        if (_0x6B4A[_$_a926[9]] != _$_a926[17]) {
            for (var _0x6687 = 0; _0x6687 < this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[77]][_$_a926[76]]; _0x6687++) {
                if (this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[77]][_0x6687][_$_a926[9]] != undefined) {
                    if (this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[77]][_0x6687][_$_a926[108]] != _$_a926[109]) {
                        delete game[_$_a926[9]][this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[77]][_0x6687][_$_a926[108]]]; //266
                        this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[58]](this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[77]][_0x6687]);
                        _0x6687 = 0
                    }

                }

            }
            //262
            if (_0x6B4A[_$_a926[51]] != _$_a926[107]) {
                game[_$_a926[14]][_$_a926[97]][_$_a926[110]] = _0x6B4A[_$_a926[51]]
            }
            //273
            if (_0x6B4A[_$_a926[51]] == _$_a926[17]) {
                game[_$_a926[14]][_$_a926[97]][_$_a926[41]] = false
            } else {
                game[_$_a926[14]][_$_a926[97]][_$_a926[41]] = true
            }
            //276
            var _0x6B7F = typeof _0x6B4A[_$_a926[9]]; //282
            if (_0x6B7F == _$_a926[111]) {
                if (_0x6B4A[_$_a926[112]] == _$_a926[18]) {
                    _0x6B4A[_$_a926[9]] = [{
                        x: game[_$_a926[12]][_$_a926[71]][_$_a926[21]] / 2,
                        y: 180,
                        align: this[_$_a926[3]][_$_a926[71]][_$_a926[113]],
                        color: _$_a926[114],
                        size: this[_$_a926[3]][_$_a926[71]][_$_a926[115]] * 1.3,
                        text: _0x6B4A[_$_a926[9]]
                    }];
                    buttons[_$_a926[88]] = true;
                    buttons[_$_a926[116]] = [_$_a926[97]];
                    if (buttons[_$_a926[96]][game[_$_a926[10]]] != undefined) {
                        buttons[_$_a926[96]][_$_a926[18]] = buttons[_$_a926[96]][game[_$_a926[10]]];
                        buttons[_$_a926[96]][_$_a926[18]][_$_a926[97]] = {
                            display: true,
                            state: _$_a926[56]
                        }
                    }
                    //296
                    game[_$_a926[86]] = game[_$_a926[10]];
                    game[_$_a926[10]] = _$_a926[18]
                } else {
                    _0x6B4A[_$_a926[9]] = [{
                        x: game[_$_a926[12]][_$_a926[71]][_$_a926[21]] / 2,
                        y: 200,
                        align: this[_$_a926[3]][_$_a926[71]][_$_a926[113]],
                        color: this[_$_a926[3]][_$_a926[71]][_$_a926[117]],
                        size: this[_$_a926[3]][_$_a926[71]][_$_a926[115]],
                        text: _0x6B4A[_$_a926[9]]
                    }]
                }

            }
            //284
            for (var _0x6687 = 0; _0x6687 < _0x6B4A[_$_a926[9]][_$_a926[76]]; _0x6687++) {
                if (_0x6B4A[_$_a926[9]][_0x6687][_$_a926[118]] == undefined) {
                    _0x6B4A[_$_a926[9]][_0x6687][_$_a926[118]] = {
                        font: _0x6B4A[_$_a926[9]][_0x6687][_$_a926[119]] + _$_a926[120],
                        fill: _0x6B4A[_$_a926[9]][_0x6687][_$_a926[121]],
                        align: _0x6B4A[_$_a926[9]][_0x6687][_$_a926[122]]
                    }
                }
                //317
                this[_$_a926[127]]({
                    key: _$_a926[123] + _0x6687,
                    text: _0x6B4A[_$_a926[9]][_0x6687][_$_a926[9]][_$_a926[126]](this[_$_a926[3]][_$_a926[124]], _$_a926[125]),
                    x: _0x6B4A[_$_a926[9]][_0x6687][_$_a926[35]] + this[_$_a926[12]][_$_a926[71]][_$_a926[35]],
                    y: _0x6B4A[_$_a926[9]][_0x6687][_$_a926[37]] + this[_$_a926[12]][_$_a926[71]][_$_a926[37]],
                    style: _0x6B4A[_$_a926[9]][_0x6687][_$_a926[118]],
                    stage: this[_$_a926[12]][_$_a926[71]][_$_a926[87]]
                })
            }
            //315
            this[_$_a926[31]][_$_a926[41]] = true;
            this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[41]] = true
        }

    }

};
game[_$_a926[4]][_$_a926[30]] = function() {
    var _0x675B = $(window)[_$_a926[21]](); //339
    var _0x6652 = $(window)[_$_a926[22]](); //340
    if (this[_$_a926[3]][_$_a926[128]] == undefined) {
        if (this[_$_a926[3]][_$_a926[21]] / 4 * 3 == this[_$_a926[3]][_$_a926[22]]) {
            this[_$_a926[3]][_$_a926[128]] = _$_a926[129]
        } else {
            this[_$_a926[3]][_$_a926[128]] = _$_a926[130]
        }

    }
    //341
    if (this[_$_a926[3]][_$_a926[50]] == true) {
        console[_$_a926[131]](this[_$_a926[3]][_$_a926[50]]);
        if (this[_$_a926[3]][_$_a926[132]] == _$_a926[133] || this[_$_a926[3]][_$_a926[132]] == _$_a926[134]) {
            $(_$_a926[135])[_$_a926[21]]($(window)[_$_a926[21]]() + 1);
            $(_$_a926[135])[_$_a926[22]]($(window)[_$_a926[22]]() + 1);
            $(_$_a926[136])[_$_a926[21]](this[_$_a926[3]][_$_a926[21]] + 1);
            $(_$_a926[136])[_$_a926[22]](this[_$_a926[3]][_$_a926[22]] + 1)
        } else {
            $(_$_a926[136])[_$_a926[21]](this[_$_a926[3]][_$_a926[21]]);
            $(_$_a926[136])[_$_a926[22]](this[_$_a926[3]][_$_a926[22]])
        }
        //350
        $(_$_a926[136])[_$_a926[141]](_$_a926[137], _$_a926[138] + $(window)[_$_a926[21]]() / this[_$_a926[3]][_$_a926[21]] + _$_a926[139] + $(window)[_$_a926[22]]() / this[_$_a926[3]][_$_a926[22]] + _$_a926[140]);
        if (this[_$_a926[3]][_$_a926[132]] == _$_a926[133] || this[_$_a926[3]][_$_a926[132]] == _$_a926[134]) {
            window[_$_a926[142]](0, 1)
        }
        //360
        window[_$_a926[142]](0, 1)
    } else {
        if (this[_$_a926[3]][_$_a926[128]] == _$_a926[129]) {
            if (_0x675B / 4 > _0x6652 / 3) {
                _0x675B = _0x6652 * 4 / 3
            } else {
                _0x6652 = _0x675B * 3 / 4
            }
            //366
            var _0x6687 = _$_a926[143]
        } else {
            if (this[_$_a926[3]][_$_a926[128]] == _$_a926[130]) {
                if (_0x675B / 16 > _0x6652 / 9) {
                    _0x675B = _0x6652 * 16 / 9
                } else {
                    _0x6652 = _0x675B * 9 / 16
                }
                //373
                var _0x6687 = _$_a926[143]
            } else {
                _0x675B = 100;
                _0x6652 = 100;
                var _0x6687 = _$_a926[144]
            }

        }
        //365
        canvas[_$_a926[118]][_$_a926[21]] = _0x675B + _0x6687;
        canvas[_$_a926[118]][_$_a926[22]] = _0x6652 + _0x6687
    }

};
game[_$_a926[4]][_$_a926[145]] = function(_0x79FD, _0x6A41) {
    console[_$_a926[85]](_$_a926[146] + _0x79FD + _$_a926[147] + _0x6A41);
    if (_0x79FD == _$_a926[148]) {
        var _0x6C88 = game[_$_a926[3]][_$_a926[151]][_$_a926[148]][_$_a926[150]](game[_$_a926[3]][_$_a926[149]][_$_a926[148]]); //392
        if (_0x6A41 == _$_a926[152]) {
            _0x6C88++
        } else {
            _0x6C88--
        }
        //393
        if (game[_$_a926[3]][_$_a926[151]][_$_a926[148]][_0x6C88] != undefined) {
            game[_$_a926[3]][_$_a926[149]][_$_a926[148]] = game[_$_a926[3]][_$_a926[151]][_$_a926[148]][_0x6C88]
        }

    }
    //391
    if (_0x79FD == _$_a926[153]) {
        var _0x6C88 = game[_$_a926[3]][_$_a926[151]][_$_a926[154]][_$_a926[150]](game[_$_a926[3]][_$_a926[149]][_$_a926[153]]); //400
        if (_0x6A41 == _$_a926[152]) {
            _0x6C88++
        } else {
            _0x6C88--
        }
        //401
        if (game[_$_a926[3]][_$_a926[151]][_$_a926[154]][_0x6C88] != undefined) {
            game[_$_a926[3]][_$_a926[149]][_$_a926[153]] = game[_$_a926[3]][_$_a926[151]][_$_a926[154]][_0x6C88]
        }

    }
    //399
    if (buttons[_$_a926[96]][_$_a926[56]][_$_a926[155]] != undefined) {
        var _0x79C8 = game[_$_a926[3]][_$_a926[151]][_$_a926[148]][_$_a926[150]](game[_$_a926[3]][_$_a926[149]][_$_a926[148]]); //408
        if (_0x79C8 == game[_$_a926[3]][_$_a926[151]][_$_a926[148]][_$_a926[76]] - 1) {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[155]][_$_a926[156]] = _$_a926[157];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[155]][_$_a926[156]] = _$_a926[157]
        } else {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[155]][_$_a926[156]] = _$_a926[56];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[155]][_$_a926[156]] = _$_a926[56]
        }
        //409
        if (_0x79C8 == 0) {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[158]][_$_a926[156]] = _$_a926[157];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[158]][_$_a926[156]] = _$_a926[157]
        } else {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[158]][_$_a926[156]] = _$_a926[56];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[158]][_$_a926[156]] = _$_a926[56]
        }

    }
    //407
    if (buttons[_$_a926[96]][_$_a926[56]][_$_a926[159]] != undefined) {
        var _0x7993 = game[_$_a926[3]][_$_a926[151]][_$_a926[154]][_$_a926[150]](game[_$_a926[3]][_$_a926[149]][_$_a926[153]]); //425
        if (_0x7993 == game[_$_a926[3]][_$_a926[151]][_$_a926[154]][_$_a926[76]] - 1) {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[159]][_$_a926[156]] = _$_a926[157];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[159]][_$_a926[156]] = _$_a926[157]
        } else {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[159]][_$_a926[156]] = _$_a926[56];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[159]][_$_a926[156]] = _$_a926[56]
        }
        //426
        if (_0x7993 == 0) {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[160]][_$_a926[156]] = _$_a926[157];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[160]][_$_a926[156]] = _$_a926[157]
        } else {
            buttons[_$_a926[96]][_$_a926[56]][_$_a926[160]][_$_a926[156]] = _$_a926[56];
            buttons[_$_a926[96]][_$_a926[95]][_$_a926[160]][_$_a926[156]] = _$_a926[56]
        }
        //433
        buttons[_$_a926[161]] = true
    }
    //424
    this[_$_a926[3]][_$_a926[149]][_$_a926[162]] = this[_$_a926[3]][_$_a926[149]][_$_a926[148]] * this[_$_a926[3]][_$_a926[149]][_$_a926[153]];
    if (this[_$_a926[3]][_$_a926[151]][_$_a926[163]] != undefined) {
        this[_$_a926[3]][_$_a926[149]][_$_a926[162]] = this[_$_a926[3]][_$_a926[151]][_$_a926[163]][this[_$_a926[3]][_$_a926[149]][_$_a926[148]]] * this[_$_a926[3]][_$_a926[149]][_$_a926[153]]
    }
    //444
    if (this[_$_a926[3]][_$_a926[151]][_$_a926[164]] != undefined) {
        var _0x6C88 = game[_$_a926[3]][_$_a926[151]][_$_a926[148]][_$_a926[150]](game[_$_a926[3]][_$_a926[149]][_$_a926[148]]); //448
        this[_$_a926[3]][_$_a926[149]][_$_a926[162]] = game[_$_a926[3]][_$_a926[151]][_$_a926[164]][_0x6C88] * this[_$_a926[3]][_$_a926[149]][_$_a926[153]]
    }
    //447
    if (game[_$_a926[9]][_$_a926[148]] != undefined) {
        this[_$_a926[165]]({
            key: _$_a926[148],
            text: this[_$_a926[3]][_$_a926[149]][_$_a926[148]]
        })
    }
    //451
    if (this[_$_a926[9]][_$_a926[166]] != undefined) {
        this[_$_a926[165]]({
            key: _$_a926[166],
            text: this[_$_a926[167]](this[_$_a926[3]][_$_a926[149]][_$_a926[153]])
        })
    }
    //454
    if (this[_$_a926[9]][_$_a926[162]] != undefined) {
        this[_$_a926[165]]({
            key: _$_a926[162],
            text: this[_$_a926[167]](this[_$_a926[3]][_$_a926[149]][_$_a926[162]])
        })
    }

};
game[_$_a926[4]][_$_a926[167]] = function(_0x7A32) {
    _0x7A32 = _0x7A32 * game[_$_a926[3]][_$_a926[149]][_$_a926[168]];
    if (game[_$_a926[3]][_$_a926[149]][_$_a926[168]] == _$_a926[169]) {
        var _0x7A67 = 2
    } else {
        var _0x7A67 = 0
    }
    //466
    return (_0x7A32)[_$_a926[170]](_0x7A67)
};
game[_$_a926[4]][_$_a926[127]] = function(_0x6B4A) {
    if (_0x6B4A[_$_a926[33]] == undefined) {
        _0x6B4A[_$_a926[33]] = 10
    }
    //475
    if (_0x6B4A[_$_a926[41]] == undefined) {
        _0x6B4A[_$_a926[41]] = true
    }
    //476
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]] = new PIXI[_$_a926[172]](_0x6B4A[_$_a926[9]], _0x6B4A[_$_a926[118]]);
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[35]] = _0x6B4A[_$_a926[35]];
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[37]] = _0x6B4A[_$_a926[37]];
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[173]] = _0x6B4A[_$_a926[35]];
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[174]] = _0x6B4A[_$_a926[37]];
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[33]] = _0x6B4A[_$_a926[33]];
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[41]] = _0x6B4A[_$_a926[41]];
    this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[108]] = _0x6B4A[_$_a926[171]];
    if (this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[118]][_$_a926[122]] == _$_a926[7]) {
        this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[35]] -= this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[21]] / 2
    }
    //487
    if (this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[118]][_$_a926[122]] == _$_a926[175]) {
        this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[35]] -= this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[21]]
    }
    //490
    if (this[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[118]][_$_a926[122]] == _$_a926[176]) {

    }
    //493
    if (_0x6B4A[_$_a926[24]] == undefined) {
        _0x6B4A[_$_a926[24]] = _$_a926[17]
    }
    //498
    if (_0x6B4A[_$_a926[24]] == _$_a926[177]) {
        return this[_$_a926[9]][_0x6B4A[_$_a926[171]]]
    } else {
        if (_0x6B4A[_$_a926[24]] == _$_a926[178]) {
            gamble[_$_a926[24]][_$_a926[42]](this[_$_a926[9]][_0x6B4A[_$_a926[171]]])
        } else {
            if (_0x6B4A[_$_a926[24]] == _$_a926[179]) {
                return this[_$_a926[9]][_0x6B4A[_$_a926[171]]]
            } else {
                if (_0x6B4A[_$_a926[24]] != _$_a926[17]) {
                    _0x6B4A[_$_a926[24]][_$_a926[42]](this[_$_a926[9]][_0x6B4A[_$_a926[171]]])
                } else {
                    this[_$_a926[24]][_$_a926[42]](this[_$_a926[9]][_0x6B4A[_$_a926[171]]])
                }

            }

        }

    }

};
game[_$_a926[4]][_$_a926[165]] = function(_0x6B4A) {
    if (game[_$_a926[9]][_0x6B4A[_$_a926[171]]] != undefined) {
        game[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[9]] = _0x6B4A[_$_a926[9]];
        if (game[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[118]][_$_a926[122]] == _$_a926[7]) {
            game[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[35]] = game[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[36]][_$_a926[173]] - game[_$_a926[9]][_0x6B4A[_$_a926[171]]][_$_a926[21]] / 2
        }

    } else {
        console[_$_a926[85]](_$_a926[180] + _0x6B4A[_$_a926[171]]);
        console[_$_a926[85]](JSON[_$_a926[181]](game[_$_a926[9]][_0x6B4A[_$_a926[171]]]))
    }

};
game[_$_a926[4]][_$_a926[62]] = function() {
    game[_$_a926[24]][_$_a926[77]][_$_a926[182]](function(_0x6C88, _0x6D27) {
        _0x6C88[_$_a926[33]] = _0x6C88[_$_a926[33]] || 0;
        _0x6D27[_$_a926[33]] = _0x6D27[_$_a926[33]] || 0;
        return _0x6C88[_$_a926[33]] - _0x6D27[_$_a926[33]]
    })
};
game[_$_a926[4]][_$_a926[183]] = function() {
    if (this[_$_a926[184]] == true) {
        console[_$_a926[131]](_$_a926[185])
    }
    //540
    this[_$_a926[71]]({
        text: _$_a926[186],
        onclick: _$_a926[17]
    });
    this[_$_a926[66]]({
        cmd: _$_a926[187],
        session: this[_$_a926[3]][_$_a926[65]]
    }, true);
    setTimeout(function() {
        window[_$_a926[188]] = game[_$_a926[3]][_$_a926[189]]
    }, 500)
};
game[_$_a926[4]][_$_a926[190]] = function() {
    this[_$_a926[66]]({
        cmd: _$_a926[191],
        session: this[_$_a926[3]][_$_a926[65]]
    }, true)
};
game[_$_a926[4]][_$_a926[192]] = function() {
    var _0x6B4A = {
        cmd: _$_a926[193],
        session: this[_$_a926[3]][_$_a926[65]]
    }; //553
    var _0x7A9C = _$_a926[194] + jQuery[_$_a926[195]](_0x6B4A); //555
    $[_$_a926[200]]({
        type: _$_a926[197],
        dataType: _$_a926[198],
        url: this[_$_a926[3]][_$_a926[199]] + _0x7A9C,
        crossDomain: true,
        data: _0x6B4A,
        async: true,
        timeout: 6000
    })[_$_a926[196]]
};
game[_$_a926[4]][_$_a926[66]] = function(_0x6B4A, _0x7AD1) {
    if (_0x7AD1 == undefined) {
        _0x7AD1 = false
    }
    //570
    this[_$_a926[201]] = _$_a926[66];
    this[_$_a926[80]] = _$_a926[17];
    var _0x7A9C = _$_a926[194] + jQuery[_$_a926[195]](_0x6B4A); //574
    $[_$_a926[200]]({
        type: _$_a926[197],
        dataType: _$_a926[198],
        url: this[_$_a926[3]][_$_a926[199]] + _0x7A9C,
        crossDomain: true,
        data: _0x6B4A,
        async: _0x7AD1,
        success: function(_0x6B4A) {
            game[_$_a926[202]](_0x6B4A)
        },
        fail: function() {
            game[_$_a926[18]] = _$_a926[203];
            console[_$_a926[131]](JSON[_$_a926[181]](game[_$_a926[80]]))
        },
        error: function() {
            if (game[_$_a926[18]] == false) {
                game[_$_a926[18]] = _$_a926[204]
            }

        }
    })[_$_a926[196]];
    if (this[_$_a926[184]] == true) {
        console[_$_a926[131]](_$_a926[205] + JSON[_$_a926[181]](this[_$_a926[80]]))
    }

};
game[_$_a926[4]][_$_a926[206]] = function(_0x6A41) {
    console[_$_a926[85]](_0x6A41)
};
game[_$_a926[4]][_$_a926[207]] = function() {
    if (this[_$_a926[3]][_$_a926[208]] == true) {
        this[_$_a926[3]][_$_a926[208]] = false;
        PIXI[_$_a926[210]][_$_a926[209]]()
    } else {
        this[_$_a926[3]][_$_a926[208]] = true;
        PIXI[_$_a926[210]][_$_a926[211]]()
    }

};
game[_$_a926[4]][_$_a926[212]] = function() {
    if (this[_$_a926[10]] == _$_a926[213]) {
        if (this[_$_a926[3]][_$_a926[75]][_$_a926[74]] == true && reels[_$_a926[3]][_$_a926[214]] == false) {
            this[_$_a926[3]][_$_a926[75]][_$_a926[74]] = false;
            this[_$_a926[3]][_$_a926[75]][_$_a926[176]] = 1;
            this[_$_a926[165]]({
                key: _$_a926[215],
                text: game[_$_a926[3]][_$_a926[75]][_$_a926[176]]
            });
            buttons[_$_a926[96]][_$_a926[213]][_$_a926[216]][_$_a926[156]] = _$_a926[157];
            buttons[_$_a926[161]] = true
        } else {
            if (reels[_$_a926[3]][_$_a926[214]] == true) {
                reels[_$_a926[217]]()
            }

        }

    } else {
        if (this[_$_a926[10]] == _$_a926[218]) {
            reels[_$_a926[219]]()
        }

    }

};
game[_$_a926[4]][_$_a926[75]] = function(_0x6A41) {
    if (_0x6A41 == undefined) {
        if (this[_$_a926[12]][_$_a926[71]][_$_a926[87]][_$_a926[41]] == false) {
            if (this[_$_a926[10]] == _$_a926[56]) {
                this[_$_a926[3]][_$_a926[75]][_$_a926[220]]++;
                if (this[_$_a926[3]][_$_a926[75]][_$_a926[220]] > this[_$_a926[3]][_$_a926[75]][_$_a926[221]]) {
                    this[_$_a926[3]][_$_a926[75]][_$_a926[220]] = 0;
                    this[_$_a926[222]]();
                    if (game[_$_a926[3]][_$_a926[73]] == false) {
                        this[_$_a926[3]][_$_a926[75]][_$_a926[176]]--;
                        this[_$_a926[165]]({
                            key: _$_a926[215],
                            text: game[_$_a926[3]][_$_a926[75]][_$_a926[176]]
                        });
                        if (this[_$_a926[3]][_$_a926[75]][_$_a926[176]] == 1) {
                            this[_$_a926[3]][_$_a926[75]][_$_a926[74]] = false
                        }

                    }

                }

            } else {
                if (this[_$_a926[10]] == _$_a926[95] && reels[_$_a926[223]] == true) {
                    this[_$_a926[10]] = _$_a926[56]
                }

            }

        }

    } else {
        var _0x6C88 = game[_$_a926[3]][_$_a926[75]][_$_a926[224]][_$_a926[150]](game[_$_a926[3]][_$_a926[75]][_$_a926[176]]); //659
        if (_0x6A41 == _$_a926[152]) {
            _0x6C88++
        } else {
            _0x6C88--
        }
        //660
        if (game[_$_a926[3]][_$_a926[75]][_$_a926[224]][_0x6C88] != undefined) {
            game[_$_a926[3]][_$_a926[75]][_$_a926[176]] = game[_$_a926[3]][_$_a926[75]][_$_a926[224]][_0x6C88];
            game[_$_a926[165]]({
                key: _$_a926[215],
                text: game[_$_a926[3]][_$_a926[75]][_$_a926[176]]
            })
        }

    }

};
game[_$_a926[4]][_$_a926[222]] = function() {
    if (this[_$_a926[184]] == true) {
        console[_$_a926[131]](_$_a926[225])
    }
    //669
    if (this[_$_a926[10]] == _$_a926[56] || this[_$_a926[10]] == _$_a926[218] || this[_$_a926[10]] == _$_a926[95]) {
        this[_$_a926[71]]({
            text: _$_a926[17],
            onclick: _$_a926[107]
        });
        if (this[_$_a926[12]][_$_a926[226]] != undefined) {
            if (this[_$_a926[12]][_$_a926[226]][_$_a926[41]] == true) {
                payTable[_$_a926[11]]()
            }

        }
        //672
        if (this[_$_a926[3]][_$_a926[73]] == false) {
            if (this[_$_a926[3]][_$_a926[75]][_$_a926[176]] > 1 && this[_$_a926[3]][_$_a926[75]][_$_a926[74]] == false) {
                this[_$_a926[3]][_$_a926[75]][_$_a926[74]] = true;
                this[_$_a926[3]][_$_a926[75]][_$_a926[176]]--;
                this[_$_a926[165]]({
                    key: _$_a926[215],
                    text: this[_$_a926[3]][_$_a926[75]][_$_a926[176]]
                })
            }
            //678
            if (this[_$_a926[3]][_$_a926[149]][_$_a926[162]] > this[_$_a926[3]][_$_a926[227]]) {
                this[_$_a926[71]]({
                    text: this[_$_a926[13]][_$_a926[228]],
                    onclick: _$_a926[229],
                    type: _$_a926[18]
                });
                this[_$_a926[3]][_$_a926[75]][_$_a926[74]] = false;
                this[_$_a926[3]][_$_a926[75]][_$_a926[176]] = 0;
                this[_$_a926[165]]({
                    key: _$_a926[215],
                    text: this[_$_a926[3]][_$_a926[75]][_$_a926[176]]
                });
                return
            }
            //683
            this[_$_a926[3]][_$_a926[227]] -= this[_$_a926[3]][_$_a926[149]][_$_a926[162]];
            this[_$_a926[165]]({
                key: _$_a926[227],
                text: this[_$_a926[167]](this[_$_a926[3]][_$_a926[227]])
            });
            this[_$_a926[165]]({
                key: _$_a926[230],
                text: this[_$_a926[13]][_$_a926[9]][this[_$_a926[3]][_$_a926[231]]]
            });
            this[_$_a926[3]][_$_a926[231]]++;
            if (this[_$_a926[13]][_$_a926[9]][this[_$_a926[3]][_$_a926[231]]] == undefined) {
                this[_$_a926[3]][_$_a926[231]] = 1
            }
            //694
            this[_$_a926[3]][_$_a926[232]] = 0.00;
            this[_$_a926[165]]({
                key: _$_a926[232],
                text: (this[_$_a926[3]][_$_a926[232]] * 1)[_$_a926[170]](2)
            })
        } else {
            var _0x7B06 = this[_$_a926[13]][_$_a926[233]]; //700
            _0x7B06 = _0x7B06[_$_a926[126]](_$_a926[234], freeSpin[_$_a926[235]][_$_a926[78]] + 1);
            _0x7B06 = _0x7B06[_$_a926[126]](_$_a926[236], freeSpin[_$_a926[235]][_$_a926[237]]);
            this[_$_a926[165]]({
                key: _$_a926[230],
                text: _0x7B06
            })
        }
        //677
        if (game[_$_a926[16]][_$_a926[239]][_$_a926[238]] != undefined) {
            game[_$_a926[16]][_$_a926[239]][_$_a926[238]][_$_a926[240]]()
        }
        //705
        reels[_$_a926[241]]();
        this[_$_a926[10]] = _$_a926[213];
        this[_$_a926[66]]($[_$_a926[26]]({}, {
            cmd: _$_a926[242],
            session: this[_$_a926[3]][_$_a926[65]],
            lines: this[_$_a926[3]][_$_a926[149]][_$_a926[148]],
            bet: this[_$_a926[3]][_$_a926[149]][_$_a926[153]],
            denomination: this[_$_a926[3]][_$_a926[149]][_$_a926[168]]
        }, game[_$_a926[243]]), true)
    }

};
game[_$_a926[4]][_$_a926[202]] = function(_0x6B4A) {
    if (_0x6B4A[_$_a926[96]] == _$_a926[244]) {
        game[_$_a926[18]] = _0x6B4A[_$_a926[18]];
        game[_$_a926[71]]({
            text: game[_$_a926[18]],
            type: _$_a926[18],
            onclick: _$_a926[70]
        })
    } else {
        if (_0x6B4A[_$_a926[96]] == _$_a926[245]) {
            console[_$_a926[131]](_0x6B4A[_$_a926[79]][_$_a926[246]]);
            if (0!=0){
            } else {
                if (_0x6B4A[_$_a926[79]][_$_a926[246]] == _$_a926[64]) {
                    game[_$_a926[80]] = _0x6B4A;
                    game[_$_a926[3]][_$_a926[60]] = _0x6B4A[_$_a926[79]][_$_a926[60]];
                    game[_$_a926[3]][_$_a926[189]] = _0x6B4A[_$_a926[79]][_$_a926[189]];
                    pingTimer = setInterval(function() {
                        game[_$_a926[192]]()
                    }, _0x6B4A[_$_a926[79]][_$_a926[252]]);
                    game[_$_a926[3]][_$_a926[149]] = _0x6B4A[_$_a926[79]][_$_a926[149]];
                    game[_$_a926[3]][_$_a926[227]] = _0x6B4A[_$_a926[79]][_$_a926[227]];
                    game[_$_a926[3]][_$_a926[151]] = _0x6B4A[_$_a926[79]][_$_a926[151]];
                    game[_$_a926[3]][_$_a926[151]][_$_a926[253]] = game[_$_a926[3]][_$_a926[151]][_$_a926[148]][game[_$_a926[3]][_$_a926[151]][_$_a926[148]][_$_a926[76]] - 1];
                    game[_$_a926[3]][_$_a926[151]][_$_a926[254]] = game[_$_a926[3]][_$_a926[151]][_$_a926[154]][0];
                    game[_$_a926[3]][_$_a926[151]][_$_a926[255]] = game[_$_a926[3]][_$_a926[151]][_$_a926[154]][game[_$_a926[3]][_$_a926[151]][_$_a926[154]][_$_a926[76]] - 1];
                    game[_$_a926[3]][_$_a926[256]] = _0x6B4A[_$_a926[79]][_$_a926[256]];
                    game[_$_a926[257]] = _0x6B4A[_$_a926[79]][_$_a926[257]];
                    if (game[_$_a926[257]] == null) {
                        game[_$_a926[257]] = engine[_$_a926[258]]()
                    }
                    //763
                    if (game[_$_a926[257]][_$_a926[259]] != undefined) {
                        reels[_$_a926[3]][_$_a926[259]] = game[_$_a926[257]][_$_a926[259]]
                    }
                    //766
                    game[_$_a926[145]]();
                    game[_$_a926[10]] = _$_a926[56]
                } else {
                    if (_0x6B4A[_$_a926[79]][_$_a926[246]] == _$_a926[242]) {
                        game[_$_a926[80]] = _0x6B4A;
                        reels[_$_a926[260]]()
                    } else {
                        if (_0x6B4A[_$_a926[79]][_$_a926[246]] == _$_a926[261]) {
                            game[_$_a926[80]] = _0x6B4A;
                            gamble[_$_a926[260]]()
                        } else {
                            if (_0x6B4A[_$_a926[79]][_$_a926[246]] == _$_a926[262]) {
                                game[_$_a926[80]] = _0x6B4A;
                                gamble[_$_a926[260]]()
                            } else {
                                if (_0x6B4A[_$_a926[79]][_$_a926[246]] == _$_a926[191]) {
                                    game[_$_a926[80]] = _0x6B4A;
                                    game[_$_a926[3]][_$_a926[227]] = _0x6B4A[_$_a926[79]][_$_a926[227]];
                                    this[_$_a926[165]]({
                                        key: _$_a926[227],
                                        text: game[_$_a926[167]](game[_$_a926[3]][_$_a926[227]])
                                    })
                                } else {
                                    if (_0x6B4A[_$_a926[79]][_$_a926[246]] == _$_a926[263]) {
                                        game[_$_a926[80]] = _0x6B4A;
                                        pick[_$_a926[260]]()
                                    } else {
                                        game[_$_a926[80]] = _0x6B4A;
                                        var _0x7A67 = _0x6B4A[_$_a926[79]][_$_a926[246]][_$_a926[126]](_$_a926[264], _$_a926[17]); //807
                                        _0x7A67 = _0x7A67[_$_a926[265]]() + _$_a926[266];
                                        try {
                                            var _0x7B3B = new Function(_0x7A67); //811
                                            _0x7B3B()
                                        } catch (err) {
                                            game[_$_a926[18]] = _$_a926[267] + _0x7A67
                                        }

                                    }

                                }

                            }

                        }

                    }

                }

            }

        }

    }

};
game[_$_a926[4]][_$_a926[44]] = function(_0x7BA5) {
    if (_0x7BA5 == undefined) {
        _0x7BA5 = this[_$_a926[16]][_$_a926[221]][0];
        this[_$_a926[16]][_$_a926[221]][_$_a926[268]](0, 1)
    } else {
        this[_$_a926[16]][_$_a926[16]]++;
        this[_$_a926[16]][_0x7BA5[_$_a926[112]]][_0x7BA5[_$_a926[34]]] = {
            load: false
        };
        if ((_0x7BA5[_$_a926[112]] == _$_a926[45] || _0x7BA5[_$_a926[112]] == _$_a926[13]) && this[_$_a926[16]][_$_a926[269]] != _$_a926[17]) {
            this[_$_a926[16]][_$_a926[221]][_$_a926[270]](_0x7BA5);
            return false
        }

    }
    //824
    if (_0x7BA5[_$_a926[112]] == _$_a926[13]) {
        this[_$_a926[16]][_$_a926[269]] = _0x7BA5[_$_a926[34]];
        var _0x7B70 = document[_$_a926[271]](_$_a926[45]); //838
        _0x7B70[_$_a926[112]] = _$_a926[272];
        if (_0x7BA5[_$_a926[34]] == _$_a926[43]) {
            _0x7B70[_$_a926[273]] = this[_$_a926[3]][_$_a926[112]] + _$_a926[274] + _0x7BA5[_$_a926[275]] + _$_a926[276] + this[_$_a926[3]][_$_a926[28]] + _$_a926[277]
        } else {
            if (_0x7BA5[_$_a926[68]] == true) {
                _0x7B70[_$_a926[273]] = this[_$_a926[3]][_$_a926[112]] + _$_a926[274] + _0x7BA5[_$_a926[275]] + _$_a926[278] + this[_$_a926[3]][_$_a926[279]] + _$_a926[277]
            } else {

            }

        }
        //840
        document[_$_a926[282]](_$_a926[281])[0][_$_a926[280]](_0x7B70);
        _0x7B70[_$_a926[283]] = function() {
            game[_$_a926[16]][_$_a926[284]]++;
            game[_$_a926[16]][_$_a926[269]] = _$_a926[17];
            if (game[_$_a926[16]][_$_a926[221]][0] != undefined) {
                game[_$_a926[44]]()
            }

        };
        _0x7B70[_$_a926[285]] = function() {
            if (game[_$_a926[3]][_$_a926[13]] != _$_a926[286]) {
                var _0x7C0F = window[_$_a926[188]][_$_a926[289]][_$_a926[126]](_$_a926[287] + game[_$_a926[3]][_$_a926[13]], _$_a926[288]); //860
                window[_$_a926[188]] = _0x7C0F;
                console[_$_a926[131]](_0x7C0F)
            }
            //859
            game[_$_a926[18]] = _$_a926[290]
        }

    } else {
        if (_0x7BA5[_$_a926[112]] == _$_a926[45]) {
            if (_0x7BA5[_$_a926[291]] == undefined) {
                _0x7BA5[_$_a926[291]] = _$_a926[17]
            }
            //870
            this[_$_a926[16]][_$_a926[269]] = _0x7BA5[_$_a926[34]];
            var _0x7BDA = document[_$_a926[271]](_$_a926[45]); //874
            _0x7BDA[_$_a926[112]] = _$_a926[272];
            if (_0x7BA5[_$_a926[34]] == _$_a926[27] || _0x7BA5[_$_a926[34]] == _$_a926[14]) {
                if (game[_$_a926[3]][_$_a926[27]] == _$_a926[17]) {
                    _0x7BDA[_$_a926[273]] = game[_$_a926[3]][_$_a926[112]] + _$_a926[292] + _0x7BA5[_$_a926[34]] + _0x7BA5[_$_a926[291]] + _$_a926[293] + this[_$_a926[3]][_$_a926[65]]
                } else {
                    _0x7BDA[_$_a926[273]] = game[_$_a926[3]][_$_a926[112]] + _$_a926[294] + game[_$_a926[3]][_$_a926[27]] + _$_a926[278] + _0x7BA5[_$_a926[34]] + _0x7BA5[_$_a926[291]] + _$_a926[293] + this[_$_a926[3]][_$_a926[65]]
                }

            } else {
                if (_0x7BA5[_$_a926[68]] == true) {
                    _0x7BDA[_$_a926[273]] = game[_$_a926[3]][_$_a926[112]] + _$_a926[292] + _0x7BA5[_$_a926[34]] + _0x7BA5[_$_a926[291]] + _$_a926[293] + this[_$_a926[3]][_$_a926[65]]
                } else {
                    _0x7BDA[_$_a926[273]] = game[_$_a926[3]][_$_a926[112]] + _$_a926[278] + game[_$_a926[3]][_$_a926[279]] + _$_a926[295] + _0x7BA5[_$_a926[34]] + _0x7BA5[_$_a926[291]] + _$_a926[293] + this[_$_a926[3]][_$_a926[65]]
                }

            }
            //876
            document[_$_a926[282]](_$_a926[281])[0][_$_a926[280]](_0x7BDA);
            _0x7BDA[_$_a926[283]] = function() {
                game[_$_a926[16]][_$_a926[284]]++;
                game[_$_a926[16]][_$_a926[45]][_0x7BA5[_$_a926[34]]] = {
                    load: true
                };
                if (_0x7BA5[_$_a926[296]] != undefined) {
                    if (_0x7BA5[_$_a926[296]] != _$_a926[17]) {
                        var _0x7B3B = new Function(_0x7BA5[_$_a926[296]]); //896
                        _0x7B3B()
                    }

                }
                //894
                game[_$_a926[16]][_$_a926[269]] = _$_a926[17];
                if (game[_$_a926[16]][_$_a926[221]][0] != undefined) {
                    game[_$_a926[44]]()
                }

            };
            _0x7BDA[_$_a926[285]] = function() {
                game[_$_a926[18]] = _$_a926[297] + _0x7BA5[_$_a926[34]]
            }

        }

    }
    //836
    if (_0x7BA5[_$_a926[112]] == _$_a926[198]) {
        _0x7BA5[_$_a926[298]] = this[_$_a926[3]][_$_a926[112]] + _$_a926[278] + this[_$_a926[3]][_$_a926[279]] + _$_a926[278] + _0x7BA5[_$_a926[298]];
        var _0x66BC = new PIXI[_$_a926[300]][_$_a926[299]](); //912
        _0x66BC[_$_a926[106]](_0x7BA5[_$_a926[34]], _0x7BA5[_$_a926[298]]);
        _0x66BC[_$_a926[302]](_$_a926[301], function(_0x69A2) {
            game[_$_a926[16]][_$_a926[284]]++
        });
        _0x66BC[_$_a926[67]]()
    } else {
        if (_0x7BA5[_$_a926[112]] == _$_a926[303] || _0x7BA5[_$_a926[112]] == _$_a926[304] || _0x7BA5[_$_a926[112]] == _$_a926[239]) {
            if (_0x7BA5[_$_a926[305]] != undefined) {
                var _0x66BC = new PIXI[_$_a926[300]][_$_a926[299]](); //922
                for (var _0x696D = 0; _0x696D < _0x7BA5[_$_a926[305]][_$_a926[76]]; _0x696D++) {
                    _0x7BA5[_$_a926[305]][_0x696D] = this[_$_a926[3]][_$_a926[112]] + _$_a926[278] + this[_$_a926[3]][_$_a926[279]] + _$_a926[278] + _0x7BA5[_$_a926[305]][_0x696D];
                    _0x66BC[_$_a926[106]](_0x7BA5[_$_a926[34]] + _$_a926[17] + _0x696D, _0x7BA5[_$_a926[305]][_0x696D])
                }
                //923
                _0x66BC[_$_a926[67]](function(_0x69A2) {
                    game[_$_a926[16]][_$_a926[284]]++;
                    if (_0x7BA5[_$_a926[112]] == _$_a926[304]) {
                        _0x69A2[_$_a926[3]] = {
                            name: _0x7BA5[_$_a926[34]],
                            files: _0x7BA5[_$_a926[305]],
                            width: _0x7BA5[_$_a926[21]],
                            height: _0x7BA5[_$_a926[22]]
                        };
                        engine[_$_a926[306]](_0x69A2)
                    }

                });
                return
            }
            //921
            _0x7BA5[_$_a926[298]] = this[_$_a926[3]][_$_a926[112]] + _$_a926[278] + this[_$_a926[3]][_$_a926[279]] + _$_a926[278] + _0x7BA5[_$_a926[298]];
            var _0x66BC = new PIXI[_$_a926[300]][_$_a926[299]](); //942
            _0x66BC[_$_a926[106]](_0x7BA5[_$_a926[34]], _0x7BA5[_$_a926[298]]);
            _0x66BC[_$_a926[67]](function(_0x69A2) {
                game[_$_a926[16]][_$_a926[284]]++;
                if (_0x7BA5[_$_a926[112]] == _$_a926[303]) {
                    game[_$_a926[15]][_0x7BA5[_$_a926[34]]] = PIXI[_$_a926[308]][_$_a926[307]](_0x7BA5[_$_a926[298]]);
                    game[_$_a926[15]][_0x7BA5[_$_a926[34]]][_$_a926[3]] = {
                        name: _0x7BA5[_$_a926[34]],
                        width: _0x7BA5[_$_a926[21]],
                        height: _0x7BA5[_$_a926[22]]
                    }
                } else {
                    if (_0x7BA5[_$_a926[112]] == _$_a926[304]) {
                        _0x69A2[_$_a926[3]] = {
                            name: _0x7BA5[_$_a926[34]],
                            file: _0x7BA5[_$_a926[298]],
                            width: _0x7BA5[_$_a926[21]],
                            height: _0x7BA5[_$_a926[22]]
                        };
                        engine[_$_a926[306]](_0x69A2)
                    } else {
                        if (_0x7BA5[_$_a926[112]] == _$_a926[239]) {
                            game[_$_a926[16]][_$_a926[239]][_0x7BA5[_$_a926[34]]] = PIXI[_$_a926[210]][_$_a926[309]](_0x7BA5[_$_a926[34]])
                        }

                    }

                }
                //946
                if (_0x7BA5[_$_a926[296]] != undefined) {
                    if (_0x7BA5[_$_a926[296]] != _$_a926[17]) {
                        var _0x7B3B = new Function(_0x7BA5[_$_a926[296]]); //970
                        _0x7B3B()
                    }

                }

            });
            _0x66BC[_$_a926[67]]()
        } else {
            if (_0x7BA5[_$_a926[112]] == _$_a926[310]) {
                game[_$_a926[16]][_$_a926[284]]++;
                if (_0x7BA5[_$_a926[68]] == true) {
                    $(_$_a926[312] + _0x7BA5[_$_a926[34]] + _$_a926[313] + game[_$_a926[3]][_$_a926[112]] + _$_a926[314] + _0x7BA5[_$_a926[298]] + _$_a926[315])[_$_a926[311]](_$_a926[281])
                } else {
                    $(_$_a926[312] + _0x7BA5[_$_a926[34]] + _$_a926[313] + game[_$_a926[3]][_$_a926[112]] + _$_a926[278] + game[_$_a926[3]][_$_a926[279]] + _$_a926[278] + _0x7BA5[_$_a926[298]] + _$_a926[315])[_$_a926[311]](_$_a926[281])
                }
                //984
                var _0x6E30 = new PIXI[_$_a926[172]](_0x7BA5[_$_a926[34]], {
                    fontFamily: _0x7BA5[_$_a926[34]],
                    fontSize: 1
                }); //989
                _0x6E30[_$_a926[36]][_$_a926[35]] = -10;
                _0x6E30[_$_a926[36]][_$_a926[37]] = -10;
                game[_$_a926[24]][_$_a926[42]](_0x6E30)
            }

        }

    }

};
game[_$_a926[4]][_$_a926[306]] = function(_0x67C5) {
    if (_0x67C5[_$_a926[3]][_$_a926[34]] == _$_a926[316]) {

    }
    //997
    game[_$_a926[15]][_0x67C5[_$_a926[3]][_$_a926[34]]] = PIXI[_$_a926[308]][_$_a926[307]](_0x67C5[_$_a926[3]][_$_a926[298]]);
    game[_$_a926[15]][_0x67C5[_$_a926[3]][_$_a926[34]]][_$_a926[317]] = [];
    var _0x67FA = game[_$_a926[15]][_0x67C5[_$_a926[3]][_$_a926[34]]][_$_a926[318]][_$_a926[21]] / _0x67C5[_$_a926[3]][_$_a926[21]]; //1003
    var _0x682F = game[_$_a926[15]][_0x67C5[_$_a926[3]][_$_a926[34]]][_$_a926[318]][_$_a926[22]] / _0x67C5[_$_a926[3]][_$_a926[22]]; //1004
    var _0x6790 = _0x67FA * _0x682F; //1005
    var _0x6899 = 0; //1007
    var _0x68CE = 0; //1008
    for (var _0x6687 = 1; _0x6687 < _0x6790 + 1; _0x6687++) {
        if (_0x6899 == _0x67FA) {
            _0x6899 = 0;
            _0x68CE++
        }
        //1011
        var _0x6864 = new PIXI[_$_a926[319]](_0x67C5[_$_a926[3]][_$_a926[21]] * _0x6899, _0x67C5[_$_a926[3]][_$_a926[22]] * _0x68CE, _0x67C5[_$_a926[3]][_$_a926[21]], _0x67C5[_$_a926[3]][_$_a926[22]]); //1016
        var _0x6938 = new PIXI[_$_a926[308]](game[_$_a926[15]][_0x67C5[_$_a926[3]][_$_a926[34]]], _0x6864); //1017
        game[_$_a926[15]][_0x67C5[_$_a926[3]][_$_a926[34]]][_$_a926[317]][_$_a926[270]](_0x6938);
        _0x6899++
    }

};
game[_$_a926[4]][_$_a926[320]] = function(_0x69A2) {
    return game[_$_a926[16]][_$_a926[239]][_0x69A2][_$_a926[235]][_$_a926[321]]
};
game[_$_a926[4]][_$_a926[29]] = function() {
    this[_$_a926[3]][_$_a926[132]] = _$_a926[17];
    this[_$_a926[3]][_$_a926[50]] = false;
    if (navigator[_$_a926[323]][_$_a926[150]](_$_a926[322]) > 0) {
        this[_$_a926[3]][_$_a926[132]] = _$_a926[322];
        this[_$_a926[3]][_$_a926[50]] = true
    } else {
        if (navigator[_$_a926[323]][_$_a926[150]](_$_a926[133]) > 0) {
            this[_$_a926[3]][_$_a926[132]] = _$_a926[133];
            this[_$_a926[3]][_$_a926[50]] = true
        } else {
            if (navigator[_$_a926[323]][_$_a926[150]](_$_a926[134]) > 0) {
                this[_$_a926[3]][_$_a926[132]] = _$_a926[134];
                this[_$_a926[3]][_$_a926[50]] = true
            }

        }

    }

};
game[_$_a926[4]][_$_a926[49]] = function(_0x69A2) {
    console[_$_a926[85]](_0x69A2);
    if (_0x69A2 == 32) {
        if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[213]] != undefined) {
            if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[213]][_$_a926[324]] == true && buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[213]][_$_a926[156]] == _$_a926[56]) {
                game[_$_a926[222]]()
            }

        } else {
            if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[216]] != undefined) {
                if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[216]][_$_a926[324]] == true && buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[216]][_$_a926[156]] == _$_a926[56]) {
                    game[_$_a926[212]]()
                }

            }

        }

    } else {
        if (_0x69A2 == 38) {
            if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[159]] != undefined) {
                if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[159]][_$_a926[324]] == true && buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[159]][_$_a926[156]] == _$_a926[56]) {
                    game[_$_a926[145]](_$_a926[153], _$_a926[152])
                }

            }

        } else {
            if (_0x69A2 == 40) {
                if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[160]] != undefined) {
                    if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[160]][_$_a926[324]] == true && buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[160]][_$_a926[156]] == _$_a926[56]) {
                        game[_$_a926[145]](_$_a926[153], _$_a926[325])
                    }

                }

            } else {
                if (_0x69A2 == 37) {
                    if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[158]] != undefined) {
                        if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[158]][_$_a926[324]] == true && buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[158]][_$_a926[156]] == _$_a926[56]) {
                            game[_$_a926[145]](_$_a926[148], _$_a926[325])
                        }

                    }

                } else {
                    if (_0x69A2 == 39) {
                        if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[155]] != undefined) {
                            if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[155]][_$_a926[324]] == true && buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[155]][_$_a926[156]] == _$_a926[56]) {
                                game[_$_a926[145]](_$_a926[148], _$_a926[152])
                            }

                        }

                    } else {
                        if (_0x69A2 == 27) {
                            if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[326]] != undefined) {
                                if (buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[326]][_$_a926[324]] == true && buttons[_$_a926[96]][game[_$_a926[10]]][_$_a926[326]][_$_a926[156]] == _$_a926[56]) {
                                    game[_$_a926[183]]()
                                }

                            }

                        }

                    }

                }

            }

        }

    }

};

function game() {

}
var game = new game(); //1085
$(window)[_$_a926[327]](function() {
    game[_$_a926[30]]()
});
document[_$_a926[20]](_$_a926[19])[_$_a926[51]] = function(_0x69A2) {
    window[_$_a926[328]]()
}