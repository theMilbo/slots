game.settingMobileConfig={
	tabName:{x:640,y:20,textSize:40},
	tabLine_1:{x:265,y:80},
	
	tabs:['settingSpin','settingBet'],
	
	G1:{x:0,y:130},
	G2:{x:0,y:250},
	
}
/*--------------------------------------------------------------------------------------------*/
game.settingMobile=function() {
console.info('settingMobile');
if(this.containers['settingMobile']==undefined){
	//-----------------------------------------------
	this.containers['settingMobile']={
		container:'',
		elements:{},
		x:0,
		y:0
	};
	this.containers['settingMobile']['container'] = new PIXI.Container();
	this.containers['settingMobile']['container'].name = 'settingMobile';
	this.containers['settingMobile']['container'].position.x = 0;
	this.containers['settingMobile']['container'].position.y = 0;
	this.containers['settingMobile']['container'].zIndex = 100;
	this.containers['settingMobile']['container'].visible=false;
	this.stage.addChild(this.containers['settingMobile']['container']);
	
	this.containers['settingMobile']['elements']['mask'] = new PIXI.Graphics()
	this.containers['settingMobile']['elements']['mask'].zIndex = 99;
	this.containers['settingMobile']['elements']['mask'].name="mask";
	this.containers['settingMobile']['elements']['mask'].position.x = 0;
	this.containers['settingMobile']['elements']['mask'].position.y = 0;
	this.containers['settingMobile']['elements']['mask'].beginFill(0x000000);
	this.containers['settingMobile']['elements']['mask'].alpha=1;
	this.containers['settingMobile']['elements']['mask'].drawRect(0, 0, 1280,680);
	this.containers['settingMobile']['container'].addChild(this.containers['settingMobile']['elements']['mask']);	
	
	TEMP=this.containers['settingMobile']['elements'];
	
	//-----------------------------------------------
	//-----------------------------------------------
	//-----------------------------------------------
	// TAB BET
	TEMP['settingBet'] = new PIXI.Container();
	TEMP['settingBet'].name = 'settingBet';
	TEMP['settingBet'].position.x = 0;
	TEMP['settingBet'].position.y = 0;
	TEMP['settingBet'].zIndex = 100;
	//TEMP['settingBet'].visible=false;
	this.containers['settingMobile']['container'].addChild(TEMP['settingBet']);
	//--------------------
	var TTT = new PIXI.Text(game.language.setting['tab_bet'],{ 
		font:this.settingMobileConfig['tabName']['textSize']+'px PartnerLightCondensed', 
		fill:'#FFFFFF',
		align:'center'
	});
	TTT.x = this.settingMobileConfig['tabName']['x'];
	TTT.y = this.settingMobileConfig['tabName']['y'];
	TTT.position.x-=TTT.width/2	
	TEMP['settingBet'].addChild(TTT);
	//--------------------
	var TTT = new PIXI.Sprite(game.texture['setting_1']);
	TTT.x = this.settingMobileConfig['tabLine_1']['x'];
	TTT.y = this.settingMobileConfig['tabLine_1']['y'];
	TEMP['settingBet'].addChild(TTT);
	//--------------------
	var TTT = new PIXI.Text(game.language['lines'],{ 
		font:this.settingMobileConfig['tabName']['textSize']+'px PartnerLightCondensed', 
		fill:'#FFFFFF',
		align:'center'
	});
	TTT.x = 200;
	TTT.y = this.settingMobileConfig['G1']['y'];
	TEMP['settingBet'].addChild(TTT);
	var TTT = new PIXI.Text(game.language['betPerLine'],{ 
		font:this.settingMobileConfig['tabName']['textSize']+'px PartnerLightCondensed', 
		fill:'#FFFFFF',
		align:'center'
	});
	TTT.x = 200;
	TTT.y = this.settingMobileConfig['G2']['y'];
	TEMP['settingBet'].addChild(TTT);
	
	buttons.status['normal']['lineMinus']={display:true,state:'normal'};
	buttons.status['normal']['linePlus']={display:true,state:'normal'};
	buttons.status['normal']['betLinePlus']={display:true,state:'normal'};
	buttons.status['normal']['betLineMinus']={display:true,state:'normal'};
	buttons.status['spin_OR_gamble']['lineMinus']={display:true,state:'normal'};
	buttons.status['spin_OR_gamble']['linePlus']={display:true,state:'normal'};
	buttons.status['spin_OR_gamble']['betLinePlus']={display:true,state:'normal'};
	buttons.status['spin_OR_gamble']['betLineMinus']={display:true,state:'normal'};	

	buttons.add([
	{
		name:'lineMinus',
		textures:[0,'setting_3','setting_3','setting_3','setting_3'],
		onclick:'game.changeBet("lines","minus")',
		clickAudio:'click',
		zIndex:99,
		//scale:2,
		x:500,y:this.settingMobileConfig['G1']['y'],w:50,h:50,
	},
	{
		name:'linePlus',
		textures:[0,'setting_2','setting_2','setting_2','setting_2'],
		onclick:'game.changeBet("lines","plus")',
		clickAudio:'click',
		zIndex:99,
		//scale:2,
		x:800,y:this.settingMobileConfig['G1']['y'],w:50,h:50,
	},
	{
		name:'betLineMinus',
		textures:[0,'setting_3','setting_3','setting_3','setting_3'],
		onclick:'game.changeBet("bet","minus")',
		clickAudio:'click',
		zIndex:99,
		//scale:2,
		x:500,y:this.settingMobileConfig['G2']['y'],w:50,h:50,
	},
	{
		name:'betLinePlus',
		textures:[0,'setting_2','setting_2','setting_2','setting_2'],
		onclick:'game.changeBet("bet","plus")',
		clickAudio:'click',
		zIndex:99,
		//scale:2,
		x:800,y:this.settingMobileConfig['G2']['y'],w:50,h:50,
	}
	],TEMP['settingBet']);
	
	
	var res=game.textAdd({
		key:'betPerLine',
		text:game.getCash(game.config['betInfo']['bet']),
		x:680,
		y:this.settingMobileConfig['G2']['y'],
		style:{ font: '40px PartnerLightCondensed', fill:'#FFFFFF',align:'center'},
		stage:0
	});
	TEMP['settingBet'].addChild(res);	
	var res=game.textAdd({
		key:'lines',
		text:game.config['betInfo']['lines'],
		x:680,
		y:this.settingMobileConfig['G1']['y'],
		style:{ font: '40px PartnerLightCondensed', fill:'#FFFFFF',align:'center'},
		stage:0
	});
	TEMP['settingBet'].addChild(res);	
	
	//--------------------
	
	
	//-----------------------------------------------
	//-----------------------------------------------
	//-----------------------------------------------
	// TAB SPIN
	TEMP['settingSpin'] = new PIXI.Container();
	TEMP['settingSpin'].name = 'settingSpin';
	TEMP['settingSpin'].position.x = 0;
	TEMP['settingSpin'].position.y = 0;
	TEMP['settingSpin'].zIndex = 100;
	TEMP['settingSpin'].visible=false;
	this.containers['settingMobile']['container'].addChild(TEMP['settingSpin']);
	//--------------------
	var TTT = new PIXI.Text(game.language.setting['tab_spin'],{ 
		font:this.settingMobileConfig['tabName']['textSize']+'px PartnerLightCondensed', 
		fill:'#FFFFFF',
		align:'center'
	});
	TTT.x = this.settingMobileConfig['tabName']['x'];
	TTT.y = this.settingMobileConfig['tabName']['y'];
	TTT.position.x-=TTT.width/2	
	TEMP['settingSpin'].addChild(TTT);
	//--------------------
	var TTT = new PIXI.Sprite(game.texture['setting_1']);
	TTT.x = this.settingMobileConfig['tabLine_1']['x'];
	TTT.y = this.settingMobileConfig['tabLine_1']['y'];
	TEMP['settingSpin'].addChild(TTT);
	//-----------------------------------------------
	buttons.status['normal']['button_setting_spin']={display:true,state:'normal'};
	buttons.status['normal']['button_setting_bet']={display:true,state:'normal'};
	buttons.status['normal']['settingClose']={display:true,state:'normal'};
	buttons.status['spin_OR_gamble']['button_setting_spin']={display:true,state:'normal'};
	buttons.status['spin_OR_gamble']['button_setting_bet']={display:true,state:'normal'};
	buttons.status['spin_OR_gamble']['settingClose']={display:true,state:'normal'};
	buttons.add([
		{
			name:'settingClose',
			textures:[0,'button_setting_close','button_setting_close','button_setting_close','button_setting_close'],
			onclick:'game.settingMobile()',
			clickAudio:'click',
			zIndex:99,
			scale:1.5,
			x:1100+80,y:610,w:55,h:40,
		},
		{
			name:'button_setting_bet',
			textures:[0,'button_setting_bet','button_setting_bet','button_setting_bet','button_setting_bet'],
			onclick:'game.settingMobileShowTab("settingBet")',
			clickAudio:'click',
			zIndex:99,
			scale:1.5,
			x:200,y:610,w:68,h:40,
		},
		{
			name:'button_setting_spin',
			textures:[0,'button_setting_spin','button_setting_spin','button_setting_spin','button_setting_spin'],
			onclick:'game.settingMobileShowTab("settingSpin")',
			clickAudio:'click',
			zIndex:99,
			scale:1.5,
			x:200+150,y:610,w:68,h:40,
		}
	],this.containers['settingMobile']['container']);
	this.containers['settingMobile']['elements']=TEMP;
	
	//console.info(this.containers['settingMobile']['container'])
	//-----------------------------------------------
}	
console.info('lll');
if(this.containers['settingMobile']['container'].visible==false){
	this.containers['settingMobile']['container'].visible=true;
	buttons.disableExclusion=['settingClose','button_setting_bet','button_setting_spin','lineMinus','linePlus','betLinePlus','betLineMinus'];
	buttons.disableAll=true;
	buttons.statusUpdate=true;
}else{
	buttons.disableExclusion=[];
	buttons.disableAll=false;
	buttons.statusUpdate=true;
	this.containers['settingMobile']['container'].visible=false;
}
}
/*--------------------------------------------------------------------------------------------*/
game.settingMobileShowTab=function(tab) {
//console.info(tab);
for(var i=0;i<this.settingMobileConfig.tabs.length;i++){
	this.containers['settingMobile']['elements'][this.settingMobileConfig.tabs[i]].visible=false;
	if(tab==this.settingMobileConfig.tabs[i]){
		this.containers['settingMobile']['elements'][this.settingMobileConfig.tabs[i]].visible=true;
	}
}	
}
/*--------------------------------------------------------------------------------------------*/