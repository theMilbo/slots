/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_53de=["\x64\x65\x62\x75\x67","\x67\x61\x6D\x62\x6C\x65\x2E\x6A\x73\x20\x4C\x4F\x41\x44\x45\x44","\x69\x6E\x66\x6F","\x62\x75\x74\x74\x6F\x6E\x73\x41\x63\x74\x69\x6F\x6E\x73","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65","\x6E\x6F\x72\x6D\x61\x6C","\x62\x75\x74\x74\x6F\x6E\x73\x41\x72\x72\x61\x79","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x41\x42\x43","\x67\x61\x6D\x62\x6C\x65\x5F\x63\x6C\x75\x62\x5F\x31","\x67\x61\x6D\x62\x6C\x65\x5F\x63\x6C\x75\x62\x5F\x32","\x67\x61\x6D\x62\x6C\x65\x5F\x63\x6C\x75\x62\x5F\x33","\x67\x61\x6D\x62\x6C\x65\x5F\x63\x6C\x75\x62\x5F\x34","\x67\x61\x6D\x62\x6C\x65\x2E\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E\x28\x22\x63\x6C\x75\x62\x22\x29","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x41\x42\x53","\x67\x61\x6D\x62\x6C\x65\x5F\x73\x70\x61\x64\x65\x5F\x31","\x67\x61\x6D\x62\x6C\x65\x5F\x73\x70\x61\x64\x65\x5F\x32","\x67\x61\x6D\x62\x6C\x65\x5F\x73\x70\x61\x64\x65\x5F\x33","\x67\x61\x6D\x62\x6C\x65\x5F\x73\x70\x61\x64\x65\x5F\x34","\x67\x61\x6D\x62\x6C\x65\x2E\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E\x28\x22\x73\x70\x61\x64\x65\x22\x29","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x41\x52\x48","\x67\x61\x6D\x62\x6C\x65\x5F\x68\x65\x61\x72\x74\x5F\x31","\x67\x61\x6D\x62\x6C\x65\x5F\x68\x65\x61\x72\x74\x5F\x32","\x67\x61\x6D\x62\x6C\x65\x5F\x68\x65\x61\x72\x74\x5F\x33","\x67\x61\x6D\x62\x6C\x65\x5F\x68\x65\x61\x72\x74\x5F\x34","\x67\x61\x6D\x62\x6C\x65\x2E\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E\x28\x22\x68\x65\x61\x72\x74\x22\x29","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x41\x52\x44","\x67\x61\x6D\x62\x6C\x65\x5F\x64\x69\x61\x6D\x6F\x6E\x64\x5F\x31","\x67\x61\x6D\x62\x6C\x65\x5F\x64\x69\x61\x6D\x6F\x6E\x64\x5F\x32","\x67\x61\x6D\x62\x6C\x65\x5F\x64\x69\x61\x6D\x6F\x6E\x64\x5F\x33","\x67\x61\x6D\x62\x6C\x65\x5F\x64\x69\x61\x6D\x6F\x6E\x64\x5F\x34","\x67\x61\x6D\x62\x6C\x65\x2E\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E\x28\x22\x64\x69\x61\x6D\x6F\x6E\x64\x22\x29","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x72\x65\x64","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x31","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x32","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x33","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x34","\x67\x61\x6D\x62\x6C\x65\x2E\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E\x28\x22\x72\x65\x64\x22\x29","\x72\x65\x64","\x48\x65\x6C\x76\x65\x74\x69\x63\x61","\x63\x65\x6E\x74\x65\x72","\x62\x6F\x6C\x64","\x23\x64\x36\x33\x35\x33\x34","\x23\x63\x63\x63","\x50\x49","\x54\x65\x78\x74\x53\x74\x79\x6C\x65","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x62\x6C\x61\x63\x6B","\x67\x61\x6D\x62\x6C\x65\x2E\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E\x28\x22\x62\x6C\x61\x63\x6B\x22\x29","\x62\x6C\x61\x63\x6B","\x23\x30\x30\x30\x30\x30\x30","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x75\x74\x74\x6F\x6E\x5F\x74\x61\x6B\x65\x57\x69\x6E","\x67\x61\x6D\x62\x6C\x65\x2E\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E\x28\x22\x74\x61\x6B\x65\x57\x69\x6E\x22\x29","\x74\x61\x6B\x65\x57\x69\x6E","\x6C\x61\x73\x74\x43\x61\x72\x64","","\x73\x65\x6C\x65\x63\x74\x43\x6F\x6C\x6F\x72","\x74\x69\x6D\x65\x53\x68\x6F\x77\x52\x65\x73\x75\x6C\x74","\x73\x6F\x75\x6E\x64\x50\x61\x79","\x73\x68\x6F\x77\x43\x61\x72\x64","\x6D\x61\x69\x6E\x43\x61\x72\x64","\x67\x61\x6D\x62\x6C\x65\x5F\x63\x61\x72\x64\x5F\x6D\x61\x69\x6E","\x62\x75\x74\x74\x6F\x6E\x73\x41\x64\x64\x65\x64","\x67\x61\x6D\x62\x6C\x65\x53\x6D\x61\x6C\x43\x61\x72\x64\x73","\x75\x70\x64\x61\x74\x65","\x63\x61\x72\x64\x73","\x73\x74\x6F\x70","\x74\x65\x78\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73","\x66\x75\x6C\x6C\x5F\x67\x61\x6D\x62\x6C\x65\x5F\x73\x65\x6C\x65\x63\x74\x65\x64","\x23\x46\x46\x46\x46\x46\x46","\x67\x61\x6D\x62\x6C\x65\x5F\x61\x6D\x6F\x75\x6E\x74","\x68\x69\x73\x74\x6F\x72\x79","\x73\x75\x69\x74\x5F\x67\x61\x6D\x62\x6C\x65","\x72\x65\x64\x5F\x62\x6C\x61\x63\x6B\x5F\x67\x61\x6D\x62\x6C\x65","\x74\x6F\x5F\x77\x69\x6E","\x61\x6D\x6F\x75\x6E\x74\x5F\x67\x61\x6D\x62\x6C\x65","\x23\x65\x32\x37\x61\x30\x30","\x23\x66\x65\x66\x62\x30\x30","\x23\x64\x66\x62\x38\x32\x37","\x61\x6D\x6F\x75\x6E\x74\x5F\x58\x34","\x61\x6D\x6F\x75\x6E\x74\x5F\x58\x32","\x67\x6F\x6F\x64\x4C\x75\x63\x6B","\x65\x6C\x65\x6D\x65\x6E\x74\x73","\x69\x6E\x69\x74","\x67\x61\x6D\x62\x6C\x65\x2E\x69\x6E\x69\x74","\x73\x74\x61\x67\x65","\x43\x6F\x6E\x74\x61\x69\x6E\x65\x72","\x6E\x61\x6D\x65","\x67\x61\x6D\x62\x6C\x65\x73\x53\x74\x61\x67\x65","\x78","\x70\x6F\x73\x69\x74\x69\x6F\x6E","\x79","\x7A\x49\x6E\x64\x65\x78","\x61\x64\x64\x43\x68\x69\x6C\x64","\x67\x61\x6D\x62\x6C\x65\x5F\x62\x61\x63\x6B\x67\x72\x6F\x75\x6E\x64","\x74\x65\x78\x74\x75\x72\x65","\x53\x70\x72\x69\x74\x65","\x67\x61\x6D\x62\x6C\x65","\x73\x74\x61\x74\x75\x73","\x65\x78\x74\x65\x6E\x64","\x61\x64\x64","\x63\x61\x72\x64\x5F\x6D\x61\x69\x6E","\x77\x69\x64\x74\x68","\x68\x65\x69\x67\x68\x74","\x77\x69\x6E\x5F\x61\x6E\x69\x6D","\x61\x6E\x69\x6D\x46\x72\x61\x6D\x65\x73","\x67\x61\x6D\x62\x6C\x65\x5F\x77\x69\x6E\x5F\x61\x6E\x69\x6D","\x4D\x6F\x76\x69\x65\x43\x6C\x69\x70","\x65\x78\x74\x72\x61\x73","\x61\x6E\x69\x6D\x61\x74\x69\x6F\x6E\x53\x70\x65\x65\x64","\x63\x6F\x6E\x66\x69\x67","\x76\x69\x73\x69\x62\x6C\x65","\x6C\x6F\x6F\x70","\x6F\x6E\x43\x6F\x6D\x70\x6C\x65\x74\x65","\x62\x75\x74\x74\x6F\x6E\x73","\x6C\x61\x73\x74\x43\x61\x72\x64\x41\x72\x72\x61\x79","\x6C\x65\x6E\x67\x74\x68","\x6C\x61\x73\x74\x43\x61\x72\x64\x50\x6F\x73\x69\x74\x69\x6F\x6E\x73","\x6C\x6F\x67","\x67\x61\x6D\x62\x6C\x65\x5F\x63\x61\x72\x64\x5F\x63\x6C\x75\x62\x5F\x32","\x50\x61\x72\x74\x6E\x65\x72\x4C\x69\x67\x68\x74\x43\x6F\x6E\x64\x65\x6E\x73\x65\x64","\x66\x6F\x6E\x74\x53\x69\x7A\x65","\x66\x69\x6C\x6C","\x6B\x65\x79","\x6C\x61\x6E\x67\x75\x61\x67\x65","\x74\x65\x78\x74\x41\x64\x64","\x67\x61\x6D\x62\x6C\x65\x53\x74\x61\x72\x74","\x67\x61\x6D\x62\x6C\x65\x20\x53\x54\x41\x52\x54","\x73\x6F\x75\x6E\x64\x5F\x77\x69\x6E\x53\x6F\x75\x6E\x64\x5F","\x73\x65\x67\x6D\x65\x6E\x74\x73\x41\x63\x74\x69\x76","\x61\x75\x64\x69\x6F","\x72\x65\x73\x6F\x75\x72\x63\x65\x73","\x61\x63\x74\x69\x6F\x6E","\x73\x6F\x72\x74\x53\x74\x61\x67\x65","\x77\x69\x6E","\x67\x65\x74\x43\x61\x73\x68","\x74\x65\x78\x74\x55\x70\x64\x61\x74\x65","\x75\x70\x64\x61\x74\x65\x4C\x61\x73\x74\x43\x61\x72\x64","\x63\x6F\x6E\x74\x65\x6E\x74","\x72\x65\x73\x70\x6F\x6E\x73\x65","\x67\x61\x6D\x62\x6C\x65\x5F\x63\x61\x72\x64\x5F","\x5F\x32","\x61\x6E\x73\x77\x65\x72\x73\x57\x6F\x72\x6B","\x63\x6D\x64","\x67\x61\x6D\x65\x47\x61\x6D\x62\x6C\x65","\x73\x75\x63\x63\x65\x73\x73","\x63\x61\x72\x64","\x5F\x31","\x62\x61\x6C\x61\x6E\x63\x65","\x70\x6C\x61\x79","\x73\x6F\x75\x6E\x64\x5F\x67\x61\x6D\x62\x6C\x65\x5F\x6C\x6F\x73\x65","\x72\x65\x73\x65\x74\x41\x6E\x64\x43\x6C\x6F\x73\x65","\x73\x6F\x75\x6E\x64\x5F\x67\x61\x6D\x62\x6C\x65\x5F\x77\x69\x6E","\x67\x6F\x74\x6F\x41\x6E\x64\x50\x6C\x61\x79","\x64\x69\x73\x61\x62\x6C\x65","\x73\x74\x61\x74\x65\x53\x65\x74","\x64\x69\x73\x61\x62\x6C\x65\x41\x6C\x6C","\x64\x69\x73\x61\x62\x6C\x65\x45\x78\x63\x6C\x75\x73\x69\x6F\x6E","\x66\x75\x6C\x6C\x53\x63\x72\x65\x65\x6E","\x63\x6C\x6F\x73\x65","\x61\x63\x74\x69\x6F\x6E\x42\x75\x74\x74\x6F\x6E","\x67\x61\x6D\x65\x54\x61\x6B\x65\x57\x69\x6E","\x73\x65\x73\x73\x69\x6F\x6E\x49\x64","\x73\x65\x6E\x64","\x63\x6F\x6C\x6F\x72\x20","\x77\x69\x6E\x4C\x69\x6E\x65\x73\x53\x74\x61\x67\x65"];
if(game[_$_53de[0]]== true)
{
	console[_$_53de[2]](_$_53de[1])
}
//4
gamble[_$_53de[4]][_$_53de[3]]= {gamble_button_ABC:{display:true,state:_$_53de[5],blinking:true},gamble_button_ABS:{display:true,state:_$_53de[5],blinking:true},gamble_button_ARH:{display:true,state:_$_53de[5],blinking:true},gamble_button_ARD:{display:true,state:_$_53de[5],blinking:true},gamble_button_black:{display:true,state:_$_53de[5],blinking:true},gamble_button_red:{display:true,state:_$_53de[5],blinking:true},gamble_button_takeWin:{display:true,state:_$_53de[5],blinking:true}};gamble[_$_53de[4]][_$_53de[6]]= [{name:_$_53de[7],textures:[0,_$_53de[8],_$_53de[9],_$_53de[10],_$_53de[11]],onclick:_$_53de[12],zIndex:99,x:822,y:440,w:174,h:109},{name:_$_53de[13],textures:[0,_$_53de[14],_$_53de[15],_$_53de[16],_$_53de[17]],onclick:_$_53de[18],zIndex:99,x:1006,y:440,w:174,h:109},{name:_$_53de[19],textures:[0,_$_53de[20],_$_53de[21],_$_53de[22],_$_53de[23]],onclick:_$_53de[24],zIndex:99,x:100,y:440,w:174,h:109},{name:_$_53de[25],textures:[0,_$_53de[26],_$_53de[27],_$_53de[28],_$_53de[29]],onclick:_$_53de[30],zIndex:99,x:280,y:440,w:174,h:109},{name:_$_53de[31],textures:[0,_$_53de[32],_$_53de[33],_$_53de[34],_$_53de[35]],onclick:_$_53de[36],text:{key:_$_53de[37],size:50,x:0,y:-5,style: new PIXI[_$_53de[44]]({fontFamily:_$_53de[38],fontSize:50,align:_$_53de[39],fontWeight:_$_53de[40],fill:_$_53de[41],dropShadow:true,dropShadowColor:_$_53de[42],dropShadowBlur:2,dropShadowAngle:Math[_$_53de[43]]/ 3,dropShadowDistance:2})},zIndex:99,x:100,y:300,w:358,h:107},{name:_$_53de[45],textures:[0,_$_53de[32],_$_53de[33],_$_53de[34],_$_53de[35]],onclick:_$_53de[46],zIndex:99,text:{key:_$_53de[47],size:50,x:0,y:-5,style: new PIXI[_$_53de[44]]({fontFamily:_$_53de[38],fontSize:50,align:_$_53de[39],fontWeight:_$_53de[40],fill:_$_53de[48],dropShadow:true,dropShadowColor:_$_53de[42],dropShadowBlur:2,dropShadowAngle:Math[_$_53de[43]]/ 3,dropShadowDistance:2})},x:822,y:300,w:358,h:107},{name:_$_53de[49],textures:[0,_$_53de[32],_$_53de[33],_$_53de[34],_$_53de[35]],onclick:_$_53de[50],text:{key:_$_53de[51],size:40,x:0,y:-5,style: new PIXI[_$_53de[44]]({fontFamily:_$_53de[38],fontSize:40,align:_$_53de[39],fontWeight:_$_53de[40],fill:_$_53de[48],dropShadow:true,dropShadowColor:_$_53de[42],dropShadowBlur:2,dropShadowAngle:Math[_$_53de[43]]/ 3,dropShadowDistance:2})},zIndex:99,scale:0.8,x:640- 145,y:580,w:358,h:107}];gamble[_$_53de[4]][_$_53de[52]]= [_$_53de[53]];gamble[_$_53de[4]][_$_53de[54]]= _$_53de[53];gamble[_$_53de[4]][_$_53de[55]]= 30;gamble[_$_53de[4]][_$_53de[56]]= false;gamble[_$_53de[4]][_$_53de[57]]= _$_53de[53];gamble[_$_53de[4]][_$_53de[58]]= _$_53de[59];gamble[_$_53de[4]][_$_53de[60]]= false;gamble[_$_53de[4]][_$_53de[61]]= false;gamble[_$_53de[4]][_$_53de[62]]= true;gamble[_$_53de[4]][_$_53de[63]]= {prefix:_$_53de[53],card_main:{width:280,height:350,x:640- 140,y:200,act:_$_53de[64],step:8},size:{ow:173,oh:251,w:54,h:77.1},smal_size:{ow:33,oh:34,w:33,h:33},lastCardPositions:[{x:970,y:61},{x:1010,y:61},{x:1050,y:61},{x:1090,y:61},{x:1130,y:61}]};gamble[_$_53de[4]][_$_53de[65]]= [{key:_$_53de[66],x:270,y:55,textAlign:_$_53de[39],fontSize:36,fill:_$_53de[67],stroke:_$_53de[53]},{key:_$_53de[68],x:280,y:120,textAlign:_$_53de[39],fontSize:36,fill:_$_53de[67],stroke:_$_53de[53]},{key:_$_53de[69],x:900,y:55,textAlign:_$_53de[39],fontSize:36,fill:_$_53de[67],stroke:_$_53de[53]},{key:_$_53de[70],x:890,y:120,textAlign:_$_53de[39],fontSize:36,fill:_$_53de[67],stroke:_$_53de[53]},{key:_$_53de[71],x:1110,y:120,textAlign:_$_53de[39],fontSize:36,fill:_$_53de[67],stroke:_$_53de[53]},{key:_$_53de[72],x:890,y:160,textAlign:_$_53de[39],fontSize:36,fill:_$_53de[67],stroke:_$_53de[53]},{key:_$_53de[72],x:1110,y:160,textAlign:_$_53de[39],fontSize:36,fill:_$_53de[67],stroke:_$_53de[53]},{key:_$_53de[73],x:280,y:220,textAlign:_$_53de[39],fontSize:55,fill:[_$_53de[74],_$_53de[75],_$_53de[76]],stroke:_$_53de[53]},{key:_$_53de[77],x:890,y:220,textAlign:_$_53de[39],fontSize:55,fill:[_$_53de[74],_$_53de[75],_$_53de[76]],stroke:_$_53de[53]},{key:_$_53de[78],x:1110,y:220,textAlign:_$_53de[39],fontSize:55,fill:[_$_53de[74],_$_53de[75],_$_53de[76]],stroke:_$_53de[53]},{key:_$_53de[79],x:640,y:0,textAlign:_$_53de[39],fontSize:50,fill:[_$_53de[74],_$_53de[75],_$_53de[76]],stroke:_$_53de[53]}];gamble[_$_53de[4]][_$_53de[80]]= {};gamble[_$_53de[4]][_$_53de[81]]= function()
{
	console[_$_53de[2]](_$_53de[82]);this[_$_53de[83]]=  new PIXI[_$_53de[84]]();this[_$_53de[83]][_$_53de[85]]= _$_53de[86];this[_$_53de[83]][_$_53de[88]][_$_53de[87]]= 0;this[_$_53de[83]][_$_53de[88]][_$_53de[89]]= 0;this[_$_53de[83]][_$_53de[90]]= 90;game[_$_53de[83]][_$_53de[91]](this[_$_53de[83]]);this[_$_53de[83]][_$_53de[91]]( new PIXI[_$_53de[94]](game[_$_53de[93]][_$_53de[92]]));buttons[_$_53de[96]][_$_53de[95]]= $[_$_53de[97]]({},this[_$_53de[3]],buttons[_$_53de[96]][_$_53de[95]]);buttons[_$_53de[98]](this[_$_53de[6]],this[_$_53de[83]]);this[_$_53de[99]]=  new PIXI[_$_53de[94]](game[_$_53de[93]][_$_53de[59]]);this[_$_53de[99]][_$_53de[87]]= gamble[_$_53de[63]][_$_53de[99]][_$_53de[87]];this[_$_53de[99]][_$_53de[89]]= gamble[_$_53de[63]][_$_53de[99]][_$_53de[89]];this[_$_53de[99]][_$_53de[100]]= gamble[_$_53de[63]][_$_53de[99]][_$_53de[100]];this[_$_53de[99]][_$_53de[101]]= gamble[_$_53de[63]][_$_53de[99]][_$_53de[101]];this[_$_53de[83]][_$_53de[91]](this[_$_53de[99]]);this[_$_53de[102]]=  new PIXI[_$_53de[106]][_$_53de[105]](game[_$_53de[93]][_$_53de[104]][_$_53de[103]]);this[_$_53de[102]][_$_53de[87]]= gamble[_$_53de[63]][_$_53de[99]][_$_53de[87]]+ 40;this[_$_53de[102]][_$_53de[89]]= gamble[_$_53de[63]][_$_53de[99]][_$_53de[89]]+ 30;this[_$_53de[102]][_$_53de[107]]= game[_$_53de[108]][_$_53de[107]];this[_$_53de[102]][_$_53de[109]]= false;this[_$_53de[102]][_$_53de[110]]= false;this[_$_53de[102]][_$_53de[111]]= function(_0x17F71)
	{
		gamble[_$_53de[102]][_$_53de[109]]= false;gamble[_$_53de[112]](_$_53de[5])
	}
	;this[_$_53de[83]][_$_53de[91]](this[_$_53de[102]]);this[_$_53de[113]]= [];for(var _0x17DE2=0;_0x17DE2< this[_$_53de[63]][_$_53de[115]][_$_53de[114]];_0x17DE2++)
	{
		console[_$_53de[116]](this[_$_53de[63]][_$_53de[115]][_0x17DE2]);this[_$_53de[113]][_0x17DE2]=  new PIXI[_$_53de[94]](game[_$_53de[93]][_$_53de[117]]);this[_$_53de[113]][_0x17DE2][_$_53de[87]]= this[_$_53de[63]][_$_53de[115]][_0x17DE2][_$_53de[87]];this[_$_53de[113]][_0x17DE2][_$_53de[89]]= this[_$_53de[63]][_$_53de[115]][_0x17DE2][_$_53de[89]];this[_$_53de[113]][_0x17DE2][_$_53de[109]]= false;this[_$_53de[83]][_$_53de[91]](this[_$_53de[113]][_0x17DE2])
	}
	//192
	for(var _0x17DE2=0;_0x17DE2< gamble[_$_53de[65]][_$_53de[114]];_0x17DE2++)
	{
		var _0x18544= new PIXI[_$_53de[44]]({fontFamily:_$_53de[118],fontSize:gamble[_$_53de[65]][_0x17DE2][_$_53de[119]],align:_$_53de[39],fontWeight:_$_53de[40],fill:gamble[_$_53de[65]][_0x17DE2][_$_53de[120]],stroke:_$_53de[48],strokeThickness:1,dropShadow:true,dropShadowColor:_$_53de[48],dropShadowBlur:4,dropShadowAngle:Math[_$_53de[43]]/ 6,dropShadowDistance:4});//202
		game[_$_53de[123]]({key:gamble[_$_53de[65]][_0x17DE2][_$_53de[121]],text:game[_$_53de[122]][gamble[_$_53de[65]][_0x17DE2][_$_53de[121]]],x:gamble[_$_53de[65]][_0x17DE2][_$_53de[87]],y:gamble[_$_53de[65]][_0x17DE2][_$_53de[89]],style:_0x18544,stage:this[_$_53de[83]]})
	}
	
}
;gamble[_$_53de[4]][_$_53de[124]]= function()
{
	console[_$_53de[2]](_$_53de[125]);if(this[_$_53de[83]]== undefined)
	{
		gamble[_$_53de[81]]()
	}
	//230
	game[_$_53de[129]][_$_53de[128]][_$_53de[126]+ reels[_$_53de[127]]][_$_53de[64]]();game[_$_53de[130]]= _$_53de[95];game[_$_53de[131]]();game[_$_53de[134]]({key:_$_53de[73],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[132]])});game[_$_53de[134]]({key:_$_53de[78],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[132]]* 2)});game[_$_53de[134]]({key:_$_53de[77],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[132]]* 4)});this[_$_53de[83]][_$_53de[109]]= true;this[_$_53de[112]](_$_53de[5])
}
;gamble[_$_53de[4]][_$_53de[135]]= function()
{
	this[_$_53de[52]]= game[_$_53de[137]][_$_53de[136]][_$_53de[52]];for(var _0x17DE2=0;_0x17DE2< game[_$_53de[137]][_$_53de[136]][_$_53de[52]][_$_53de[114]];_0x17DE2++)
	{
		if(this[_$_53de[113]][_0x17DE2]!= undefined)
		{
			this[_$_53de[113]][_0x17DE2][_$_53de[93]]= game[_$_53de[93]][_$_53de[138]+ game[_$_53de[137]][_$_53de[136]][_$_53de[52]][_0x17DE2]+ _$_53de[139]];this[_$_53de[113]][_0x17DE2][_$_53de[109]]= true
		}
		
	}
	
}
;gamble[_$_53de[4]][_$_53de[140]]= function()
{
	if(game[_$_53de[137]][_$_53de[136]][_$_53de[141]]== _$_53de[142])
	{
		if(game[_$_53de[137]][_$_53de[96]]== _$_53de[143])
		{
			console[_$_53de[2]](game[_$_53de[137]][_$_53de[136]]);this[_$_53de[135]]();this[_$_53de[99]][_$_53de[93]]= game[_$_53de[93]][_$_53de[138]+ game[_$_53de[137]][_$_53de[136]][_$_53de[144]]+ _$_53de[145]];game[_$_53de[108]][_$_53de[132]]= game[_$_53de[137]][_$_53de[136]][_$_53de[132]];game[_$_53de[108]][_$_53de[146]]= game[_$_53de[137]][_$_53de[136]][_$_53de[146]];game[_$_53de[134]]({key:_$_53de[73],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[132]])});game[_$_53de[134]]({key:_$_53de[78],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[132]]* 2)});game[_$_53de[134]]({key:_$_53de[77],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[132]]* 4)});if(game[_$_53de[108]][_$_53de[132]]== 0)
			{
				this[_$_53de[112]](false);game[_$_53de[129]][_$_53de[128]][_$_53de[148]][_$_53de[147]]();setTimeout(function()
				{
					gamble[_$_53de[149]]()
				}
				,gamble[_$_53de[55]]* 100)
			}
			else 
			{
				game[_$_53de[129]][_$_53de[128]][_$_53de[150]][_$_53de[147]]();this[_$_53de[102]][_$_53de[109]]= true;this[_$_53de[102]][_$_53de[151]](0)
			}
			
		}
		else 
		{
			this[_$_53de[149]]()
		}
		
	}
	else 
	{
		this[_$_53de[149]]()
	}
	
}
;gamble[_$_53de[4]][_$_53de[112]]= function(_0x18655)
{
	if(_0x18655== _$_53de[5]|| _0x18655== _$_53de[152])
	{
		buttons[_$_53de[153]]({key:_$_53de[45],state:_0x18655});buttons[_$_53de[153]]({key:_$_53de[31],state:_0x18655});buttons[_$_53de[153]]({key:_$_53de[49],state:_0x18655});buttons[_$_53de[153]]({key:_$_53de[7],state:_0x18655});buttons[_$_53de[153]]({key:_$_53de[13],state:_0x18655});buttons[_$_53de[153]]({key:_$_53de[19],state:_0x18655});buttons[_$_53de[153]]({key:_$_53de[25],state:_0x18655})
	}
	//285
	if(_0x18655== _$_53de[5])
	{
		buttons[_$_53de[154]]= true;buttons[_$_53de[155]]= [_$_53de[45],_$_53de[31],_$_53de[49],_$_53de[7],_$_53de[13],_$_53de[19],_$_53de[25],_$_53de[156]]
	}
	else 
	{
		if(_0x18655== _$_53de[157])
		{
			buttons[_$_53de[154]]= false;buttons[_$_53de[155]]= []
		}
		
	}
	
}
;gamble[_$_53de[4]][_$_53de[158]]= function(_0x1866A)
{
	this[_$_53de[112]](_$_53de[152]);if(_0x1866A== _$_53de[51])
	{
		this[_$_53de[149]]();game[_$_53de[161]]({cmd:_$_53de[159],session:game[_$_53de[108]][_$_53de[160]]},true)
	}
	else 
	{
		if(this[_$_53de[57]]== false&& game[_$_53de[108]][_$_53de[132]]> 0)
		{
			this[_$_53de[54]]= _0x1866A;if(game[_$_53de[0]]== true)
			{
				console[_$_53de[116]](_$_53de[162]+ _0x1866A)
			}
			//321
			game[_$_53de[161]]({cmd:_$_53de[142],session:game[_$_53de[108]][_$_53de[160]],color:_0x1866A})
		}
		
	}
	
}
;gamble[_$_53de[4]][_$_53de[149]]= function()
{
	game[_$_53de[134]]({key:_$_53de[146],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[146]])});game[_$_53de[134]]({key:_$_53de[132],text:game[_$_53de[133]](game[_$_53de[108]][_$_53de[132]])});this[_$_53de[99]][_$_53de[93]]= game[_$_53de[93]][_$_53de[59]];this[_$_53de[83]][_$_53de[109]]= false;this[_$_53de[112]](_$_53de[157]);game[_$_53de[130]]= _$_53de[5];if(reels[_$_53de[163]]!= undefined)
	{
		reels[_$_53de[163]][_$_53de[109]]= true
	}
	
}
;function gamble()
{
	
}
var gamble= new gamble()