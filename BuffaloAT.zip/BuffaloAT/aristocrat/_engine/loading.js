/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_19ee=["\x6C\x6F\x61\x64\x69\x6E\x67\x5F\x6C\x6F\x67\x6F","\x69\x6D\x61\x67\x65\x73\x2F\x6C\x6F\x61\x64\x69\x6E\x67\x5F\x6C\x6F\x67\x6F\x2E","\x69\x6D\x67\x54\x79\x70\x65","\x63\x6F\x6E\x66\x69\x67","\x69\x6D\x61\x67\x65","\x77\x69\x64\x74\x68","\x68\x65\x69\x67\x68\x74","\x6C\x6F\x61\x64\x52\x65\x73\x6F\x75\x72\x63\x65","\x6C\x6F\x61\x64\x69\x6E\x67\x53\x74\x61\x67\x65","\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72\x73","\x43\x6F\x6E\x74\x61\x69\x6E\x65\x72","\x6E\x61\x6D\x65","\x78","\x70\x6F\x73\x69\x74\x69\x6F\x6E","\x79","\x7A\x49\x6E\x64\x65\x78","\x61\x64\x64\x43\x68\x69\x6C\x64","\x73\x74\x61\x67\x65","\x70\x72\x6F\x74\x6F\x74\x79\x70\x65","\x62\x6F\x6C\x64\x20\x34\x30\x70\x78\x20\x50\x61\x72\x74\x6E\x65\x72\x4C\x69\x67\x68\x74\x43\x6F\x6E\x64\x65\x6E\x73\x65\x64","\x23\x46\x46\x46\x46\x46\x46","\x63\x65\x6E\x74\x65\x72","\x23\x43\x43\x43\x43\x43\x43","\x70\x65\x72\x63\x65\x6E\x74","\x70\x65\x72\x63\x65\x6E\x74\x43\x75\x72\x72\x65\x6E\x74","\x69\x6E\x69\x74","\x65\x72\x72\x6F\x72","","\x61\x63\x74\x69\x6F\x6E","\x6C\x6F\x61\x64\x69\x6E\x67\x43\x6F\x6D\x70\x6C\x65\x74\x65","\x74\x65\x78\x74","\x69\x6E\x66\x6F\x42\x61\x72","\x63\x6F\x6E\x6E\x65\x63\x74\x69\x6E\x67\x5F\x74\x6F\x5F\x73\x65\x72\x76\x65\x72","\x6C\x61\x6E\x67\x75\x61\x67\x65","\x78\x4F","\x69\x6E\x66\x6F","\x6C\x6F\x61\x64","\x73\x63\x72\x69\x70\x74","\x72\x65\x73\x6F\x75\x72\x63\x65\x73","\x74\x65\x78\x74\x75\x72\x65","\x53\x70\x72\x69\x74\x65","\x30\x20\x25","\x73\x74\x79\x6C\x65","\x54\x65\x78\x74","\x20\x25","\x74\x6F\x46\x69\x78\x65\x64","\x72\x65\x73\x6F\x75\x72\x63\x65\x73\x4C\x6F\x61\x64","\x45\x52\x52\x4F\x52\x20\x3A\x20","\x64\x69\x61\x6C\x6F\x67\x42\x6F\x78","\x6C\x6F\x61\x64\x69\x6E\x67"];
game[_$_19ee[7]]({name:_$_19ee[0],file:_$_19ee[1]+ game[_$_19ee[3]][_$_19ee[2]],type:_$_19ee[4],width:game[_$_19ee[3]][_$_19ee[5]],height:game[_$_19ee[3]][_$_19ee[6]]});game[_$_19ee[9]][_$_19ee[8]]=  new PIXI[_$_19ee[10]]();game[_$_19ee[9]][_$_19ee[8]][_$_19ee[11]]= _$_19ee[8];game[_$_19ee[9]][_$_19ee[8]][_$_19ee[13]][_$_19ee[12]]= 0;game[_$_19ee[9]][_$_19ee[8]][_$_19ee[13]][_$_19ee[14]]= 0;game[_$_19ee[9]][_$_19ee[8]][_$_19ee[15]]= 100;game[_$_19ee[17]][_$_19ee[16]](game[_$_19ee[9]][_$_19ee[8]]);loading[_$_19ee[18]][_$_19ee[3]]= {infoBar:{x:640,y:640,style:{font:_$_19ee[19],fill:_$_19ee[20],align:_$_19ee[21],stroke:_$_19ee[22],strokeThickness:2}}};loading[_$_19ee[18]][_$_19ee[23]]= 0;loading[_$_19ee[18]][_$_19ee[24]]= 0;loading[_$_19ee[18]][_$_19ee[25]]= function()
{
	if(game[_$_19ee[26]]== _$_19ee[27])
	{
		if(this[_$_19ee[23]]== 100&& game[_$_19ee[28]]!= _$_19ee[29])
		{
			game[_$_19ee[28]]= _$_19ee[29];this[_$_19ee[31]][_$_19ee[30]]= game[_$_19ee[33]][_$_19ee[32]];this[_$_19ee[31]][_$_19ee[13]][_$_19ee[12]]= this[_$_19ee[31]][_$_19ee[34]]- this[_$_19ee[31]][_$_19ee[5]]/ 2;console[_$_19ee[35]](_$_19ee[29]);this[_$_19ee[23]]++
		}
		else 
		{
			if(game[_$_19ee[38]][_$_19ee[37]][_$_19ee[3]][_$_19ee[36]]== true)
			{
				if(this[_$_19ee[23]]== 0)
				{
					if(game[_$_19ee[39]][_$_19ee[0]]!= undefined)
					{
						game[_$_19ee[9]][_$_19ee[8]][_$_19ee[16]]( new PIXI[_$_19ee[40]](game[_$_19ee[39]][_$_19ee[0]]));this[_$_19ee[31]]=  new PIXI[_$_19ee[43]](_$_19ee[41],this[_$_19ee[3]][_$_19ee[31]][_$_19ee[42]]);this[_$_19ee[31]][_$_19ee[12]]= this[_$_19ee[3]][_$_19ee[31]][_$_19ee[12]];this[_$_19ee[31]][_$_19ee[34]]= this[_$_19ee[3]][_$_19ee[31]][_$_19ee[12]];this[_$_19ee[31]][_$_19ee[14]]= this[_$_19ee[3]][_$_19ee[31]][_$_19ee[14]];this[_$_19ee[31]][_$_19ee[13]][_$_19ee[12]]-= this[_$_19ee[31]][_$_19ee[5]]/ 2;game[_$_19ee[9]][_$_19ee[8]][_$_19ee[16]](this[_$_19ee[31]]);this[_$_19ee[23]]++
					}
					
				}
				else 
				{
					if(this[_$_19ee[23]]> 0)
					{
						this[_$_19ee[31]][_$_19ee[30]]= this[_$_19ee[23]]+ _$_19ee[44];this[_$_19ee[31]][_$_19ee[13]][_$_19ee[12]]= this[_$_19ee[31]][_$_19ee[34]]- this[_$_19ee[31]][_$_19ee[5]]/ 2;if(game[_$_19ee[38]][_$_19ee[37]][_$_19ee[38]][_$_19ee[36]]== true)
						{
							this[_$_19ee[24]]= (100/ game[_$_19ee[38]][_$_19ee[38]]* game[_$_19ee[38]][_$_19ee[46]])[_$_19ee[45]](0);if(this[_$_19ee[24]]> this[_$_19ee[23]])
							{
								this[_$_19ee[23]]++
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
	}
	else 
	{
		game[_$_19ee[48]]({text:_$_19ee[47]+ game[_$_19ee[26]],onclick:_$_19ee[27]})
	}
	
}
;function loading()
{
	
}
var loading= new loading();//74
game[_$_19ee[28]]= _$_19ee[49];try
{
	config[_$_19ee[49]]()
}
catch(err)
{
	
}
//77
try
{
	config[_$_19ee[3]]()
}
catch(err)
{
	
}
