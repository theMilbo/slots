/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_d8cc=["\x73\x65\x74\x74\x69\x6E\x67\x53\x74\x61\x6E\x64\x61\x72\x64\x43\x6F\x6E\x66\x69\x67","\x73\x65\x74\x74\x69\x6E\x67\x53\x74\x61\x6E\x64\x61\x72\x64","\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72\x73","","\x77\x69\x64\x74\x68","\x62\x61\x73\x65\x54\x65\x78\x74\x75\x72\x65","\x64\x69\x61\x6C\x6F\x67\x5F\x62\x6F\x78","\x74\x65\x78\x74\x75\x72\x65","\x68\x65\x69\x67\x68\x74","\x70\x6F\x73\x69\x74\x69\x6F\x6E","\x74\x6F\x70\x59","\x63\x6F\x6E\x74\x61\x69\x6E\x65\x72","\x43\x6F\x6E\x74\x61\x69\x6E\x65\x72","\x6E\x61\x6D\x65","\x78","\x79","\x7A\x49\x6E\x64\x65\x78","\x76\x69\x73\x69\x62\x6C\x65","\x61\x64\x64\x43\x68\x69\x6C\x64","\x73\x74\x61\x67\x65","\x65\x6C\x65\x6D\x65\x6E\x74\x73","\x62\x61\x63\x6B\x67\x72\x6F\x75\x6E\x64","\x53\x70\x72\x69\x74\x65","\x73\x6F\x75\x6E\x64","\x6C\x61\x6E\x67\x75\x61\x67\x65","\x33\x30\x70\x78\x20\x50\x61\x72\x74\x6E\x65\x72\x4C\x69\x67\x68\x74\x43\x6F\x6E\x64\x65\x6E\x73\x65\x64","\x23\x46\x46\x46\x46\x46\x46","\x63\x65\x6E\x74\x65\x72","\x54\x65\x78\x74","\x73\x6F\x75\x6E\x64\x42\x75\x74\x74\x6F\x6E","\x63\x68\x65\x63\x6B\x5F\x6F\x6E","\x73\x63\x61\x6C\x65","\x62\x75\x74\x74\x6F\x6E\x4D\x6F\x64\x65","\x69\x6E\x74\x65\x72\x61\x63\x74\x69\x76\x65","\x74\x6F\x75\x63\x68\x73\x74\x61\x72\x74","\x73\x65\x74\x74\x69\x6E\x67\x53\x74\x61\x6E\x64\x61\x72\x64\x53\x6F\x75\x6E\x64","\x6F\x6E","\x6D\x6F\x75\x73\x65\x64\x6F\x77\x6E","\x73\x6F\x75\x6E\x64\x5F\x62\x61\x63\x6B\x67\x72\x6F\x75\x6E\x64","\x61\x75\x64\x69\x6F","\x72\x65\x73\x6F\x75\x72\x63\x65\x73","\x73\x6F\x75\x6E\x64\x4C\x6F\x62\x62\x79","\x72\x69\x67\x68\x74","\x73\x6F\x75\x6E\x64\x4C\x6F\x62\x62\x79\x42\x75\x74\x74\x6F\x6E","\x73\x65\x74\x74\x69\x6E\x67\x53\x74\x61\x6E\x64\x61\x72\x64\x73\x6F\x75\x6E\x64\x4C\x6F\x62\x62\x79\x42\x75\x74\x74\x6F\x6E","\x73\x65\x74\x74\x69\x6E\x67\x53\x74\x61\x6E\x64\x61\x72\x64\x5F\x4F\x4B","\x6E\x6F\x72\x6D\x61\x6C","\x73\x74\x61\x74\x75\x73","\x77\x69\x6E\x4C\x69\x6E\x65\x73","\x73\x70\x69\x6E\x5F\x4F\x52\x5F\x67\x61\x6D\x62\x6C\x65","\x62\x75\x74\x74\x6F\x6E\x31\x5F\x31","\x62\x75\x74\x74\x6F\x6E\x31\x5F\x32","\x62\x75\x74\x74\x6F\x6E\x31\x5F\x33","\x62\x75\x74\x74\x6F\x6E\x31\x5F\x34","\x67\x61\x6D\x65\x2E\x73\x65\x74\x74\x69\x6E\x67\x53\x74\x61\x6E\x64\x61\x72\x64\x28\x29","\x67\x6F","\x23\x30\x30\x30\x30\x30\x30","\x61\x64\x64","\x64\x69\x73\x61\x62\x6C\x65\x45\x78\x63\x6C\x75\x73\x69\x6F\x6E","\x64\x69\x73\x61\x62\x6C\x65\x41\x6C\x6C","\x73\x74\x61\x74\x75\x73\x55\x70\x64\x61\x74\x65","\x6D\x61\x73\x6B","\x50\x61\x79\x54\x61\x62\x6C\x65","\x61\x63\x74\x69\x6F\x6E\x53\x6F\x75\x6E\x64","\x63\x6F\x6E\x66\x69\x67","\x63\x68\x65\x63\x6B\x5F\x6F\x66\x66","\x70\x6C\x61\x79\x69\x6E\x67","\x70\x6C\x61\x79","\x73\x74\x6F\x70"];
game[_$_d8cc[0]]= {sound:{x:240,y:200},soundButton:{x:190,y:200},soundLobby:{x:240,y:250},soundLobbyButton:{x:190,y:250}};game[_$_d8cc[1]]= function()
{
	if(this[_$_d8cc[2]][_$_d8cc[1]]== undefined)
	{
		this[_$_d8cc[2]][_$_d8cc[1]]= {container:_$_d8cc[3],elements:{},x:1280/ 2- game[_$_d8cc[7]][_$_d8cc[6]][_$_d8cc[5]][_$_d8cc[4]]/ 2,y:reels[_$_d8cc[9]][0][_$_d8cc[8]]/ 2- game[_$_d8cc[7]][_$_d8cc[6]][_$_d8cc[5]][_$_d8cc[8]]/ 2+ reels[_$_d8cc[9]][0][_$_d8cc[10]]};this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]]=  new PIXI[_$_d8cc[12]]();this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[13]]= _$_d8cc[1];this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[9]][_$_d8cc[14]]= 0;this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[9]][_$_d8cc[15]]= 0;this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[16]]= 100;this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[17]]= false;this[_$_d8cc[19]][_$_d8cc[18]](this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]]);TEMP= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]];TEMP[_$_d8cc[21]]=  new PIXI[_$_d8cc[22]](game[_$_d8cc[7]][_$_d8cc[6]]);TEMP[_$_d8cc[21]][_$_d8cc[14]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[14]];TEMP[_$_d8cc[21]][_$_d8cc[15]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[15]];this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[18]](TEMP[_$_d8cc[21]]);TEMP[_$_d8cc[23]]=  new PIXI[_$_d8cc[28]](game[_$_d8cc[24]][_$_d8cc[23]],{font:_$_d8cc[25],fill:_$_d8cc[26],align:_$_d8cc[27]});TEMP[_$_d8cc[23]][_$_d8cc[14]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[14]]+ this[_$_d8cc[0]][_$_d8cc[23]][_$_d8cc[14]];TEMP[_$_d8cc[23]][_$_d8cc[15]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[15]]+ this[_$_d8cc[0]][_$_d8cc[23]][_$_d8cc[15]];this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[18]](TEMP[_$_d8cc[23]]);TEMP[_$_d8cc[29]]=  new PIXI[_$_d8cc[22]](game[_$_d8cc[7]][_$_d8cc[30]]);TEMP[_$_d8cc[29]][_$_d8cc[14]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[14]]+ this[_$_d8cc[0]][_$_d8cc[29]][_$_d8cc[14]];TEMP[_$_d8cc[29]][_$_d8cc[15]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[15]]+ this[_$_d8cc[0]][_$_d8cc[29]][_$_d8cc[15]];TEMP[_$_d8cc[29]][_$_d8cc[31]][_$_d8cc[14]]= 2;TEMP[_$_d8cc[29]][_$_d8cc[31]][_$_d8cc[15]]= 2;TEMP[_$_d8cc[29]][_$_d8cc[32]]= true;TEMP[_$_d8cc[29]][_$_d8cc[33]]= true;TEMP[_$_d8cc[29]][_$_d8cc[36]](_$_d8cc[37],game[_$_d8cc[35]])[_$_d8cc[36]](_$_d8cc[34],game[_$_d8cc[35]]);this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[18]](TEMP[_$_d8cc[29]]);if(game[_$_d8cc[40]][_$_d8cc[39]][_$_d8cc[38]]!= undefined)
		{
			TEMP[_$_d8cc[41]]=  new PIXI[_$_d8cc[28]](game[_$_d8cc[24]][_$_d8cc[41]],{font:_$_d8cc[25],fill:_$_d8cc[26],align:_$_d8cc[42]});TEMP[_$_d8cc[41]][_$_d8cc[14]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[14]]+ this[_$_d8cc[0]][_$_d8cc[41]][_$_d8cc[14]];TEMP[_$_d8cc[41]][_$_d8cc[15]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[15]]+ this[_$_d8cc[0]][_$_d8cc[41]][_$_d8cc[15]];this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[18]](TEMP[_$_d8cc[41]]);TEMP[_$_d8cc[43]]=  new PIXI[_$_d8cc[22]](game[_$_d8cc[7]][_$_d8cc[30]]);TEMP[_$_d8cc[43]][_$_d8cc[14]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[14]]+ this[_$_d8cc[0]][_$_d8cc[43]][_$_d8cc[14]];TEMP[_$_d8cc[43]][_$_d8cc[15]]= this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[15]]+ this[_$_d8cc[0]][_$_d8cc[43]][_$_d8cc[15]];TEMP[_$_d8cc[43]][_$_d8cc[31]][_$_d8cc[14]]= 2;TEMP[_$_d8cc[43]][_$_d8cc[31]][_$_d8cc[15]]= 2;TEMP[_$_d8cc[43]][_$_d8cc[32]]= true;TEMP[_$_d8cc[43]][_$_d8cc[33]]= true;TEMP[_$_d8cc[43]][_$_d8cc[36]](_$_d8cc[37],game[_$_d8cc[44]])[_$_d8cc[36]](_$_d8cc[34],game[_$_d8cc[44]]);this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[18]](TEMP[_$_d8cc[43]])
		}
		//50
		buttons[_$_d8cc[47]][_$_d8cc[46]][_$_d8cc[45]]= {display:true,state:_$_d8cc[46]};buttons[_$_d8cc[47]][_$_d8cc[48]][_$_d8cc[45]]= {display:true,state:_$_d8cc[46]};buttons[_$_d8cc[47]][_$_d8cc[49]][_$_d8cc[45]]= {display:true,state:_$_d8cc[46]};buttons[_$_d8cc[57]]([{name:_$_d8cc[45],textures:[0,_$_d8cc[50],_$_d8cc[51],_$_d8cc[52],_$_d8cc[53]],onclick:_$_d8cc[54],clickAudio:_$_d8cc[3],text:{key:_$_d8cc[55],color:_$_d8cc[56],size:20,x:0,y:0,bold:_$_d8cc[3]},zIndex:31,x:640- 60,y:this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[15]]+ game[_$_d8cc[7]][_$_d8cc[6]][_$_d8cc[5]][_$_d8cc[8]]- 60,w:120,h:35}],this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]]);this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]]= TEMP
	}
	//10
	if(this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[17]]== false)
	{
		this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[17]]= true;buttons[_$_d8cc[58]]= [_$_d8cc[45]];buttons[_$_d8cc[59]]= true;buttons[_$_d8cc[60]]= true;this[_$_d8cc[61]][_$_d8cc[17]]= true;if(game[_$_d8cc[2]][_$_d8cc[62]]!= undefined)
		{
			game[_$_d8cc[2]][_$_d8cc[62]][_$_d8cc[17]]= false
		}
		
	}
	else 
	{
		buttons[_$_d8cc[58]]= [];buttons[_$_d8cc[59]]= false;buttons[_$_d8cc[60]]= true;this[_$_d8cc[61]][_$_d8cc[17]]= false;this[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[11]][_$_d8cc[17]]= false
	}
	
}
;game[_$_d8cc[35]]= function()
{
	game[_$_d8cc[63]]();if(game[_$_d8cc[64]][_$_d8cc[23]]== true)
	{
		game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[29]][_$_d8cc[7]]= game[_$_d8cc[7]][_$_d8cc[30]];if(game[_$_d8cc[40]][_$_d8cc[39]][_$_d8cc[38]]!= undefined)
		{
			game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[43]][_$_d8cc[17]]= true;game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[41]][_$_d8cc[17]]= true
		}
		
	}
	else 
	{
		game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[29]][_$_d8cc[7]]= game[_$_d8cc[7]][_$_d8cc[65]];if(game[_$_d8cc[40]][_$_d8cc[39]][_$_d8cc[38]]!= undefined)
		{
			game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[43]][_$_d8cc[17]]= false;game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[41]][_$_d8cc[17]]= false
		}
		
	}
	
}
;game[_$_d8cc[44]]= function()
{
	if(game[_$_d8cc[40]][_$_d8cc[39]][_$_d8cc[38]][_$_d8cc[66]]== false)
	{
		game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[43]][_$_d8cc[7]]= game[_$_d8cc[7]][_$_d8cc[30]];game[_$_d8cc[40]][_$_d8cc[39]][_$_d8cc[38]][_$_d8cc[67]]()
	}
	else 
	{
		game[_$_d8cc[2]][_$_d8cc[1]][_$_d8cc[20]][_$_d8cc[43]][_$_d8cc[7]]= game[_$_d8cc[7]][_$_d8cc[65]];game[_$_d8cc[40]][_$_d8cc[39]][_$_d8cc[38]][_$_d8cc[68]]()
	}
	
}
