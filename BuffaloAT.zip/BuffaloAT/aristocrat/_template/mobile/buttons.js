/*
1 - normal
2 - hover 
3 - presed
4 - disable
*/
game.loadResource({name:'button1_1',file:'../_template/'+game.config['template']+'/images/button1_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button1_2',file:'../_template/'+game.config['template']+'/images/button1_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button1_3',file:'../_template/'+game.config['template']+'/images/button1_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button1_4',file:'../_template/'+game.config['template']+'/images/button1_4.'+game.config['imgType'],type:'image'});



game.loadResource({name:'buttonStop',file:'../_template/'+game.config['template']+'/images/button_stop.'+game.config['imgType'],type:'image'});
game.loadResource({name:'buttonGamble',file:'../_template/'+game.config['template']+'/images/button_gamble.'+game.config['imgType'],type:'image'});

game.loadResource({name:'setting_1',file:'../_template/'+game.config['template']+'/images/setting_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'setting_2',file:'../_template/'+game.config['template']+'/images/setting_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'setting_3',file:'../_template/'+game.config['template']+'/images/setting_3.'+game.config['imgType'],type:'image'});


game.loadResource({name:'button_setting_spin',file:'../_template/'+game.config['template']+'/images/button_setting_spin.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_setting_bet',file:'../_template/'+game.config['template']+'/images/button_setting_bet.'+game.config['imgType'],type:'image'});

game.loadResource({name:'button_setting_close',file:'../_template/'+game.config['template']+'/images/button_setting_close.'+game.config['imgType'],type:'image'});





game.loadResource({name:'buttonPaytable',file:'../_template/'+game.config['template']+'/images/button_paytable.'+game.config['imgType'],type:'image'});

game.loadResource({name:'buttonSpin',file:'../_template/'+game.config['template']+'/images/button_spin.'+game.config['imgType'],type:'image'});
game.loadResource({name:'buttonExit',file:'../_template/'+game.config['template']+'/images/button_exit.'+game.config['imgType'],type:'image'});
game.loadResource({name:'buttonSetting',file:'../_template/'+game.config['template']+'/images/button_setting.'+game.config['imgType'],type:'image'});

game.loadResource({name:'buttonSound',file:'../_template/'+game.config['template']+'/images/button_sound.'+game.config['imgType'],type:'image'});
game.loadResource({name:'buttonSoundOff',file:'../_template/'+game.config['template']+'/images/button_sound_off.'+game.config['imgType'],type:'image'});

buttons.prototype.disableAll=false;
buttons.prototype.disableExclusion=[];
buttons.prototype.action="normal";
buttons.prototype.status={
	normal:{
		exit:{display:true,state:'normal'},
		spin:{display:true,state:'normal'},
		sound:{display:true,state:'normal'},
		setting:{display:true,state:'normal'},
		paytable:{display:true,state:'normal'},

	},
	spin:{
		sound:{display:true,state:'normal'},
		stop:{display:true,state:'disable'},
	},
	winLines:{
		exit:{display:true,state:'normal'},
		stop:{display:true,state:'normal'},
		sound:{display:true,state:'normal'},
		setting:{display:true,state:'normal'},
		paytable:{display:true,state:'normal'},
		gamble:{display:true,state:'normal'},
	},
	spin_OR_gamble:{
		exit:{display:true,state:'normal'},
		spin:{display:true,state:'normal'},
		sound:{display:true,state:'normal'},
		setting:{display:true,state:'normal'},
		paytable:{display:true,state:'normal'},
		gamble:{display:true,state:'normal'},
	},
	gamble:{

	},
	error:{},
	wait:{}
};


buttons.prototype.list=[
	{
		name:'exit',
		texture:'buttonExit',
		textures:[0,'buttonExit','buttonExit','buttonExit','buttonExit'],
		onclick:'window.parent.postMessage("CloseGame","*")',
		clickAudio:'click',
		zIndex:35,
		scale:1.5,
		x:10,y:619,w:55,h:40,
	},
	{
		name:'paytable',
		textures:[0,'buttonPaytable','buttonPaytable','buttonPaytable','buttonPaytable'],
		onclick:'payTable.init()',
		clickAudio:'click',
		zIndex:99,
		scale:1.5,
		x:20+80,y:619,w:55,h:40,
	},
	{
		name:'sound',
		textures:[0,'buttonSound','buttonSound','buttonSound','buttonSound'],
		onclick:'game.actionSound()',
		//clickAudio:'click',
		zIndex:35,
		scale:1.5,
		x:1095,y:619,w:55,h:40,
	},
	{
		name:'setting',
		textures:[0,'buttonSetting','buttonSetting','buttonSetting','buttonSetting'],
		onclick:'game.settingMobile()',
		clickAudio:'click',
		zIndex:35,
		scale:1.5,
		x:1100+80,y:619,w:55,h:40,
	},
	{
		name:'spin',
		textures:[0,'buttonSpin','buttonSpin','buttonSpin','buttonSpin'],
		onclick:'game.actionSpin()',
		clickAudio:'click',
		zIndex:35,
		x:1110,y:250,w:166,h:166,
	},
	{
		name:'gamble',
		textures:[0,'buttonGamble','buttonGamble','buttonGamble','buttonGamble'],
		onclick:'gamble.gambleStart()',
		clickAudio:'click',
		zIndex:35,
		x:5,y:250,w:125*0.7,h:51*0.7,
	},
	{
		name:'stop',
		textures:[0,'buttonStop','buttonStop','buttonStop','buttonStop'],
		onclick:'game.actionStop()',
		clickAudio:'click',
		zIndex:35,
		x:1110,y:250,w:166,h:166,
	},
	
	
];
buttons.prototype.blinking={
	timer:40,
	time:40,
	status:1
};
/*------------------------------------------------------------*/
/*------------------------------------------------------------*/
buttons.prototype.init = function() {
//console.info(game.action);
if(this.action!=game.action || this.statusUpdate==true){
	this.statusUpdate=false
	this.action=game.action;
	//console.info(game.action);
	//console.info(buttons.status[game.action]);
	Object.keys(game.buttons).forEach(function(key) {
		if(buttons.status[game.action][key]==undefined){
			buttons.stateSet({key:key,state:'disable',visible:false});
			//console.info(key)
		}else{
			if(buttons.disableAll==false || buttons.disableExclusion.indexOf(key)>=0){
				buttons.stateSet({key:key,state:buttons.status[game.action][key]['state'],visible:buttons.status[game.action][key]['display']});
			}else{
				buttons.stateSet({key:key,state:'disable',visible:buttons.status[game.action][key]['display']});
			}
		}
	});
}
//---- blinking
if(this.blinking.timer>this.blinking.time){
	if(buttons.blinking.status==0){
		buttons.blinking.status=1;
	}else{
		buttons.blinking.status=0;
	}
	if(this.status[game.action]!=undefined){
		Object.keys(this.status[game.action]).forEach(function(key) {
			if(buttons.status[game.action][key]['blinking']==true){
				//console.info(game.buttons[key].buttonTextures);
				if(game.buttons[key].interactive == true){
					if(buttons.blinking.status==0){
						game.buttons[key].texture=game.texture[game.buttons[key].buttonTextures[1]];
					}else{
						game.buttons[key].texture=game.texture[game.buttons[key].buttonTextures[2]];
					}
				}
			}
		});
	}
	this.blinking.timer=0;
}
this.blinking.timer++;
}
/*------------------------------------------------------------*/
buttons.prototype.stateSet = function(data) {
//console.info(data.key);
if(data.state=='disable'){
	game.buttons[data.key].visible = true;
	game.buttons[data.key].interactive = false;
	game.buttons[data.key].texture=game.texture[game.buttons[data.key].buttonTextures[4]];
	if(game.buttons[data.key].buttonText!=undefined){
		game.text[game.buttons[data.key].buttonText].visible = true;
	}
}	
else if(data.state=='normal'){
	game.buttons[data.key].visible = true;
	game.buttons[data.key].interactive = true;
	game.buttons[data.key].texture=game.texture[game.buttons[data.key].buttonTextures[1]];
	if(game.buttons[data.key].buttonText!=undefined){
		game.text[game.buttons[data.key].buttonText].visible = true;
	}
}
if(data.visible!=undefined){
	game.buttons[data.key].visible = data.visible;
	if(game.buttons[data.key].buttonText!=undefined){
		game.text[game.buttons[data.key].buttonText].visible =  data.visible;
	}
}
}
/*------------------------------------------------------------*/
buttons.prototype.add = function(buttonsArray,stage) {
if(buttonsArray==undefined && stage==undefined && this.initMain==undefined){
	buttonsArray=this.list;
	stage='';
	//this.status['spin_OR_gamble']=this.status['winLines'];
}
for(var i=0;i<buttonsArray.length;i++){
	//console.info(buttonsArray[i]);
	if(this.status['normal'][buttonsArray[i]['name']]==undefined){
		this.status['normal'][buttonsArray[i]['name']]={display:false,state:'disable'};
	}
	if(buttonsArray[i]['zIndex']==undefined){
		buttonsArray[i]['zIndex']=0;
	}
	if(buttonsArray[i]['clickAudio']==undefined){
		buttonsArray[i]['clickAudio']='';
	}
	
	
	if(buttonsArray[i]['textures']!=undefined){
		game.buttons[buttonsArray[i]['name']] = new PIXI.Sprite(game.texture[buttonsArray[i]['textures'][1]]);
		game.buttons[buttonsArray[i]['name']].buttonTextures = buttonsArray[i]['textures'];
	}else{
		game.buttons[buttonsArray[i]['name']] = new PIXI.Sprite(game.texture[buttonsArray[i]['texture']]);
	}
	game.buttons[buttonsArray[i]['name']].y = buttonsArray[i]['y'];
	game.buttons[buttonsArray[i]['name']].x = buttonsArray[i]['x'];
	game.buttons[buttonsArray[i]['name']].clickAudio=buttonsArray[i]['clickAudio'];
	game.buttons[buttonsArray[i]['name']].buttonMode = true;
	game.buttons[buttonsArray[i]['name']].interactive = true;
	game.buttons[buttonsArray[i]['name']].buttonName=buttonsArray[i]['name'];
	game.buttons[buttonsArray[i]['name']].buttonOnclick=buttonsArray[i]['onclick'];
	game.buttons[buttonsArray[i]['name']].zIndex = buttonsArray[i]['zIndex'];
	game.buttons[buttonsArray[i]['name']].visible = this.status['normal'][buttonsArray[i]['name']]['display'];

	if(buttonsArray[i]['scale']!=undefined){
		game.buttons[buttonsArray[i]['name']].scale.x = buttonsArray[i]['scale'];
		game.buttons[buttonsArray[i]['name']].scale.y = buttonsArray[i]['scale'];
	}
	if(stage==''){
		game.stage.addChild(game.buttons[buttonsArray[i]['name']]);
		textAddStage="";
	}else{
		stage.addChild(game.buttons[buttonsArray[i]['name']]);
		textAddStage=0;
	}

	if(buttonsArray[i]['scale']!=undefined){
		game.buttons[buttonsArray[i]['name']].scale.x = buttonsArray[i]['scale'];
		game.buttons[buttonsArray[i]['name']].scale.y = buttonsArray[i]['scale'];
	}else{
		buttonsArray[i]['scale']=1;
	}
	if(buttonsArray[i]['scaleX']!=undefined){
		game.buttons[buttonsArray[i]['name']].scale.x = buttonsArray[i]['scaleX'];
	}
	if(buttonsArray[i]['scaleY']!=undefined){
		game.buttons[buttonsArray[i]['name']].scale.y = buttonsArray[i]['scaleY'];
	}
	game.buttons[buttonsArray[i]['name']]
        // set the mousedown and touchstart callback...
        .on('mousedown', buttons.onButtonDown)
        .on('touchstart', buttons.onButtonDown)

        // set the mouseup and touchend callback...
       // .on('mouseup', buttons.onButtonUp)
       // .on('touchend', buttons.onButtonUp)
       // .on('mouseupoutside', buttons.onButtonUp)
       // .on('touchendoutside', buttons.onButtonUp)

        // set the mouseover callback...
      //.on('mouseover', buttons.onButtonOver)
		  //.on('mouseover',function(e){onButtonOver(s);})
		
        // set the mouseout callback...
        //.on('mouseout', buttons.onButtonOut)
	//---------------------------------
	//------------------ button Text
	/**/
		if(buttonsArray[i]['text']!=undefined){
			if(buttonsArray[i]['text']['key']!=undefined){
				var text=game.language[buttonsArray[i]['text']['key']];
			}else{
				var text=buttonsArray[i]['text']['text'];
			}
			if(buttonsArray[i]['text']['style']!=undefined){
				var style=buttonsArray[i]['text']['style'];
			}else{
				var style={ 
					font:buttonsArray[i]['text']['bold']+' '+buttonsArray[i]['text']['size']+'px PartnerLightCondensed', 
					fill:buttonsArray[i]['text']['color'],
					align:'center'
				};
			}
			var b=game.textAdd({
				key:'buttonText_'+buttonsArray[i]['name'],
				text:text,
				x:(buttonsArray[i]['x']+buttonsArray[i]['w']*buttonsArray[i]['scale']/2)+buttonsArray[i]['text']['x'],
				y:(buttonsArray[i]['y']+buttonsArray[i]['h']*buttonsArray[i]['scale']/2-buttonsArray[i]['text']['size']/2)+buttonsArray[i]['text']['y'],
				style:style,
				zIndex:buttonsArray[i]['zIndex']+1,
				visible:game.buttons[buttonsArray[i]['name']].visible,
				stage:textAddStage
			});
			if(stage!=''){
				stage.addChild(b);
			}
			
			game.buttons[buttonsArray[i]['name']].buttonText='buttonText_'+buttonsArray[i]['name'];
		}
	//---------------------------------	
}
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonUp = function(e) {
//if(buttons.status[game.action][e.target['buttonName']]['blinking']!=true){
	if (this.isOver){
		this.tilePosition.y=e.target['_height']*2;
		//console.info('afterpress '+e.target['buttonName']);
	}else{
		this.tilePosition.y=0;
		//console.info('normal2 '+e.target['buttonName']);
	}
//}
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonDown = function(e) {
if(buttons.disableAll==false || buttons.disableExclusion.indexOf(e.target['buttonName'])>=0){
	if(e.target['clickAudio']!=''){
		game.resources.audio['sound_'+e.target['clickAudio']].stop();
		game.resources.audio['sound_'+e.target['clickAudio']].play();
	}
	var tmpFunc = new Function(e.target['buttonOnclick']);
	tmpFunc();
	//console.info(e.target);
	if(e.target['buttonName']=='sound'){
		
		if(game.config.sound==true){
			e.target.texture=game.texture['buttonSound'];
			e.target.buttonTextures=[0,'buttonSound','buttonSound','buttonSound','buttonSound'];
			//PIXI.audioManager.unmute();
		}else{
			e.target.texture=game.texture['buttonSoundOff'];
			e.target.buttonTextures=[0,'buttonSoundOff','buttonSoundOff','buttonSoundOff','buttonSoundOff'];
			//PIXI.audioManager.mute();
		}
	}
	//console.info(e.target);
}
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonOut = function(e) {
	//console.info(buttons.status[game.action][e.target['buttonName']]['blinking']);
//if(buttons.status[game.action][e.target['buttonName']]['blinking']!=true){
	//this.tilePosition.y=0;
//}
	//console.info('normal '+e.target['buttonName']);
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonOver = function(e) {
//if(buttons.status[game.action][e.target['buttonName']]['blinking']!=true){
	//this.tilePosition.y=e.target['_height']*3;
	//console.info('hover '+e.target['buttonName']);
//}
}
/*------------------------------------------------------------*/
function buttons() {}
var buttons = new buttons(); 
