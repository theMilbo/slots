﻿game.loadResource({type:'font',name:'Nunito',file:'Nunito-Regular.ttf',engine:true});	
game.loadResource({type:'font',name:'Helvetica',file:'Helvetica.otf',engine:true});	
game.loadResource({type:'font',name:'PartnerLightCondensed',file:'PartnerLightCondensed.otf',engine:true});	
//game.loadResource({type:'font',name:'PartnerLightUltraCondensed',file:'PartnerLightUltraCondensed.otf',engine:true});	

Ss=1
game.text={};
/*===============================================================================================*/
game.interface = function() {
	if(Ss==1){
	Ss=0;
	var style2 = new PIXI.TextStyle({
		fontFamily: 'PartnerLightCondensed',
		fontSize: 38,
		align:'center',
		//fontStyle: 'italic',
		fontWeight: 'bold',
		fill: ['#e27a00', '#fefb00','#dfb827'], // gradient
		stroke: '#000000',
		strokeThickness: 1,
		dropShadow: true,
		dropShadowColor: '#000000',
		dropShadowBlur: 4,
		dropShadowAngle: Math.PI / 6,
		dropShadowDistance: 4,
	});
	//-------------------------
	game.textAdd({key:'gameInfo',text:game.language.text[0],x:640,y:5,style:style2,zIndex:35});
	//-------------------------
	game.textAdd({key:'totalBet',text:game.getCash(game.config['betInfo']['totalBet']),x:600+10,y:690,style:{ font: 'bold 24px Helvetica', fill:'#ded298',align:'left'}});
	game.textAdd({key:'txtTotalBet',text:game.language['bet'],x:600,y:690,style:{ font: 'bold 24px Helvetica', fill:'#FFFFFF',align:'right'}});
	//-------------------------
	game.textAdd({key:'win',text:game.getCash(0)+'',x:900+10,y:690,style:{ font: 'bold 24px Helvetica', fill:'#ded298',align:'left'}});
	game.textAdd({key:'txtLastWin',text:game.language['win'],x:900,y:690,style:{ font: 'bold 24px Helvetica', fill:'#FFFFFF',align:'right'}});
	//-------------------------
	game.textAdd({key:'balance',text:game.getCash(game.config['balance']),x:380,y:690,style:{ font: 'bold 24px Helvetica', fill:'#ded298',align:'left'}});
	game.textAdd({key:'txtBalance',text:game.language['balance'],x:380,y:690,style:{ font: 'bold 24px Helvetica', fill:'#FFFFFF',align:'right'}});
	
}	
}
/*--------------------------------------------------------------------------------------------*/
game.updateInfoBar = function(){
}
/*--------------------------------------------------------------------------------------------*/
game.updateBalance = function(){
}
/*===============================================================================================*/	