/*
1 - normal
2 - hover 
3 - presed
4 - disable
*/
game.loadResource({name:'button1_1',file:'../_template/'+game.config['template']+'/images/button1_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button1_2',file:'../_template/'+game.config['template']+'/images/button1_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button1_3',file:'../_template/'+game.config['template']+'/images/button1_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button1_4',file:'../_template/'+game.config['template']+'/images/button1_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button2_1',file:'../_template/'+game.config['template']+'/images/button2_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button2_2',file:'../_template/'+game.config['template']+'/images/button2_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button2_3',file:'../_template/'+game.config['template']+'/images/button2_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button2_4',file:'../_template/'+game.config['template']+'/images/button2_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_spin_1',file:'../_template/'+game.config['template']+'/images/button_spin_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_spin_2',file:'../_template/'+game.config['template']+'/images/button_spin_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_spin_3',file:'../_template/'+game.config['template']+'/images/button_spin_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_spin_4',file:'../_template/'+game.config['template']+'/images/button_spin_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_stop_1',file:'../_template/'+game.config['template']+'/images/button_stop_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_stop_2',file:'../_template/'+game.config['template']+'/images/button_stop_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_stop_3',file:'../_template/'+game.config['template']+'/images/button_stop_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_stop_4',file:'../_template/'+game.config['template']+'/images/button_stop_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_gamble_1',file:'../_template/'+game.config['template']+'/images/button_gamble_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_gamble_2',file:'../_template/'+game.config['template']+'/images/button_gamble_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_gamble_3',file:'../_template/'+game.config['template']+'/images/button_gamble_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_gamble_4',file:'../_template/'+game.config['template']+'/images/button_gamble_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_minus_1',file:'../_template/'+game.config['template']+'/images/bet_minus_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_minus_2',file:'../_template/'+game.config['template']+'/images/bet_minus_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_minus_3',file:'../_template/'+game.config['template']+'/images/bet_minus_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_minus_4',file:'../_template/'+game.config['template']+'/images/bet_minus_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_plus_1',file:'../_template/'+game.config['template']+'/images/bet_plus_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_plus_2',file:'../_template/'+game.config['template']+'/images/bet_plus_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_plus_3',file:'../_template/'+game.config['template']+'/images/bet_plus_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'bet_plus_4',file:'../_template/'+game.config['template']+'/images/bet_plus_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_paytable_1',file:'../_template/'+game.config['template']+'/images/button_paytable_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_paytable_2',file:'../_template/'+game.config['template']+'/images/button_paytable_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_paytable_3',file:'../_template/'+game.config['template']+'/images/button_paytable_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_paytable_4',file:'../_template/'+game.config['template']+'/images/button_paytable_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_settings_1',file:'../_template/'+game.config['template']+'/images/button_settings_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_settings_2',file:'../_template/'+game.config['template']+'/images/button_settings_2.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_settings_3',file:'../_template/'+game.config['template']+'/images/button_settings_3.'+game.config['imgType'],type:'image'});
game.loadResource({name:'button_settings_4',file:'../_template/'+game.config['template']+'/images/button_settings_4.'+game.config['imgType'],type:'image'});

game.loadResource({name:'check_off',file:'../_template/'+game.config['template']+'/images/check_off.'+game.config['imgType'],type:'image'});
game.loadResource({name:'check_on',file:'../_template/'+game.config['template']+'/images/check_on.'+game.config['imgType'],type:'image'});


game.loadResource({name:'full_screen_1',file:'../_template/'+game.config['template']+'/images/full_screen_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'full_screen_4',file:'../_template/'+game.config['template']+'/images/full_screen_4.'+game.config['imgType'],type:'image'});
game.loadResource({name:'full_screen_exit_1',file:'../_template/'+game.config['template']+'/images/full_screen_exit_1.'+game.config['imgType'],type:'image'});
game.loadResource({name:'full_screen_exit_4',file:'../_template/'+game.config['template']+'/images/full_screen_exit_4.'+game.config['imgType'],type:'image'});

game.loadResource({name:'button_auto',file:'../_template/'+game.config['template']+'/images/button_auto.'+game.config['imgType'],type:'image'});

//-----------------------------------------------
buttons.prototype.action="normal";
buttons.prototype.disableAll=false;
buttons.prototype.disableExclusion=[];
buttons.prototype.statusUpdate=false;
buttons.prototype.status={
	normal:{
		fullScreen:{display:true,state:'normal'},
		exit:{display:true,state:'normal'},
		refreshBalance:{display:true,state:'normal'},
		settings:{display:true,state:'normal'},
		payTable:{display:true,state:'normal'},
		spin:{display:true,state:'normal',blinking:true},
		betLinePlus:{display:true,state:'normal'},
		betLineMinus:{display:true,state:'normal'},
		linePlus:{display:true,state:'normal'},
		lineMinus:{display:true,state:'normal'},
		gamble:{display:true,state:'disable'},
		buttonAutoMinus:{display:true,state:'normal'},
		buttonAutoPlus:{display:true,state:'normal'},
	},
	spin:{
		fullScreen:{display:true,state:'normal'},
		exit:{display:true,state:'disable'},
		settings:{display:true,state:'disable'},
		payTable:{display:true,state:'disable'},
		stop:{display:true,state:'disable'},
		betLinePlus:{display:true,state:'disable'},
		betLineMinus:{display:true,state:'disable'},
		linePlus:{display:true,state:'disable'},
		lineMinus:{display:true,state:'disable'},
		gamble:{display:true,state:'disable'},
	},
	winLines:{
		fullScreen:{display:true,state:'normal'},
		exit:{display:true,state:'disable'},
		settings:{display:true,state:'normal'},
		payTable:{display:true,state:'disable'},
		stop:{display:true,state:'normal'},
		spin:{display:true,state:'disable'},
		betLinePlus:{display:true,state:'disable'},
		betLineMinus:{display:true,state:'disable'},
		linePlus:{display:true,state:'disable'},
		lineMinus:{display:true,state:'disable'},
		gamble:{display:true,state:'disable'},
	},
	spin_OR_gamble:{
		refreshBalance:{display:true,state:'normal'},
		fullScreen:{display:true,state:'normal'},
		exit:{display:true,state:'normal'},
		settings:{display:true,state:'normal'},
		payTable:{display:true,state:'normal'},
		spin:{display:true,state:'normal',blinking:true},
		betLinePlus:{display:true,state:'normal'},
		betLineMinus:{display:true,state:'normal'},
		linePlus:{display:true,state:'normal'},
		lineMinus:{display:true,state:'normal'},
		gamble:{display:true,state:'normal',blinking:true},
	},
	gamble:{
		fullScreen:{display:true,state:'normal'},
		exit:{display:true,state:'normal'},
		settings:{display:true,state:'disable'},
		spin:{display:true,state:'normal',blinking:true},
		betLinePlus:{display:true,state:'normal'},
		betLineMinus:{display:true,state:'normal'},
		linePlus:{display:true,state:'normal'},
		lineMinus:{display:true,state:'normal'},
		gamble:{display:true,state:'normal',blinking:true},
	},
	error:{},
	wait:{}
};
buttons.prototype.list=[
	{
		name:'fullScreen',
		textures:[0,'full_screen_1','full_screen_4','full_screen_4','full_screen_4'],
		onclick:'buttons.fullScreen();',
		clickAudio:'',
		zIndex:100,
		scale:0.7,
		x:1220,y:10,w:50,h:50,
	},
	{
		name:'exit',
		textures:[0,'button2_1','button2_2','button2_3','button2_4'],
		onclick:'window.parent.postMessage("CloseGame","*")',
		clickAudio:'click',
		text:{key:'exit',color:'#000000',size:20,x:0,y:0,bold:'bold'},
		zIndex:10,
		x:980,y:690,w:114,h:28,
	},
	{
		name:'refreshBalance',
		textures:[0,'button2_1','button2_2','button2_3','button2_4'],
		onclick:'game.refreshBalance()',
		clickAudio:'click',
		text:{key:'balanceRefresh',color:'#000000',size:25,x:10,y:0,bold:'bold'},
		zIndex:10,
		scaleX:1.5,
		x:690,y:690,w:150,h:28,
	},
	{
		name:'payTable',
		textures:[0,'button_paytable_1','button_paytable_2','button_paytable_3','button_paytable_4'],
		onclick:'payTable.init()',
		clickAudio:'click',
		zIndex:10,
		x:925,y:690,w:46,h:28,
	},
	{
		name:'settings',
		textures:[0,'button_settings_1','button_settings_2','button_settings_3','button_settings_4'],
		onclick:'game.settingStandard()',
		clickAudio:'click',
		zIndex:10,
		x:870,y:690,w:46,h:28,
	},
	
	{
		name:'spin',
		textures:[0,'button_spin_1','button_spin_2','button_spin_3','button_spin_4'],
		onclick:'game.actionSpin()',
		clickAudio:'click',
		text:{key:'spin',color:'#FFFFFF',size:25,x:0,y:5,bold:''},
		zIndex:35,
		x:962,y:572,w:115,h:108,
	},
	/*
	{
		name:'buttonAutoMinus',
		texture:game.texture['buttonAutoMinus'],
		onclick:'game.actionAuto("minus")',
		clickAudio:'click',
		zIndex:10,
		x:937,y:562,w:86,h:108,
	},
		{
		name:'buttonAutoPlus',
		texture:game.texture['buttonAutoPlus'],
		onclick:'game.actionAuto("plus")',
		clickAudio:'click',
		zIndex:10,
		rotation:-1.1,
		x:955,y:595,w:46,h:85.25,
	},*/
	/**/
	{
		name:'stop',
		textures:[0,'button_stop_1','button_stop_2','button_stop_3','button_stop_4'],
		onclick:'game.actionStop()',
		clickAudio:'click',
		text:{key:'stop',color:'#FFFFFF',size:25,x:0,y:5,bold:''},
		zIndex:37,
		x:962,y:572,w:115,h:108,
	},
	
	{
		name:'gamble',
		textures:[0,'button_gamble_1','button_gamble_2','button_gamble_3','button_gamble_4'],
		onclick:'gamble.gambleStart()',
		clickAudio:'click',
		text:{key:'gamble',color:'#FFFFFF',size:20,x:0,y:0,bold:''},
		zIndex:10,
		scale:0.7,
		x:783,y:637+12,w:125,h:51,
	},
	{
		name:'lineMinus',
		textures:[0,'bet_minus_1','bet_minus_2','bet_minus_3','bet_minus_4'],
		onclick:'game.changeBet("lines","minus")',
		clickAudio:'click',
		zIndex:10,
		scale:0.8,
		x:200,y:637,w:51,h:51,
	},
	{
		name:'linePlus',
		textures:[0,'bet_plus_1','bet_plus_2','bet_plus_3','bet_plus_4'],
		onclick:'game.changeBet("lines","plus")',
		clickAudio:'click',
		zIndex:10,
		scale:0.8,
		x:294,y:637,w:51,h:51,
	},	
	{
		name:'betLinePlus',
		textures:[0,'bet_plus_1','bet_plus_2','bet_plus_3','bet_plus_4'],
		onclick:'game.changeBet("bet","plus")',
		clickAudio:'click',
		zIndex:10,
		scale:0.8,
		x:475,y:637,w:51,h:51,
	},
	{
		name:'betLineMinus',
		textures:[0,'bet_minus_1','bet_minus_2','bet_minus_3','bet_minus_4'],
		onclick:'game.changeBet("bet","minus")',
		clickAudio:'click',
		zIndex:10,
		scale:0.8,
		x:370,y:637,w:51,h:51,
	},
];
buttons.prototype.blinking={
	timer:40,
	time:40,
	status:0
};
/*------------------------------------------------------------*/
buttons.prototype.init = function() {
//console.info(game.action);
if(this.action!=game.action || this.statusUpdate==true){
	this.statusUpdate=false
	this.action=game.action;
	//console.info(game.action);
	//console.info(buttons.status[game.action]);
	Object.keys(game.buttons).forEach(function(key) {
		if(buttons.status[game.action][key]==undefined){
			buttons.stateSet({key:key,state:'disable',visible:false});
			//console.info(key)
		}else{
			if(buttons.disableAll==false || buttons.disableExclusion.indexOf(key)>=0){
				buttons.stateSet({key:key,state:buttons.status[game.action][key]['state'],visible:buttons.status[game.action][key]['display']});
			}else{
				buttons.stateSet({key:key,state:'disable',visible:buttons.status[game.action][key]['display']});
			}
		}
	});
}
/**/
//---- blinking
if(this.blinking.timer>this.blinking.time){
	if(buttons.blinking.status==0){
		buttons.blinking.status=1;
	}else{
		buttons.blinking.status=0;
	}
	if(this.status[game.action]!=undefined){
		Object.keys(this.status[game.action]).forEach(function(key) {
			if(buttons.status[game.action][key]['blinking']==true){
				//console.info(game.buttons[key].buttonTextures);
				if(game.buttons[key].interactive == true){
					if(buttons.blinking.status==0){
						game.buttons[key].texture=game.texture[game.buttons[key].buttonTextures[1]];
					}else{
						game.buttons[key].texture=game.texture[game.buttons[key].buttonTextures[2]];
					}
				}
			}
		});
	}
	this.blinking.timer=0;
}
this.blinking.timer++;

}
/*------------------------------------------------------------*/
buttons.prototype.stateSet = function(data) {
//console.info(data);
if(data.state=='disable'){
	game.buttons[data.key].visible = true;
	game.buttons[data.key].interactive = false;
	if(game.buttons[data.key].buttonTextures[2]==''){
		game.buttons[data.key].alpha=0.7;
	}else{
		game.buttons[data.key].texture=game.texture[game.buttons[data.key].buttonTextures[4]];
	}
	if(game.buttons[data.key].buttonText!=undefined){
		game.text[game.buttons[data.key].buttonText].visible = true;
	}
}	
else if(data.state=='normal'){
	game.buttons[data.key].visible = true;
	game.buttons[data.key].interactive = true;
	if(game.buttons[data.key].buttonTextures[2]==''){
		game.buttons[data.key].alpha=0.7;
	}else{
		game.buttons[data.key].texture=game.texture[game.buttons[data.key].buttonTextures[1]];
	}
	
	if(game.buttons[data.key].buttonText!=undefined){
		game.text[game.buttons[data.key].buttonText].visible = true;
	}
}
if(data.visible!=undefined){
	game.buttons[data.key].visible = data.visible;
	if(game.buttons[data.key].buttonText!=undefined){
		game.text[game.buttons[data.key].buttonText].visible =  data.visible;
	}
}
}
/*------------------------------------------------------------*/
buttons.prototype.add = function(buttonsArray,stage) {
if(buttonsArray==undefined && stage==undefined && this.initMain==undefined){
	buttonsArray=this.list;
	stage='';
	//this.status['spin_OR_gamble']=this.status['winLines'];
}
for(var i=0;i<buttonsArray.length;i++){
	//console.info(buttonsArray[i]);
	if(buttonsArray[i]['name']=='spin'){
		var button_auto_BG = new PIXI.Sprite(game.texture['button_auto']);
		button_auto_BG.x = buttonsArray[i]['x']-30;
		button_auto_BG.y = buttonsArray[i]['y']+63;
		button_auto_BG.zIndex = buttonsArray[i]['zIndex']-1;
		button_auto_BG.rotation=-1.04;
		game.stage.addChild(button_auto_BG);

		var res=game.textAdd({
			key:'autoPlus',
			text:'+',
			x:buttonsArray[i]['x']+22,
			y:buttonsArray[i]['y']-5,
			style:{
				font: 'bold 25px PartnerLightCondensed', 
				fill:'#FFFFFF',
				align:'center'
			},
			zIndex:buttonsArray[i]['zIndex']+1,
			stage:'0'
		});
		res.buttonMode = true;
		res.interactive = true;
		res.on('mousedown', function(){game.autoPlay('plus');}).on('touchstart', function(){game.autoPlay('plus');})
		game.stage.addChild(res);	
		var res=game.textAdd({
			key:'autoMinus',
			text:'-',
			x:buttonsArray[i]['x']-5,
			y:buttonsArray[i]['y']+35,
			style:{
				font: 'bold 35px PartnerLightCondensed', 
				fill:'#FFFFFF',
				align:'center'
			},
			zIndex:buttonsArray[i]['zIndex']+1,
			stage:'0'
		});
		res.buttonMode = true;
		res.interactive = true;
		res.on('mousedown', function(){game.autoPlay('minus');}).on('touchstart', function(){game.autoPlay('minus');})
		game.stage.addChild(res);
	
		game.textAdd({
			key:'autoPlayLeft',
			text:game.config.autoPlay.left,
			x:buttonsArray[i]['x']-1,
			y:buttonsArray[i]['y']+33,
			style:{ font: '20px PartnerLightCondensed', fill:'#FFFFFF',align:'center'},
			zIndex:buttonsArray[i]['zIndex']+1,
		});
		game.text['autoPlayLeft'].rotation=-1.04;
	}
	if(this.status['normal'][buttonsArray[i]['name']]==undefined){
		this.status['normal'][buttonsArray[i]['name']]={display:false,state:'disable'};
	}
	if(buttonsArray[i]['zIndex']==undefined){
		buttonsArray[i]['zIndex']=0;
	}
	if(buttonsArray[i]['clickAudio']==undefined){
		buttonsArray[i]['clickAudio']='';
	}
	
	
	if(buttonsArray[i]['textures']!=undefined){
		game.buttons[buttonsArray[i]['name']] = new PIXI.Sprite(game.texture[buttonsArray[i]['textures'][1]]);
		game.buttons[buttonsArray[i]['name']].buttonTextures = buttonsArray[i]['textures'];
	}else{
		game.buttons[buttonsArray[i]['name']] = new PIXI.Sprite(game.texture[buttonsArray[i]['texture']]);
	}
	game.buttons[buttonsArray[i]['name']].x = buttonsArray[i]['x'];
	game.buttons[buttonsArray[i]['name']].y = buttonsArray[i]['y'];
	
	//game.buttons[buttonsArray[i]['name']].width = buttonsArray[i]['w'];
	//game.buttons[buttonsArray[i]['name']].height = buttonsArray[i]['h'];
	
	game.buttons[buttonsArray[i]['name']].clickAudio=buttonsArray[i]['clickAudio'];
	game.buttons[buttonsArray[i]['name']].buttonMode = true;
	game.buttons[buttonsArray[i]['name']].interactive = true;
	game.buttons[buttonsArray[i]['name']].buttonName=buttonsArray[i]['name'];
	game.buttons[buttonsArray[i]['name']].buttonOnclick=buttonsArray[i]['onclick'];
	game.buttons[buttonsArray[i]['name']].zIndex = buttonsArray[i]['zIndex'];
	game.buttons[buttonsArray[i]['name']].visible = this.status['normal'][buttonsArray[i]['name']]['display'];

	
	if(buttonsArray[i]['scale']!=undefined){
		game.buttons[buttonsArray[i]['name']].scale.x = buttonsArray[i]['scale'];
		game.buttons[buttonsArray[i]['name']].scale.y = buttonsArray[i]['scale'];
	}else{
		buttonsArray[i]['scale']=1;
	}
	if(buttonsArray[i]['scaleX']!=undefined){
		game.buttons[buttonsArray[i]['name']].scale.x = buttonsArray[i]['scaleX'];
	}
	if(buttonsArray[i]['scaleY']!=undefined){
		game.buttons[buttonsArray[i]['name']].scale.y = buttonsArray[i]['scaleY'];
	}
	
	if(stage==''){
		game.stage.addChild(game.buttons[buttonsArray[i]['name']]);
		textAddStage="";
	}else{
		stage.addChild(game.buttons[buttonsArray[i]['name']]);
		textAddStage=0;
	}
	if(this.status['normal'][buttonsArray[i]['name']]['state']=='disable'){
		game.buttons[buttonsArray[i]['name']].interactive = false;
		game.buttons[buttonsArray[i]['name']].texture=game.texture[buttonsArray[i]['textures'][4]];
	}//game.texture[game.buttons[key].buttonTextures[2]];
		
		
		game.buttons[buttonsArray[i]['name']]
			// set the mousedown and touchstart callback...
			.on('mousedown', buttons.onButtonDown)
			.on('touchstart', buttons.onButtonDown)
			// set the mouseup and touchend callback...
			.on('mouseup', buttons.onButtonUp)
			.on('touchend', buttons.onButtonUp)
			.on('mouseupoutside', buttons.onButtonUp)
			.on('touchendoutside', buttons.onButtonUp)
			// set the mouseover callback...
			.on('mouseover', buttons.onButtonOver)
			// set the mouseout callback...
			.on('mouseout', buttons.onButtonOut)
		//---------------------------------
		//------------------ button Text
		if(buttonsArray[i]['text']!=undefined){
			if(buttonsArray[i]['text']['key']!=undefined){
				var text=game.language[buttonsArray[i]['text']['key']];
			}else{
				var text=buttonsArray[i]['text']['text'];
			}
			if(buttonsArray[i]['text']['style']!=undefined){
				var style=buttonsArray[i]['text']['style'];
			}else{
				var style={ 
					font:buttonsArray[i]['text']['bold']+' '+buttonsArray[i]['text']['size']+'px PartnerLightCondensed', 
					fill:buttonsArray[i]['text']['color'],
					align:'center'
				};
			}
			var b=game.textAdd({
				key:'buttonText_'+buttonsArray[i]['name'],
				text:text,
				x:(buttonsArray[i]['x']+buttonsArray[i]['w']*buttonsArray[i]['scale']/2)+buttonsArray[i]['text']['x'],
				y:(buttonsArray[i]['y']+buttonsArray[i]['h']*buttonsArray[i]['scale']/2-buttonsArray[i]['text']['size']/2)+buttonsArray[i]['text']['y'],
				style:style,
				zIndex:buttonsArray[i]['zIndex']+1,
				visible:game.buttons[buttonsArray[i]['name']].visible,
				stage:textAddStage
			});
			if(stage!=''){
				stage.addChild(b);
			}
			game.buttons[buttonsArray[i]['name']].buttonText='buttonText_'+buttonsArray[i]['name'];
		}	//text:{key:'spin',color:'#FFFFFF',size:30},
		//---------------------------------
	}	
//console.info(game.stage)
}
/*------------------------------------------------------------*/
buttons.prototype.fullScreen = function() {
if(game.config.fullScreen==false){
	game.config.fullScreen=true;
	game.buttons['fullScreen'].texture=game.texture['full_screen_exit_1'];
	game.buttons['fullScreen'].buttonTextures=[0,'full_screen_exit_1','full_screen_exit_4','full_screen_exit_4','full_screen_exit_4'];
}else{
	game.config.fullScreen=false;
	game.buttons['fullScreen'].texture=game.texture['full_screen_1'];
	game.buttons['fullScreen'].buttonTextures=[0,'full_screen_1','full_screen_4','full_screen_4','full_screen_4'];
}
engine.fullScreen(game.config.fullScreen);
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonUp = function(e) {
if(game.buttons[this.buttonName].buttonTextures[2]==''){
	game.buttons[this.buttonName].alpha=1;
}else{	
	game.buttons[this.buttonName].texture=game.texture[game.buttons[this.buttonName].buttonTextures[1]];
}
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonDown = function(e) {
if(buttons.disableAll==false || buttons.disableExclusion.indexOf(this.buttonName)>=0){
	if(game.buttons[this.buttonName].buttonTextures[3]==''){
		
	}else{
		game.buttons[this.buttonName].texture=game.texture[game.buttons[this.buttonName].buttonTextures[3]];
	}
	//console.info('press '+e.target['buttonName']);
	//console.info(e.target);
	if(this.buttonName=='spin' && game.resources.audio['sound_spin']!=undefined){
		this.clickAudio='';
	}
	
	if(this.clickAudio!=''){
		game.resources.audio['sound_'+e.target['clickAudio']].stop();
		game.resources.audio['sound_'+e.target['clickAudio']].play();
	}
	var tmpFunc = new Function(this.buttonOnclick);
	tmpFunc();
}
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonOut = function(e) {
	
	//console.info(game.buttons[this.buttonName].buttonTextures[1]);
//if(buttons.status[game.action][e.target['buttonName']]['blinking']!=true){
	if(game.buttons[this.buttonName].buttonTextures[2]==''){
		game.buttons[this.buttonName].alpha=1;
	}else{
		game.buttons[this.buttonName].texture=game.texture[game.buttons[this.buttonName].buttonTextures[1]];
	}
//}
 ///console.info(this.buttonName);
	//console.info(e.data.originalEvent);
}
/*------------------------------------------------------------*/
buttons.prototype.onButtonOver = function(e) {
//if(buttons.status[game.action][e.target['buttonName']]['blinking']!=true){
	if(game.buttons[this.buttonName].buttonTextures[2]==''){
		game.buttons[this.buttonName].alpha=0.7;
	}else{
		game.buttons[e.target['buttonName']].texture=game.texture[game.buttons[e.target['buttonName']].buttonTextures[2]];
	}
	//console.info('hover '+e.target['buttonName']);
	
//}
}
/*------------------------------------------------------------*/
function buttons() {}
var buttons = new buttons(); 
