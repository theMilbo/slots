﻿game.loadResource({type:'font',name:'Nunito',file:'Nunito-Regular.ttf',engine:true});	
game.loadResource({type:'font',name:'Helvetica',file:'Helvetica.otf',engine:true});	
game.loadResource({type:'font',name:'PartnerLightCondensed',file:'PartnerLightCondensed.otf',engine:true});	
/*===============================================================================================*/
game.interface = function() {
var style = new PIXI.TextStyle({
	fontFamily: 'PartnerLightCondensed',
	fontSize: 34,
	align:'center',
	//fontStyle: 'italic',
	fontWeight: 'bold',
	fill: ['#e27a00', '#fefb00','#dfb827'], // gradient
	stroke: '#000000',
	strokeThickness: 1,
	dropShadow: true,
	dropShadowColor: '#000000',
	dropShadowBlur: 4,
	dropShadowAngle: Math.PI / 6,
	dropShadowDistance: 3,
});//
var style2 = new PIXI.TextStyle({
	fontFamily: 'PartnerLightCondensed',
	fontSize: 38,
	align:'center',
	//fontStyle: 'italic',
	fontWeight: 'bold',
	fill: ['#e27a00', '#fefb00','#dfb827'], // gradient
	stroke: '#000000',
	strokeThickness: 1,
	dropShadow: true,
	dropShadowColor: '#000000',
	dropShadowBlur: 4,
	dropShadowAngle: Math.PI / 6,
	dropShadowDistance: 4,
});

var style3=JSON.parse(JSON.stringify(style));
	style3.fill='#FFFFFF';
	style3.fontSize=31;
var style4=JSON.parse(JSON.stringify(style));
	style4.fill='#FFFFFF';
	style4.fontSize=36;	
var style5=JSON.parse(JSON.stringify(style));
	style5.fill='#b8b010';
	style5.fontSize=27;		
	style5.align='left';
var style6=JSON.parse(JSON.stringify(style));
	style6.fill='#FFFFFF';
	style6.fontSize=27;		
	style6.align='right';	
	//console.log(style5.TextStyle);	
	//{ font: 'bold 30px PartnerLightCondensed', fill:'#FFFFFF',align:'center',stroke: "#CCCCCC", strokeThickness:1}
	//{ font: 'bold 22px Helvetica', fill:'#b8b010',align:'left'}
//-------------------------
game.textAdd({key:'gameInfo',text:game.language.text[0],x:640,y:0,style:style2,zIndex:35});
//-------------------------
game.textAdd({key:'lines',text:game.config['betInfo']['lines'],x:270,y:637,style:style3});
game.textAdd({key:'txtLines',text:game.language['lines'],x:270,y:590,style:style});
//-------------------------
game.textAdd({key:'betPerLine',text:game.getCash(game.config['betInfo']['bet']),x:445,y:637,style:style3});
game.textAdd({key:'txtBetPerLine',text:game.language['betPerLine'],x:445,y:590,style:style});
//-------------------------
game.textAdd({key:'totalBet',text:game.getCash(game.config['betInfo']['totalBet']),x:640,y:637,style:style3});
game.textAdd({key:'txtTotalBet',text:game.language['totalBet'],x:640,y:590,style:style});
//-------------------------
game.textAdd({key:'win',text:game.getCash(0)+'',x:830,y:610,style:style4});
game.textAdd({key:'txtLastWin',text:game.language['win'],x:830,y:590-10,style:style});
//-------------------------
game.textAdd({key:'balance',text:game.getCash(game.config['balance']),x:380,y:688,style:style5});
game.textAdd({key:'txtBalance',text:game.language['balance'],x:380,y:688,style:style6});
//-------------------------
}//stroke: "#a4410e", strokeThickness: 7
/*--------------------------------------------------------------------------------------------*/
game.updateInfoBar = function(){
}
/*--------------------------------------------------------------------------------------------*/
game.updateBalance = function(){
}
/*===============================================================================================*/	