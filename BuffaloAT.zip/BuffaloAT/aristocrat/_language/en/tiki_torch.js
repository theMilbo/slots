game.language.text=[
	'Welcome to TIKI TORCH!',
	'PEARL is Scatter.',
	'TIKI TORCH is Wild',
];
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Free Spin Feature","background":"more_info"},
		{x:450,y:150,align:"center",color:"#FFFFFF",size:"20",stroke:"","family":"Calibri","text":"TIKI TORCH Feature - Win 8 free games when 3, 4, or 5 Scatter (PEARL) occur from left <br>most reel to right.<br><br>During the free games KNIFE, CANOE & HUT substitute for TIKI TORCH.<br><br>During free spins, a continuous Scatter (PEARL) appearing from left to right on the screen<br>wins the same amount of money as the winning reel that triggered the feature.<br><br>All free games will be played with LINES and BET PER LINE the same as that triggering the feature.<br><br>Feature can be retriggered again during the feature."}
	],
	[
		{x:0,y:30,"name":"Pay Tables","background":"paytable_1"},
		{x:140,y:150,align:"center",color:"#FFFFFF",size:"18",stroke:"","family":"Calibri","text":"TIKI TORCH substitutes  for all<br>symbols except scatter PEARL"},
		{x:870,y:150,align:"right",color:"#FFFFFF",size:"18",stroke:"","family":"Calibri","text":"Scatter pays left to<br>right. Scatter wins <br>multiplied by TOTAL BET."}
	],
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20",stroke:"","family":"Calibri","text":"Scatters (PEARL) appear on all reels. Wild (TIKI TORCH) substitute all symbols except Scatters (PEARL).<br><br><br>All wins pay LEFT to RIGHT, including Scatters (PEARL).<br>TOTAL BET is the BET PER LINE multiplied by number of LINES.<br>Choose your bet per line cost. Choose the lines that you wish to play.<br><br>All wins multiplied by the number on the BET PER LINE button except Scatter (PEARL) which <br>are multiplied by the TOTAL BET.%<br>Wins on different lit paylines added.<br>All wins on lines played except Scatters (PEARL) which are added to payline wins.<br>Highest win only on each line. Highest win only on Scatters. Winnings added to Balance <br>after Gamble or Play.<br><br>If the game window is closed during GAMBLE or FEATURE when real money is in play the game <br>state will be stored and may be resumed at a later date for a period of 90 days. Funds attached <br>to games which remain incomplete after 90 days will be donated to charity.<br><br>Malfunction Voids All Pays and Play. <br> This game has a return to player of 94.85%.  <br> Maximum payout approximately 125000.00."}
	],
	[
		{x:0,y:30,"name":"Pay Lines","background":"paytable_2"}
	],
	[
		{x:0,y:30,"name":"Gamble Option","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20",stroke:"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br><br>EBet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br><br>EBet is QUADRUPLED (x4) if SUIT choice is correct.<br><br><br>Winnings may be gambled up to 5 times.<br>Permitted Gamble Amount calculated as ((Maximum Game Payout - Current Winnings) / 4).<br><br><br>The maxiumum amount is <br><br><br>Any winnings above this threshold are held in GAMBLE RESERVE. <br><br>This is used to top-up the Gamble Amount up to the permitted limit."}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20",stroke:"","family":"Calibri","text":"Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in:Select how much of your existing balance you would like to take into the game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, <br>your total bet will be calculated asCLines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>MISS KITTY  2003 - 2011 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED<br>"}
	]
]