game.language.text=[
	'Welcome to Werewolf Wild!',
	'Three SCATTERS triggers feature.',
	'Werewolf Wild is Wild',
];
game.language.freeSpin.start=[
	{x:640,y:210,align:"center",color:TEXT_GRADIENT,size:60,family:"Arial",stroke:"#000000",text:"THE MOON IS FULL"},
	{x:640,y:290,align:"center",color:'#ffffff',size:40,family:"Arial",stroke:"#000000",text:"The Werewolf`s Touch<br>TURNS PEOPLE WILD"},
	{x:640,y:420,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"Press start button to begin feature..."},
];
game.language.freeSpin.finish=[
	{x:640,y:210,align:"center",color:TEXT_GRADIENT,size:60,family:"Arial",stroke:"#000000",text:"FEATURE WIN"},
	{x:640,y:290,align:"center",color:'#ffffff',size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"}
];
game.language['start']='Start';



game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Pay Table 1","background":"more_info"},
		{x:20,y:75,width:855,height:550,type:'image',image:'paytable'},
				
		{x:540,y:220,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"APPEARS<br>ON REEL<br>1 ONLY"},
		
		{x:310,y:180,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"SUBSTITUTES<br>FOR ALL<br>SYMBOLS<br>EXCEPT<br>AND"},
		{x:105,y:190,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3<br>2"},
		{x:40,y:190,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"1000<br>500<br>100<br>10"},
		
		{x:700,y:200,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:650,y:200,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"50<br>10<br>2"},
		{x:800,y:310,align:"center",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"PAYS ANY"},
		
		{x:160,y:350,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:210,y:350,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"500<br>250<br>25"},
		{x:450,y:350,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:500,y:350,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"500<br>250<br>25"},
		{x:730,y:350,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:780,y:350,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"400<br>100<br>20"},
		
		{x:320,y:465,align:"left",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:370,y:465,align:"left",color:"#f6e224",size:25,"stroke":"","family":"Calibri","text":"300<br>100<br>10"},
		{x:570,y:465,align:"left",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:620,y:465,align:"left",color:"#f6e224",size:25,"stroke":"","family":"Calibri","text":"250<br>75<br>10"},
		
		{x:460,y:560,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"ALL WINS LEFT TO RIGHT ONLY EXCEPT SCATTERS WHICH PAYANY"},
		
	],
	[
		{x:0,y:30,"name":"Pay Table 2","background":"more_info"},
		{x:20,y:75,width:855,height:550,type:'image',image:'paytable_1'},
		
		{x:445,y:350,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"SUBSTITUTES FOR ALL SYMBOLS EXCEPT               AND"},
		
		
		{x:500,y:200,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"APPEARS<br>ON REEL<br>1 ONLY"},
		
		{x:160,y:200,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:210,y:200,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"125<br>50<br>10"},
		{x:730,y:200,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:780,y:200,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"100<br>50<br>5"},
		
		{x:180,y:420,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:230,y:420,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"100<br>30<br>5"},
		{x:450,y:420,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:500,y:420,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"100<br>30<br>5"},
		{x:750,y:420,align:"left",color:"#FFFFFF",size:30,"stroke":"","family":"Calibri","text":"5<br>4<br>3"},
		{x:800,y:420,align:"left",color:"#f6e224",size:30,"stroke":"","family":"Calibri","text":"100<br>25<br>5"},
		
		{x:460,y:560,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"ALL WINS LEFT TO RIGHT ONLY EXCEPT SCATTERS WHICH PAYANY"},
		
	],
	[
		{x:0,y:30,"name":"Features","background":"more_info"},
		{x:450,y:80,align:"center",color:['#e27a00','#fefb00','#dfb827'],size:30,"stroke":"","family":"Calibri","text":"THE WEREWOLF'S TOUCH BONUS - WITH CONTAGIOUS WILDS"},
		{x:450,y:120,align:"center",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"3, 4 OR 5 Scatter FULL MOON TRIGGER 7, 14 OR 28 FREE GAMES RESPECTIVELY."},
		{x:450,y:170,align:"center",color:"#FFFFFF",size:18,"stroke":"","family":"Calibri","text":"DURING THE FREE GAMES EACH WEREWOLF SPUN UP ON THE REELS IS CONTAGIOUS, TRANSFORMING<br>ANY GENTLEMAN, LADY OR POLICEMAN IT TOUCHES INTO ANOTHER CONTAGIOUS WEREWOLF<br>WINS ARE AWARDED AFTER ALL TRANSFORMATIONS ARE COMPLETE. <br> THE WEREWOLF'S TOUCH BONUS CAN BE TRIGGERED AGAIN DURING THE WEREWOLF'S TOUCH BONUS <br> BET AND LINES PLAYED ARE THE SAME AS THE GAME THAT TRIGGERED THE FEATURE."},
		
		{x:680,y:350,align:"center",color:['#e27a00','#fefb00','#dfb827'],size:25,"stroke":"","family":"Calibri","text":"CLAW SWIPE FEATURE"},
		{x:680,y:400,align:"center",color:"#FFFFFF",size:"18","stroke":"","family":"Calibri","text":"DURING ANY SPIN 1, 2, 3, 4 or 5 CLAW SWIPESCAN<br>RANDOMLY APPEAR ON SEPARATE REELS<br>TURNING A SYMBOL INTO WEREWOLF."},
		{x:500,y:340,width:50,height:50,type:'movieClip',image:'claw_3'},
		{x:810,y:340,width:50,height:50,type:'image',image:'symbol_1'},
		
		{x:250,y:350,align:"center",color:['#e27a00','#fefb00','#dfb827'],size:25,"stroke":"","family":"Calibri","text":"MYSTERY COIN FEATURE"},
		{x:250,y:400,align:"center",color:"#FFFFFF",size:"18","stroke":"","family":"Calibri","text":"WHENEVER COIN IS SPUN UP ON REEL 1 AND ONE OR<br>MORE WEREWOLF APPEAR ANYWHERE IN THE<br>WINDOW, A RANDOM PRIZE OF 2, 3, 4, 5, 10, 20 OR 40<br>MULTIPLIED BY THE TOTAL BET IS AWARDED."},
		{x:40,y:340,width:50,height:50,type:'image',image:'symbol_12'},
		{x:380,y:340,width:50,height:50,type:'image',image:'symbol_1'},
		
	],
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"CHOOSE YOUR BET PER LINE. <br> ALL GAMES PLAYED AT 25 LINES. <br> ALL WINS ON LIT LINES ONLY EXCEPT SCATTERS AND MYSTERY COIN FEATURE WINS. <br> WINS ON DIFFERENT LINES ARE ADDED. <br> HIGHEST WIN ONLY ON EACH LINE. <br> SCATTER WINS AND MYSTERY COIN FEATURE WINS ARE ADDED TO LINE WINS. <br> LINE WINS ARE MULTIPLIED BY THE BET PER LINE <br> SCATTER WINS ARE MULTIPLIED BY THE TOTAL BET."},
		{x:450,y:350,align:"center",color:"#FFFFFF",size:"18","stroke":"","family":"Calibri","text":"THE THEORETICAL RETURN TO PLAYER IS: 95.30%"},
		{x:450,y:400,align:"center",color:"#FFFFFF",size:"18","stroke":"","family":"Calibri","text":"ARISTOCRAT PRODUCTS ARE PROTECTED BY PATENTS. <br> FOR A FULL LIST OF ARISTOCRAT PATENTS PLEASE CHECK WITH YOUR LOCAL PATENT OFFICE. <br> © ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED"},
	],
	[
		{x:0,y:30,"name":"Gamble Option","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT<br><br>Win is DOUBLED (X2) if RED/BLACK choice is correct<br><br>Win is QUADRUPLED (X4) if SUIT choice is correct<br><br>Winnings may be gambled up to 5 times"}
	],
	[
		{x:0,y:30,"name":"Win Lines","background":"more_info"},
		{x:20,y:100,width:855,type:'image',image:'paytable_2'},
	],
]