game.language.freeSpin.start=[
	{x:290,y:200,align:"center",color:"#F60",size:"50",family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
	{x:290,y:280,align:"center",color:"#F60",size:"30",family:"Arial",stroke:"#000000",text:"You have won free spins!"}
];
game.language.freeSpin['choice_feature_game']="Choice Feature Game";
game.language['lines']='Reels';
game.language['betPerLine']='Bet';

game.language.text=[
	'Welcome Choy Sun Doa!',
	//'Three CASTLE triggers feature.',
	//'BAT is Wild',
];

game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:95,y:30,"name":"Pay Tables","background":"more_info"},
		{x:25,y:60,width:850,height:500,type:'image',image:'paytable_1'},
		{x:450,y:90,align:"center",color:"#4b5e9d",size:16,stroke:"#bfbaaa","family":"Calibri","text":"SUBSTITUTES FOR ALL SYMBOLS EXCEPT"},
		{x:450,y:150,align:"center",color:"#4b5e9d",size:16,stroke:"#bfbaaa","family":"Calibri","text":"Appears on reels 2, 3 and 4 only."},
		{x:450,y:200,align:"center",color:"#4b5e9d",size:16,stroke:"#bfbaaa","family":"Calibri","text":"All symbols pay LEFT to RIGHT including scatters"},
		{x:450,y:230,align:"center",color:"#4b5e9d",size:16,stroke:"#bfbaaa","family":"Calibri","text":"Scatter wins always added."}
	],
	[
		{x:310,y:30,"name":"Free Spin Feature","background":"more_info"},
		{x:25,y:60,width:850,height:500,type:'image',image:'paytable_2'},
		{x:450,y:90,align:"center",color:"#5E6C9E",size:20,stroke:"","family":"Calibri","text":"FREE GAMES are WON WITH ANY 3 OR MORE scattered                  , from leftmost reel to right.<br><br>A second screen will appear displaying all five feature options.<br>Choose your free games feature by selecting the corresponding FISH."},
		{x:60,y:400,align:"left",color:"#5E6C9E",size:17,stroke:"","family":"Calibri","text":"During the free games,                     anywhere on reels 1 and 5 results in a random prize of 50, 20, 15, 10, 5 or 2."},
		{x:500,y:425,align:"center",color:"#5E6C9E",size:17,stroke:"","family":"Calibri","text":"Random prize is multiplied by the total amount staked."},
		{x:500,y:450,align:"center",color:"#5E6C9E",size:17,stroke:"","family":"Calibri","text":"The feature can be won again during the free games. Number of features remaining is represented by the number"},
		{x:70,y:475,align:"left",color:"#5E6C9E",size:17,stroke:"","family":"Calibri","text":"of             collected. The reels selected and the bet during the feature are the same as those on the game that started the feature."},
		{x:500,y:500,align:"center",color:"#5E6C9E",size:17,stroke:"","family":"Calibri","text":"Return to player for all 5 features is essentially the same."},
		{x:500,y:520,align:"center",color:"#5E6C9E",size:20,stroke:"","family":"Calibri","text":"CHOY SUN DOA  2002 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED."}
	],
	[
		{x:570,y:30,"name":"Reel Powe","background":"more_info"},
		{x:25,y:60,width:850,height:500,type:'image',image:'paytable_3'},
		{x:450,y:90,align:"center",color:"#5E6C9E",size:25,stroke:"","family":"Calibri","text":"All wins begin with leftmost reel and pay left to right only on adjacent reels. Highest win paid<br> per winning combination on bought reels. Coinciding wins added."},
		{x:450,y:150,align:"center",color:"#5E6C9E",size:25,stroke:"","family":"Calibri","text":"Total bet is the Reel Cost multiplied by the bet."},
		{x:195,y:250,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"Reels in Play<br>1<br>2<br>3<br>3<br>5"},
		{x:330,y:250,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"Reel Cost<br>1<br>3<br>7<br>15<br>25<br><br>"},
		{x:530,y:250,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"Positions in Play<br>7 reel positions<br>9 reel positions<br>11 reel positions<br>13 reel positions<br>15 reel positions<br>"},
		{x:750,y:250,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"Ways to win<br>3 ways to win<br>9 ways to win<br>27 ways to win<br>81 ways to win<br>243 ways to win"},
		{x:470,y:420,align:"center",color:"#ECBE03",size:25,stroke:"","family":"Calibri","text":"For all symbols except scatters, winning combinations pay through <br> any position on the bought reels and the center line only on other reels"},
		{x:450,y:500,align:"center",color:"#5E6C9E",size:25,stroke:"","family":"Calibri","text":"All wins multiplied by bet per reel except scatters. Scatter wins are multiplied by total bet."}
	],
	[
		{x:780,y:30,"name":"Gamble","background":"more_info"},
		{x:450,y:200,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT<br>Win is DOUBLED (X2) if RED/BLACK choice is correct <br>Win is QUADRUPLED (X4) if SUIT choice is correct <br>Winnings may be gambled up to 5 times"},
		{x:450,y:450,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"The Theoretical Return to Player is: 94.516% - 94.606%"}
	],
	[
		{x:950,y:30,"name":"Reels diagrams","background":"more_info"},
		{x:25,y:60,width:850,height:500,type:'image',image:'paytable_4'},
		{x:120,y:300,align:"left",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"REEL 1"},
		{x:450,y:300,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"REEL 1-2"},
		{x:770,y:300,align:"right",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"REEL 1-3"},
		{x:285,y:485,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"REEL 1-4"},
		{x:585,y:485,align:"center",color:"#FFFFFF",size:20,stroke:"","family":"Calibri","text":"REEL 1-5"}
	]
]