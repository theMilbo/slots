game.language.text=[
	'Welcome to MOON FESTIVAL!',
	'Three INGOT triggers feature.',
	'PEARL is Wild',
];
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Feature","background":"more_info"},
		{x:20,y:75,width:855,height:500,type:'image',image:'paytable_0'},
	],
	[
		{x:0,y:30,"name":"Pay Table I","background":"more_info"},
		{x:20,y:75,width:855,height:500,type:'image',image:'paytable_1'},
	],
	[
		{x:0,y:30,"name":"Pay Table II","background":"more_info"},
		{x:20,y:75,width:855,height:500,type:'image',image:'paytable_2'},
	],
	[
		{x:0,y:30,"name":"Win Lines","background":"more_info"},
		{x:20,y:75,width:855,height:500,type:'image',image:'paytable_3'},
	],
	[
		{x:0,y:30,"name":"Gamble Option","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br><br><br>EBet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br><br>EBet is QUADRUPLED (x4) if SUIT choice is correct.<br><br><br>Winnings may be gambled up to 5 times.<br>Permitted Gamble Amount calculated as ((Maximum Game Payout - Current Winnings) / 4).<br><br><br>The maxiumum amount is <br><br><br>Any winnings above this threshold are held in GAMBLE RESERVE. <br><br>This is used to top-up the Gamble Amount up to the permitted limit."}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in:Select how much of your existing balance you would like to take into the game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, <br>your total bet will be calculated asCLines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>MISS KITTY  2003 - 2011 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED<br>"}
	]
]