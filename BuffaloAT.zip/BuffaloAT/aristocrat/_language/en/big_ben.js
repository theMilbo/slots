game.language.text=[
	'Welcome to BIG BEN!',
	//'Three INGOT triggers feature.',
	//'PEARL is Wild',
];
game.language.chimes={
	Text1:'EACH CHIME WINS <br>A HIGHER PRIZE',
	Text2:'chimes',
	Text3:'WIN = ',
	Text4:'Text4',
	Text5:'Text5',
};


game.language['payTable']={};
game.language['payTable']['pages']=[
	[//,height:500
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:25,y:100,width:850,type:'image',image:'paytable'},
		{x:440,y:150,align:"center",color:"#FE0000",size:"30","stroke":"","family":"Calibri","text":"BIG BEN FEATURE"},
		{x:440,y:210,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"The BIG BEN Feature is won when scattered BIG BEN appears <br>ANYWHERE on reels 1 and 5<br><br>[WIN up to 500X MULTIPLIER when BIG BEN strikes!"},
		{x:440,y:320,align:"center",color:"#E6B800",size:"40","stroke":"","family":"Calibri","text":"FREE GAME FEATURE"},
		{x:440,y:360,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"25, 20 or 15 FREE GAMES are won with ANY 5X, 4X or 3X<br> scattered BIG BEN win respectively<br><br>All WINS during the FREE GAMES are DOUBLED<br><br>Refer to RULES for more details"},
		{x:107,y:110,align:"center",color:"#FE0000",size:"30","stroke":"","family":"Calibri","text":"WILD"},
		{x:800,y:110,align:"center",color:"#9E4F00",size:"30","stroke":"","family":"Calibri","text":"SCATTER"},
		{x:107,y:300,align:"center",color:"#FEFE00",size:"22","stroke":"","family":"Calibri","text":"5  30000<br>4   3000<br>3    300<br>2     10<br><br>Any WIN with<br>GUARD <br>dobles the<br>prize"},
		{x:800,y:300,align:"center",color:"#FEFE00",size:"22","stroke":"","family":"Calibri","text":"5  1000<br>4    25<br>3     5<br>2     2<br>Pay Any<br>SCATTER<br>wins are <br>multiplied by<br>total bet"}
	],
	[
		{x:0,y:30,"name":"Pay Tables","background":"more_info"},
		{x:25,y:100,width:850,type:'image',image:'paytable_1'},
		{x:130,y:120,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  800<br>4  100<br>3   25<br>2    2"},
		{x:130,y:260,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  250 <br>4  50 <br>3  12"},
		{x:350,y:120,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  800 <br>4  100 <br>3   25 <br>2    2"},
		{x:350,y:260,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  250 <br>4  50 <br>3  10"},
		{x:550,y:120,align:"left",color:"#FEFE00",size:"25","stroke":"","family":"Calibri","text":"5  500 <br>4  100 <br>3  20"},
		{x:550,y:260,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  125 <br>4  50 <br>3   5 "},
		{x:750,y:120,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  400 <br>4  75<br>3  15"},
		{x:750,y:260,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  100 <br>4  25 <br>3  5"},
		{x:230,y:380,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  100 <br>4  25 <br>3  5"},
		{x:440,y:380,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  100 <br>4  25 <br>3  5"},
		{x:650,y:380,align:"left",color:"#FEFE00",size:"30","stroke":"","family":"Calibri","text":"5  100 <br>4  25 <br>3  5<br>2  2"}
	],
	[
		{x:0,y:30,"name":"Free Game Feature","background":"more_info"},
		{x:440,y:170,align:"center",color:"#FFFFFF",size:"30","stroke":"","family":"Calibri","text":"25, 20 or 15 FREE GAMES are won with ANY 5X, 4X or 3X <br>scattered BIG BEN win respectively<br><br>All WINS during the FREE GAMES are DOUBLED<br><br>Feature can be re-triggered during the Free Games<br><br>Credits bet and lines played are the same as the game that <br>started the FREE GAMES"}
	],
	[
		{x:0,y:30,"name":"Big Ben Feature","background":"more_info"},
		{x:215,y:420,width:650,type:'image',image:'paytable_2'},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"30","stroke":"","family":"Calibri","text":"The BIG BEN Feature is won when scattered BIG BEN<br>appears ANYWHERE on reels 1 and 5<br><br>The number of times BIG BEN chimes determines the prize YOU win!"},
		{x:107,y:433,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Number of Chimes"},
		{x:107,y:525,align:"center",color:"#FEFE00",size:"20","stroke":"","family":"Calibri","text":"WIN"},
		{x:235,y:450,align:"left",color:"#FFFFFF",size:"30","stroke":"","family":"Calibri","text":"1       2      3       4      5      6     7      8      9     10    11    12"},
		{x:235,y:527,align:"left",color:"#FE0000",size:"30","stroke":"","family":"Calibri","text":"x2    x4    x6     x8   x10  x12  x14   x16  x18  x20  x25  x500"}
	],
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"CHOOSE YOUR BET PER LINE.<br>CHOOSE YOUR NUMBER OF LINES.<br>ALL WINS LEFT TO RIGHT ONLY EXCEPT SCATTERS WHICH PAY ANY.<br>ALL WINS ON LIT LINES ONLY EXCEPT SCATTERS.<br>WINS ON DIFFERENT PAYLINES ARE ADDED.<br>SCATTER WINS ARE ADDED TO LINE WINS.<br>MALFUNCTION VOIDS ALL PAYS AND PLAYS."},
		{x:440,y:450,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"ARISTOCRAT PRODUCTS ARE PROTECTED BY PATENTS.<br>FOR A FULL LIST OF ARISTOCRAT PATENTS PLEASE CHECK WITH YOUR LOCAL PATENT OFFICE.<br>COPYRIGHTufffd2003-2007 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED."}
	],
	[
		{x:0,y:30,"name":"Win Lines","background":"more_info"},
		{x:50,y:100,width:800,type:'image',image:'paytable_3'},
	],
	[
		{x:0,y:30,"name":"Gamble Feature","background":"more_info"},
		{x:440,y:300,align:"center",color:"#FFFFFF",size:"30","stroke":"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br>Bet is DOUBLED (x2) if RED/BLACK choice is correct.<br>Bet is QUADRUPLED (x4) if SUIT is correct.<br>Winnings may be gambled up to 5 times."}
	]
]