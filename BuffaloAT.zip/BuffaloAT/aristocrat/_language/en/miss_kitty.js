game.language.text=[
	'Welcome to Miss Kitty!',
	'Three INGOT triggers feature.',
	'PEARL is Wild',
];
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Scatters (Moon Symbol) only appear on reels 1,2 and 3.<br>Wilds (Cat Symbol) only appear on reels 2,3,4 and 5 and substitute all symbols except Scatters (Moon Symbol).<br><br>All wins pay LEFT to RIGHT including Scatters (Moon Symbol).<br>TOTAL BET is the number of LINES on the LINES button multiplied by the value on the BET PER LINE button.<br>Choose your bet per line cost.  Choose the lines that you wish to play.<br><br>Scatter (Moon Symbol) wins added to payline wins.<br>Scatter (Moon Symbol) wins are multiplied by the number <br>on the BET PER LINE button X the number of lines played.<br>All wins multiplied by the number on the BET PER LINE button except Scatter (Moon Symbol).<br>Wins on different lit paylines added.<br>All wins on lines played except Scatters (Moon Symbol) which are added to payline wins.<br><br>Spacebar can be used to spin the reels. This option must be selected from the settings menu.<br><br>Malfunction Voids All Pays and Play.<br>This game has a return to player of 94.765%.<br>Maximum payout is "}
	],
	[
		{x:0,y:30,"name":"Gamble Option","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br><br><br>EBet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br><br>EBet is QUADRUPLED (x4) if SUIT choice is correct.<br><br><br>Winnings may be gambled up to 5 times.<br>Permitted Gamble Amount calculated as ((Maximum Game Payout - Current Winnings) / 4).<br><br><br>The maxiumum amount is <br><br><br>Any winnings above this threshold are held in GAMBLE RESERVE. <br><br>This is used to top-up the Gamble Amount up to the permitted limit."}
	],
	[
		{x:0,y:30,"name":"Free Spin Feature","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"When 3 scatters (Moon Symbol) appear 10 free games are won.<br><br>Any WILD (Cat Symbol) appearing during the free games stays in the window at that position <br>for the remainder of the free games, and substitutes for all symbols except scatters.<br><br>Scatters (Moon Symbol) occurring beneath a STICKY WILD (Cat Symbol) may contribute to a <br>scatter prize, as indicated by alternating display of these symbols.<br><br>Feature can be triggered again during the feature once only, with 5 free games awarded.<br><br>BETS and lines played are the same as the game that triggered the feature."}
	],
	[
		{x:0,y:30,"name":"Pay Tables","background":"paytable_1"},
		{x:235,y:190,align:"center",color:"#FFFFFF",size:"12","stroke":"","family":"Calibri","text":"SUBSTITUTES ALL SYMBOLS<br>EXPERT SCATTER"},
		{x:235,y:220,align:"center",color:"#FFFFFF",size:"12","stroke":"","family":"Calibri","text":"APPEARS ON REELS 2,3,4 AND<br>5 ONLY"},
		{x:630,y:180,align:"center",color:"#FFFFFF",size:"12","stroke":"","family":"Calibri","text":"APEARS ON REELS 1,2<br> AND 3 ONLY"},
		{x:630,y:240,align:"center",color:"#FFFFFF",size:"12","stroke":"","family":"Calibri","text":"PAY LEFT TO RIGHT"},
		{x:200,y:155,align:"center",color:"#FFD34C",size:"35","stroke":"#FF0099","family":"Arial Black","text":"WILD"},
		{x:700,y:155,align:"center",color:"#FFD34C",size:"35","stroke":"#FF0099","family":"Arial Black","text":"SCATTER"}
	],
	[
		{x:0,y:30,"name":"Pay Lines","background":"paytable_2"}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in:Select how much of your existing balance you would like to take into the game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, <br>your total bet will be calculated asCLines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>MISS KITTY  2003 - 2011 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED<br>"}
	]
]