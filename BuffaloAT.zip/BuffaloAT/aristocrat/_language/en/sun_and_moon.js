game.language.text=[
	'Welcome to SUN & MOON!',
	'Three SUN/MOON triggers feature.',
	'SUN & MOON is Wild',
];
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:200,align:"center",color:"#F60",size:"50",family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:280,align:"center",color:"#F60",size:"30",family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!<br>ALL WINS X2"}
	], 
	"finish":[ 
		{x:290,y:200,align:"center",color:"#F60",size:"40",family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:280,align:"center",color:"#F60",size:"40",family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:200,align:"center",color:"#F60",size:"50",family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES<br>ALL WINS X2"}
	]   
}
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,name:"Games Rules",background:"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:20,stroke:"",family:"Calibri",text:"Scatters (GOLD SUN/SILVER MOON) appear on all reels.<br>Wilds (GOLD SUN/SILVER MOON) substitute all symbols except Scatters (GOLD SUN/SILVER MOON).<br><br>All wins pay LEFT to RIGHT only on adjacent reels starting from LEFTMOST reel. Scatters <br>(GOLD SUN/SILVER MOON) of a kind or mixed pay LEFT to RIGHT anywhere on adjacent reels.<br><br>Choose the lines that you wish to play. Choose your bet per line cost.<br>TOTAL BET is number of LINES multiplied by BET PER LINE.<br><br>All wins on lines played except Scatters (GOLD SUN/SILVER MOON) which are added to payline wins.<br>Wins on different lit paylines added.<br>All wins multiplied by the number on the BET PER LINE button except Scatters (GOLD SUN/SILVER MOON) <br>which are multiplied by the TOTAL BET.<br>Highest win only on each line. Highest win only on Scatters. Winnings added to Balance after Play.<br><br>Malfunction Voids All Pays and Play.<br><br>Aristocrat products are protected by patents.<br><br>Aristocrat Technologies Australia PTY Limited."}
	],
	[
		{x:0,y:30,name:"Free Spins Feature",background:"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:20,stroke:"",family:"Calibri",text:"Win 5, 10, 20, or 50 free games when 2, 3, 4 OR 5 GOLD SUN/SILVER MOON (of a kind or mixed) <br>occur respectively from left most reel to right.<br><br>All prizes are doubled during the free games feature.<br><br>Feature can be retriggered during free games.<br><br>Bets and lines played are the same as the game that triggered the feature."}
	],
	[
		{x:0,y:30,name:"Pay Tables",background:"paytable"}
	],
	[
		{x:0,y:30,name:"Pay Lines",background:"paytable_1"}
	],
	[
		{x:0,y:30,name:"Instructions",background:"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:20,stroke:"",family:"Calibri",text:"Spacebar:  Can be used to spin the reels.<br>Settings:  Enable / disable sounds effects, ambient sound and the spacebar spin button<br>Help:  View games rules, paytables and paylines.<br><br>Lines:  Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line:  Use the + and - buttons to select the amount you wish to stake per line, your total<br>bet will be calculated as  Lines bet  x  Bet per line <br><br>Play:  Confirm your bet.<br>Auto:  Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop:  Stop any Autospin whilst in progress<br><br>Results published on cashing out of the game<br>"}
	]
]