game.language.text=[
	'Welcome to Double Happiness!',
	'Any 3 or More DOUBLE HAPPINESS Triggers the Feature',
	'DRAGON is WILD',
	'WILD substitutes for all symbols except SCATTERS',
	'During the feature, two ROAMING WILDS appear'
];
game.language['payTable']={};
game.language['payTable']['pages']=[
    [
		{x:100,y:30,"name":"Wild","background":"more_info"},
		{x:-110,y:-17,width:1150,height:575,type:'image',image:'paytable'},
		{x:360,y:115,align:"center",color:"#FFFFFF",size:25,stroke:"",family:"Calibri",text:"10, 15 or 25 free games are won <br>with any 3, 4 or 5 scattered"},
		{x:360,y:270,align:"center",color:"#B3EB00",size:35,stroke:"",family:"Calibri",text:"ROAMING WILD"},
		{x:360,y:350,align:"center",color:"#FFFFFF",size:20,stroke:"",family:"Calibri",text:"Roaming wilds appear and substitute <br>for all symbols except scatters"},
		{x:360,y:477,align:"center",color:"#FFFFFF",size:17,stroke:"",family:"Calibri",text:"Refer to RULES page for more details"},
		{x:770,y:420,align:"center",color:"#FFFFFF",size:18,stroke:"",family:"Calibri",text:"Substitutes for all<br>symbols except<br>scatters"},
	],
	[
		{x:260,y:30,"name":"Free games feature","background":"more_info"},
		{x:-110,y:-17,width:1150,height:575,type:'image',image:'paytable_1'},
		{x:480,y:80,align:"center",color:"#FF1D1D",size:"35",stroke:"",family:"Calibri",text:"FREE GAMES FEATURE"},
		{x:520,y:130,align:"center",color:"#FFFFFF",size:"18",stroke:"",family:"Calibri",text:"10, 15 or 25 free games are won with any 3, 4 or 5 scattered"},
		{x:530,y:180,align:"center",color:"#B3EB00",size:"30",stroke:"",family:"Calibri",text:"DOUBLE ROAMING WILD"},
		{x:50,y:410,align:"left",color:"#FF1D1D",size:"18",stroke:"",family:"Calibri",text:"DOUBLE HAPPINESS"},
		{x:50,y:435,align:"left",color:"#FFFFFF",size:"18",stroke:"",family:"Calibri",text:"pays in ANY position"},
		{x:500,y:250,align:"center",color:"#FFFFFF",size:"17",stroke:"",family:"Calibri",text:"Two ROAMING WILDS appear and substitute for all symbols except scatters.<br>Each ROAMING WILD moves one position between each free game.<br>If both ROAMING WILDS appear in the same position and substitute in a win,<br>the pay for that win is multiplied by 10.<br><br>                          Scattered DOUBLE HAPPINESS occurring beneath <br>                          ROAMING WILD may contribute to a scatter prize.<br>              <br>         Feature can be triggered again during the feature.<br><br>Free Games are played at the paylines and bet of the trigger game.<br><br>Refer to RULES page for more details"}
	],
	[
		{x:620,y:30,"name":"Pay Table","background":"more_info"},
		{x:-110,y:-17,width:1150,height:575,type:'image',image:'paytable_2'},
		{x:640,y:565,align:"center",color:"#FFFFFF",size:"18",stroke:"",family:"Calibri",text:"Payline wins are multiplied by the bet per payline"}
	],
	[
		{x:805,y:30,"name":"Rules","background":"more_info"},
		{x:-110,y:-17,width:1150,height:575,type:'image',image:'paytable_4'},
		{x:5,y:80,align:"left",color:"#FFFFFF",size:"16",stroke:"",family:"Calibri",text:"FREE GAMES FEATURE<br>  - 10, 15 or 25 free games are won with any 3, 4 or 5 scattered DOUBLE HAPPINESS<br><br>DOUBLE ROAMING WILD<br>  - Two ROAMING WILDS appear and substitute for all symbols except scatters<br>  - Each ROAMING WILD moves one position between each free game<br>  - If both ROAMING WILDS appear in the same position and substitute in a win,<br>    the pay for that win is multiplied by 10<br>  - Scattered DOUBLE HAPPINESS occurring beneath ROAMING WILD<br>    may contribute to a scatter prize<br>  - Feature can be triggered again during the feature<br>  - Free Games are played at the paylines and bet of the trigger game<br><br>GAME RULES<br>  - Play 25 paylines <br>  - The cost to play 25 paylines is 30 coins multiplied by the bet per payline <br>  - Payouts are made ac cording to the Paytable <br>  - Payline wins are multiplied by the bet per payline <br>  - Scatter wins are multiplied by the bet per line and number of lines played <br>  - Scatter wins are added to payline wins <br>  - Highest win only on each selected payline "},
		{x:490,y:80,align:"left",color:"#FFFFFF",size:"16",stroke:"",family:"Calibri",text:"  - Wins on different paylines are added <br>  - Malfunction voids all pays and plays <br>  - All wins pay from Left to Right on selected paylines except scattered <br>  - DOUBLE HAPPINESS <br>  - WILD substitutes for all symbols except scatters <br><br>GAMBLE FEATURE<br>  - To gamble any win press GAMBLE then select RED/BLACK or a SUIT <br>  - Win is DOUBLED (X2) if RED/BLACK choice is correct <br>  - Win is QUADRUPLED (X4) if SUIT choice is correct <br>  - Winnings may be gambled up to 5 times <br>  - Progressive Jackpot Wins (if available) may not be gambled <br>  <br>  <br>The Theoretical Return to Player is: 93.057% <br>Double Happiness 2007 Aristocrat Technologies Australia Pty Limited <br>Aristocrat products are protected by patents <br>For a full list of Aristocrat patents please check with your <br>local patent office"}
	],
	[
		{x:950,y:30,"name":"Pay Lines","background":"more_info"},
		{x:-110,y:-17,width:1150,height:575,type:'image',image:'paytable_3'},
	]
]