game.language.text=[
	'Welcome to BIG RED!',
	'TREE is Scatter.',
	'KANGAROO is Wild',
];
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Scatters (TREE) appear on all reels.<br>Wilds (KANGAROO) appear on reels 3, 4, and 5 and substitute for all symbols except Scatters (TREE).<br><br>All wins including Scatters (TREE) pay LEFT to RIGHT except during free games where Scatters (TREE) pay ANY.<br>TOTAL BET is number of LINES multiplied by BET PER LINE.<br>Choose your bet per line cost. Choose the lines that you wish to play.<br><br>Scatter (TREE) wins are added to payline wins.<br>Scatter (TREE) wins are multiplied by the BET PER LINE and the number of lines played.<br>All wins on lines played except Scatters (TREE) which are added to payline wins.<br>Highest win only on each line. Highest win only on Scatters. Winnings added to Balance after Gamble or Play.<br><br>During free spins each individual Scatter (TREE) can have an additional payout.<br>During free spins, any scatter appearing on the screen wins the same amount of money as the winline that <br>triggered the feature.<br><br>Maximum payout is 125000.00.<br>This game has a return to player of 97.04%.<br><br>Malfunction voids all pays and plays."}
	],
	[
		{x:0,y:30,"name":"Gamble Option","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br><br><br>EBet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br><br>EBet is QUADRUPLED (x4) if SUIT choice is correct.<br><br><br>Winnings may be gambled up to 5 times.<br>Permitted Gamble Amount calculated as ((Maximum Game Payout - Current Winnings) / 4).<br><br><br>The maxiumum amount is <br><br><br>Any winnings above this threshold are held in GAMBLE RESERVE. <br><br>This is used to top-up the Gamble Amount up to the permitted limit."}
	],
	[
		{x:0,y:30,"name":"Free Spin Feature","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Feature is triggered where one or more Wilds (KANGAROO) substitute in any winning payline.<br>5 free games are awarded for each lit payline triggering the feature.<br><br>Any Scatter (TREE) during the free games will generate the same amount of winnings as the line that <br>triggered the feature originally excluding scatters.<br><br>All free games will be played on 5 lines with the BET PER LINE the same as the BET PER LINE that <br>started the feature.<br><br>During free games one or more Wilds (KANGAROO) substituting in a win on any lit payline wins 5 free games <br>with same rule as if the player were playing a normal spin. If current set of 5 free spins have not <br>finished the new set is  stacked and will be triggered when the current have finished.<br><br>A stacked free spins indicator (KANGAROO WITH NUMBER MULTIPLIER) will appear in top right of screen <br>if free spins stacked. NUMBER MULTIPLIER shows number of sets of free spins stacked."}
	],
	[
		{x:0,y:30,"name":"Pay Table","background":"paytable_1"}
	],
	[
		{x:0,y:30,"name":"Pay Lines","background":"paytable_2"}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in:Select how much of your existing balance you would like to take into the game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, <br>your total bet will be calculated asCLines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>MISS KITTY  2003 - 2011 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED<br>"}
	]
]