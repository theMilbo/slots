game.language.freeSpin.start=[
	{x:290,y:200,align:"center",color:"#F60",size:"50",family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
	{x:290,y:280,align:"center",color:"#F60",size:"30",family:"Arial",stroke:"#000000",text:"You have won free spins!"}
];
game.language.text=[
	'Welcome to Queen OF THE NILE II!',
	'Three PYRAMID triggers feature.',
	'CLEOPATRA is Wild',
];
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Pay Table","background":"more_info"},
		{x:120,y:150,width:650,type:'image',image:'paytable'},
		{x:470,y:80,align:"center",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"substitutes for all symbols except scatter"},
		{x:470,y:120,align:"center",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"substituting in any win is doubled as shown"},
		{x:70,y:280,align:"center",color:"#FED100",size:20,"stroke":"","family":"Calibri","text":"ORANGE <br>PRIZES <br>ARE <br>FOR <br>STANDARD<br> WINS"},
		{x:820,y:280,align:"center",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"WHITE <br>PRIZES <br>ARE <br>FOR <br>CLEOPATRA <br>SUBSTITUTE <br>WINS"}
	],
	[
		{x:0,y:30,"name":"Free Spin Feature","background":"more_info"},
		{x:25,y:100,width:850,type:'image',image:'paytable_1'},
		{x:440,y:350,align:"left",color:"#DADA00",size:20,"stroke":"","family":"Calibri","text":"WIN the Free Games Feature with<br>3 or more scattered PYRAMID"},
		{x:440,y:450,align:"center",color:"#FCD762",size:20,"stroke":"","family":"Calibri","text":"All wins pays left to right except scatter which pays any.<br>Highest win only paid on any lit payline except scatter which is added to payline wins.<br>Wins on different paylines added."}
	],
	[
		{x:0,y:30,"name":"Free Spin Rules","background":"more_info"},
		{x:25,y:200,width:850,type:'image',image:'paytable_2'},
		{x:440,y:100,align:"center",color:"#FEFE00",size:"25","stroke":"","family":"Calibri","text":"Choose Your Free Games Feature!<br>Choose your free game feature by selecting the pyramid of your choice"},
		{x:200,y:230,align:"center",color:"#CFCB48",size:"20","stroke":"","family":"Calibri","text":"5 FREE GAMES<br>All wins X10"},
		{x:700,y:230,align:"center",color:"#CFCB48",size:"20","stroke":"","family":"Calibri","text":"10 FREE GAMES<br>All wins X5"},
		{x:200,y:340,align:"center",color:"#CFCB48",size:"20","stroke":"","family":"Calibri","text":"15 FREE GAMES<br>All wins X3"},
		{x:700,y:340,align:"center",color:"#CFCB48",size:"20","stroke":"","family":"Calibri","text":"20 FREE GAMES<br>All wins X2"},
		{x:440,y:430,align:"center",color:"#FEFE00",size:"18","stroke":"","family":"Calibri","text":"The feature can be won again during the free games"},
		{x:440,y:460,align:"center",color:"#00B1B2",size:"18","stroke":"","family":"Calibri","text":"The number of features remaining is indicated on the screen"},
		{x:440,y:480,align:"center",color:"#FCD762",size:"18","stroke":"","family":"Calibri","text":"The bet and lines played during the free games are the same as those for the game that started the feature"},
		{x:440,y:530,align:"center",color:"#FCB539",size:"18","stroke":"","family":"Calibri","text":"QUEEN OF THE NILE II 2003 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED"}
	],
	[
		{x:0,y:30,"name":"Pay Lines","background":"more_info"},
		{x:25,y:100,width:850,type:'image',image:'paytable_3'},
	],
	[
		{x:0,y:30,"name":"Gamble Option","background":"more_info"},
		{x:440,y:156,align:"center",color:"#F4ED54",size:"25","stroke":"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT<br>Bet is DOUBLED (x2) if RED/BLACK choice is correct.<br>Bet is QUADRUPLED (x4) if SUIT is correct.<br>Winnings may be gambled up to 5 times."},
		{x:440,y:430,align:"center",color:"#FCB539",size:"18","stroke":"","family":"Calibri","text":"QUEEN OF THE NILE II 2003 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED"}
	]
]