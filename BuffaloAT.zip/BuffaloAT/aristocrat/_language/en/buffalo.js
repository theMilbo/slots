
game.language['lines']='Reel Cost';
game.language['betPerLine']='Bet';

game.language.text=[
	'Welcome to BUFFALO!',
	'3,4 or 5 Scatters  triggers feature.',
	' is Wild',
];

game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Feature","background":"more_info"},
		{x:440,y:110,align:"center",color:"#FFFFFF",size:24,stroke:"",family:"Calibri","text":"BUFFALO Feature - Win 8, 15 or 20 FREE GAMES with any 3, 4 or 5 Scatters (COIN) respectively. <br>Your total win for any spin may be multiplied by up to 27.<br><br>During the free games each SUNSET that appears anywhere in reels 2, 3 or 4 will multiply the <br>total win for that spin by either 2 or 3.<br><br>All free games will be played with REEL COST and BET PER REEL the same as that <br>triggering the feature.<br><br>The feature can be triggered again during the feature. In addition, 5 EXTRA FREE GAMES <br>are awarded if any 2 Scatters (COIN) occur during any free game.<br><br>Aristocrat products are protected by patents.<br>Aristocrat Technologies Australia PTY Limited."}
	],
	[
		{x:0,y:30,"name":"Pay Tables","background":"paytable_1"},
		{x:380,y:120,align:"left",color:"#FFFFFF",size:24,stroke:"#FFFFFF",family:"Calibri","text":"substitute for all<br>symbols expert <br>Scatter"},
		{x:380,y:220,align:"left",color:"#FFFFFF",size:24,stroke:"#FFFFFF",family:"Calibri","text":"appears on reels 2,3<br>and 4 only"}
	],
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:440,y:110,align:"center",color:"#FFFFFF",size:24,stroke:"",family:"Calibri","text":"Scatters (COIN) appear on all reels. Wild (SUNSET) substitute all symbols except Scatters (COIN).<br><br>All wins pay LEFT to RIGHT except Scatters (COIN) which pay ANY.<br>TOTAL BET is the BET PER REEL multiplied by REEL COST.<br>Choose your bet per reel cost.  Choose the reels that you wish to play.<br><br>Only positions containing the winning symbol are used in determining win for that symbol.<br><br>Coinciding wins are added. Scatter (COIN) wins added to REEL POWER wins. <br>Highest win only on Scatters.<br><br>REEL POWER wins multiplied by the number on the BET PER REEL button. <br>Scatter (COIN) wins multiplied by the TOTAL BET.<br><br>Malfunction Voids All Pays and Play."}
	],
	[
		{x:0,y:30,"name":"REEL POWER","background":"paytable_2"},
		{x:520,y:150,align:"center",color:"#FEFE00",size:45,stroke:"",family:"Calibri","text":"Reel Selections"},
		{x:332,y:305,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x1"},
		{x:558,y:305,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x5"},
		{x:790,y:305,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x10"},
		{x:455,y:430,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x20"},
		{x:673,y:430,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x40"}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:440,y:110,align:"center",color:"#FFFFFF",size:24,stroke:"",family:"Calibri","text":"Spacebar:  Can be used to spin the reels.<br>Settings:  Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help:  View games rules, paytables and paylines.<br><br>EReel Cost:  Use the + and - buttons to select the REEL POWER and the Reel Cost.<br>Bet Per Reel:  Use the + and - buttons to select the amount you wish to stake per reel. <br>Your Total Bet will be calculated as Reel Cost x Bet Per Reel.<br><br>Play:  Confirm your bet and start a new game.<br>Auto:  Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop:  Stop any Autospin whilst in progress. Also stop spinning reels and game animations.<br><br>Results published on cashing out of the game."}
	]
]