/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
/*
language EN
*/
game.language['ok']='OK'; 
game.language['start']='Start'; 
game.language['connecting_to_server']='CONNECTING TO SERVER'; 
game.language['balance']='Balance : '; 
game.language['balanceRefresh']='Refresh Balance'; 
game.language['lines']='LINES';
game.language['betPerLine']='BET PER LINE';
game.language['totalBet']='TOTAL BET';
game.language['win']='WIN';
game.language['lineWin']='Line {line} wins {win}!';
game.language['reelPowerWin']='Symbol {symbol} wins {win}!';
game.language['symbolWin']='Symbol {symbol} wins {win}!';
game.language['gamble']="GAMBLE";
game.language['spin']="PLAY";
game.language['stop']="STOP";
game.language['exit']="EXIT";
game.language['goodLuck']="Good Luck!";
game.language['black']="BLACK";
game.language['red']="RED";
game.language['takeWin']="TAKE WIN";
game.language['go']="GO!";
game.language['restoreMessage']="Note: All game features and bet settings,<br>including bet and lines have<br>been restored from the previous round.";
game.language['freeGame']='Free Game {current} of {total}';
game.language['sound']='SOUND';
game.language['soundLobby']='SOUND LOBBY';


game.language['error_fail_balance']='Not enough balance for the Bet'; 

game.language['txtSpin']='Good luck!';
game.language['txtWin']='won';
game.language['playNow']="Play Now";
/*--------------gamble--------------*/
game.language['full_gamble_selected']="Full Gamble Selected";
game.language['gamble_amount']="Gamble Amount";
game.language['history']="HISTORY";
game.language['suit_gamble']="Suit Gamble";
game.language['red_black_gamble']="Red/Black Gamble";
game.language['to_win']="to win";
/*--------------freeSpin--------------*/
game.language.freeSpin={
	pressStart:"Press START",
	of:"OF",
	freeSpin:"FREE SPIN",
	"start":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!"},
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:30,family:"Arial",stroke:"#000000",text:"You have won {FREE_GAMES} free spins!"}
	], 
	"finish":[ 
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"FEATURE WIN"}, 
		{x:290,y:290,align:"center",color:TEXT_GRADIENT,size:40,family:"Arial",stroke:"#000000",text:"{FATURE_WIN}"} 
	], 
	"processing":[], 
	"add":[
		{x:290,y:210,align:"center",color:TEXT_GRADIENT,size:50,family:"Arial",stroke:"#000000",text:"CONGRATULATIONS!<br>ADD {FREE_GAMES_ADD} FREE GAMES"}
	]   
}
/*----------------------------*/
game.language['payTable']={};
