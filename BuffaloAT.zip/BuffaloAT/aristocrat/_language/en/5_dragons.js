game.language.text=[
	'Welcome 5 Dragons!',
	'3 or more COIN triggers feature',
	'DRAGON is Wild',
];
game.language['betPerLine']='REEL COST';
game.language['lines']='UNIT STAKE';
//game.language.setting['lines']='Extra';
//game.language.setting['line_bet']='Bet';
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:110,y:30,"name":"Game Rules","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:22,stroke:"","family":"Calibri","text":"All wins begin with leftmost reel and pay left to right only on adjacent reels, including Scatters. <br>Choose your number of reels, then choose your bet per reel to begin game.<br>Coinciding wins added. Scatter wins always added.<br><br>Total bet is the number on the bet button multiplied by the amount on the reels button.<br>Highest win paid per winning combination on bought reels. Highest win only on Scatters.<br><br>Scatter wins multiplied by total amount staked.<br>All wins multiplied by the amount bet per reel except Scatters.<br><br>All Reels Played. Ante Bet does not count towards Scatter Win multiplier.  <br>Minimum RTP equals 90.935% or 95.317% when Ante Bet is staked.  <br>Maximum payout is 1250000"}
	],
	[
		{x:275,y:30,"name":"Gamble Option","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:22,stroke:"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br><br><br>EBet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br><br>EBet is QUADRUPLED (x4) if SUIT choice is correct.<br><br><br>Winnings may be gambled up to 5 times.<br>Permitted Gamble Amount calculated as ((Maximum Game Payout - Current Winnings) / 4).<br><br><br>The maxiumum amount is <br><br><br>Any winnings above this threshold are held in GAMBLE RESERVE. <br><br>This is used to top-up the Gamble Amount up to the permitted limit."}
	],
	[
		{x:470,y:30,"name":"Free Spin Feature","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:22,stroke:"","family":"Calibri","text":"Free games are won with any 3 or more scattered COIN symbol, from leftmost reel to right.<br>A second screen will appear displaying all five feature options.<br><br>1) WHITE DRAGON 20 FREE GAMES - All wins with WHITE DRAGON substituting are x2, x3, or x5.<br>2) RED DRAGON 15 FREE GAMES - All wins with RED DRAGON substituting are x3, x5, or x8.<br>3) BLACK DRAGON 10 FREE GAMES - All wins with BLACK DRAGON substituting are x5, x8, or x10.<br>4) BLUE DRAGON 8 FREE GAMES - All wins with BLUE DRAGON substituting are x8, x10, or x15.<br>5) YELLOW DRAGON 5 FREE GAMES - All wins with YELLOW DRAGON substituting are x10, x15, or x30.<br><br>During the free games, RED PACKET symbol anywhere on Reel 1 and 5 result in a bonus prize<br>of 50, 20, 15, 10, 5 or 2.<br>Feature can be won again during the free games.<br>Number of features remaining is represented by the number of MONEY BAG symbol collected.<br>The reels selected and the bet multiplier during the feature are the same as those on the game <br>that started the feature.<br>Return to player for all 5 features is essentially the same."}
	],
	[
		{x:695,y:30,"name":"Pay Table I","background":"paytable_1"}
	],
	[
		{x:855,y:30,"name":"Pay Table II","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:22,stroke:"","family":"Calibri","text":"GREEN DRAGON SYMBOL substitutes for all symbols except scattered COIN SYMBOL.<br>Scatters pay left to right anywhere on adjacent reels.<br><br>Normal Game GREEN DRAGON SYMBOL appears on reels 2, 3, and 4 only.<br>For 5 Dragons Feature Selected WHITE, RED, BLACK, BLUE, or YELLOW DRAGON SYMBOL appear on <br>reels 2, 3 and 4 only.<br><br>WHITE, RED, BLACK, BLUE, YELLOW DRAGON SYMBOL substitute for all symbols except scattered <br>COIN SYMBOL."}
	],
	[
		{x:1020,y:30,"name":"Instructions","background":"more_info"},
		{x:440,y:100,align:"center",color:"#FFFFFF",size:22,stroke:"","family":"Calibri","text":"Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in:Select how much of your existing balance you would like to take into the game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, <br>your total bet will be calculated asCLines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>MISS KITTY  2003 - 2011 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED<br>"}
	]
]