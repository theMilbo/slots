game.language.text=[
	'Welcome to Wild Splash!',
	//'Three FLOWERS triggers feature.',
	//'DIAMOND is Wild',
];
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{"x":0,"y":30,"name":"Pay Table","background":"more_info"},
		{x:25,y:160,width:850,height:261,type:'image',image:'paytable'},
		{"x":350,"y":180,"align":"left","color":"#FFFFFF","size":"20","stroke":"","family":"Calibri",type:'text',"text":"Substitutes for all symbols except Scatters.<br>Appears on reels 2,3,4 and 5 only."},
		{"x":440,"y":420,"align":"center","color":"#FFFFFF","size":"20","stroke":"","family":"Calibri",type:'text',"text":"All wins befin width lefmost reel and pay left to right on adjacent reels, except Scatters.<br>All winns shown with bet multiplied of 1.<br>All wins are paid per lit game. Including Scatters"}
	], 
	[
		{"x":0,"y":30,"name":"Free Spin Feature","background":"more_info"},
		{"x":440,"y":100,"align":"center","color":"#FFFFFF","size":"20","stroke":"","family":"Calibri",type:'text',"text":"5,10 or 25 free games are awarded with 3,4 or 5 scatter win<br><br>Free Games will be played	for the triggered game only.<br><br>Feature reels are in play during features and there are extra WILD on reelsd 2,3,4 and 5<br><br>Feature can be retriggerd during the feature.<br><br>Bet multiplied is the same as the game that triggered the feature. "}
	],
	[
		{"x":0,"y":30,"name":"Pay Lines","background":"more_info"},
		{x:25,y:160,width:850,height:261,type:'image',image:'paytable_1'},
	], 
	[
		{"x":0,"y":30,"name":"Instructions","background":"more_info"},
		{"x":440,"y":100,"align":"center","color":"#FFFFFF","size":"20","stroke":"","family":"Calibri",type:'text',"text":"Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in:Select how much of your existing balance you would like to take into the game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, <br>your total bet will be calculated asCLines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>2003 - 2011 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED<br>"}
	], 
	[
		{"x":0,"y":30,"name":"Gamble Option","background":"more_info"},
		{"x":440,"y":100,"align":"center","color":"#FFFFFF","size":"20","stroke":"","family":"Calibri",type:'text',"text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br><br><br>EBet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br><br>EBet is QUADRUPLED (x4) if SUIT choice is correct.<br><br><br>Winnings may be gambled up to 5 times.<br>Permitted Gamble Amount calculated as ((Maximum Game Payout - Current Winnings) / 4).<br><br><br>The maxiumum amount is <br><br><br>Any winnings above this threshold are held in GAMBLE RESERVE. <br><br>This is used to top-up the Gamble Amount up to the permitted limit."}
	]
]