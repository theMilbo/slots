
game.language['lines']='Reel Cost';
game.language['betPerLine']='Bet';

game.language.text=[
	'Welcome to JAGUAR MIST!',
	'3,4 or 5 Scatters  triggers feature.',
	'ORCHID is Wild',
];

game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Feature","background":"more_info"},
		{x:440,y:110,align:"center",color:"#FFFFFF",size:24,stroke:"",family:"Calibri","text":"JAGUAR MIST Feature - Win 8, 15 or 20 FREE GAMES with any 3, 4 or 5 Scatters (MEDAL)<br>respectively. Your total win for any spin may be multiplied by up to 27.<br><br><br>During the free games each ORCHID that appears anywhere in reels 2, 3 or 4 will multiply<br>the totalwin for that spin by either 2 or 3.<br><br><br>All free games will be played with REEL COST and BET PER REEL<br>the same as that triggering the feature.<br><br><br>The feature can be triggered again during the feature. In addition, 5 EXTRA FREE GAMES are<br>awarded if any 2 Scatters (MEDAL) occur during any free game.<br><br><br>Aristocrat products are protected by patents.<br>Aristocrat Technologies Australia PTY Limited."}
	],
	[
		{x:0,y:30,"name":"Pay Tables","background":"more_info"},
		{x:20,y:75,width:855,height:500,type:'image',image:'paytable_1'},
	],
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:440,y:110,align:"center",color:"#FFFFFF",size:24,stroke:"",family:"Calibri","text":"Scatters (MEDAL) appear on all reels. Wild (ORCHID) <br>substitute all symbols except Scatters (MEDAL).<br><br>All wins pay LEFT to RIGHT except Scatters (MEDAL) which pay ANY.<br>TOTAL BET is the BET PER REEL multiplied by REEL COST.<br>Choose your bet per reel cost.  Choose the reels that you wish to play.<br><br>Only positions containing the winning symbol are used in determining win for that symbol.<br><br>MEDALciding wins are added. Scatter (MEDAL) wins added to REEL POWER wins. <br>Highest win only on Scatters.<br><br>REEL POWER wins multiplied by the number on the BET PER REEL button. <br>Scatter (MEDAL) wins multiplied by the TOTAL BET.<br><br>Malfunction Voids All Pays and Play."}
	],
	[
		{x:0,y:30,"name":"REEL POWER","background":"more_info"},
		{x:20,y:75,width:855,height:500,type:'image',image:'paytable_2'},
		{x:520,y:150,align:"center",color:"#FEFE00",size:45,stroke:"",family:"Calibri","text":"Reel Selections"},
		{x:332,y:305,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x1"},
		{x:558,y:305,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x5"},
		{x:790,y:305,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x10"},
		{x:455,y:450,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x20"},
		{x:673,y:450,align:"center",color:"#FEFE00",size:20,stroke:"",family:"Calibri","text":"Reel cost = x40"}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:440,y:110,align:"center",color:"#FFFFFF",size:24,stroke:"",family:"Calibri","text":"Spacebar:  Can be used to spin the reels.<br>Settings:  Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help:  View games rules, paytables and paylines.<br><br>EReel Cost:  Use the + and - buttons to select the REEL POWER and the Reel Cost.<br>Bet Per Reel:  Use the + and - buttons to select the amount you wish to stake per reel. <br>Your Total Bet will be calculated as Reel Cost x Bet Per Reel.<br><br>Play:  Confirm your bet and start a new game.<br>Auto:  Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop:  Stop any Autospin whilst in progress. Also stop spinning reels and game animations.<br><br>Results published on cashing out of the game."}
	]
]