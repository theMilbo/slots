game.language.text=[
	'Flame Of Olympus!',
	'Scatters is Coin',
	'Wild is doble',
];
game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20",stroke:"","family":"Calibri","text":"Scatters (Coin) appear on all reels.<br>Wild (Adonis) appears on all reels and substitute all symbols except Scatters (Coin).<br><br>All wins pay LEFT to RIGHT except Scatters (Coin) which pay ANY.<br>TOTAL BET is number of LINES multiplied by BET PER LINE.<br>Choose your bet per line cost.  Choose the lines that you wish to play.<br><br>Scatter (Coin) wins added to payline wins.<br>Scatter (Coin) wins are multiplied by the BET PER LINE and the number of lines played.<br>If one or more Wilds (Adonis) substitutes in a win line the win is DOUBLED.<br><br>All wins multiplied by the BET PER LINE except Scatter (Coin).<br>Wins on different lit paylines added.<br>All wins on lines played except Scatters (Coin) which are added to payline wins.<br>Highest win only on each line. Highest win only on Scatters.<br><br>Malfunction voids all pays and plays."}
	],
	[
		{x:0,y:30,"name":"Free Spin Feature","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20",stroke:"","family":"Calibri","text":"15 free games won with 3,4 or 5 Scatters (Coin).<br><br><br>All prizes are tripled during the free games feature.<br><br><br>Feature can be retriggered during free games.<br><br><br>BET PER LINE and lines played are the same as the game that triggered the feature."}
	],
	[
		{x:0,y:30,"name":"Pay Table","background":"paytable"},
		{x:450,y:115,align:"center",color:"#FFFF00",size:"18",stroke:"","family":"Calibri","text":"If one or more ADONIS SYMBOL substitute in a win <br>the pay for that win is doubled. ADONIS SYMBOL <br>substitutes for all symbols except COIN SYMBOL. All<br> wins left to right only except COIN SYMBOL which <br> pay any.<br>"}
	],
	[
		{x:0,y:30,"name":"Pay Lines","background":"paytable_1"}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:450,y:100,align:"center",color:"#FFFFFF",size:"20",stroke:"","family":"Calibri","text":"Spacebar: Can be used to spin the reels.<br>Rules: View game rules, paytables and paylines.<br>Lines: Use the + and - buttons to select the number of lines you wish to bet on.<br>Bet Per Line: Use the + and - buttons to select the amount you wish to bet per line, your TOTAL BET <br>will be calculated as LINES bet multiplied by the BET PER LINE.<br>Max Bet: Selects the maximum number of lines and the maximum bet per line that the balance can <br>cover.<br><br>Spin: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress. Also stop spinning reels and game animations.<br><br>Aristocrat products are protected by patents.<br>For a full list of aristocrat patents, please check with your local patent office.<br>FLAME OF OLYMPUS Aristocrat Technologies Australia PTY Limited<br><br>1.2-MainGame9-25-1"}
	]
]