game.language.text=[
	'Welcome to LUCKY 88!',
	'Three or more LAMP triggers feature.',
	'MAN is Wild',
];
game.language['button_extra_text']='PLAY<br><br>EXTRA CHOICE';

game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:40,"name":"Info","background":"more_info"},
		{x:20,y:75,width:855,height:450,type:'image',image:'paytable'},
	],
	[
		{x:0,y:40,"name":"Pay Table","background":"more_info"},
		{x:20,y:75,width:855,height:450,type:'image',image:'paytable_1'},
	],
	[
		{x:0,y:40,"name":"Feature 'EXTRA'","background":"more_info"},
		{x:460,y:100,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"FREE GAMES FEATURE with 'EXTRA CHOICE'"},
		{x:50,y:150,align:"left",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"3 or more scattered LAMP triggers the Free Games feature.<br>You must play maximum lines + EXTRA CHOICE to be eligible for these features.<br>The bet for Extra Choice is (5 coins + the number of lines played) multiplied by the bet per line.<br>Choose your Free Games Feature or Roll your Lucky Dice<br>25 FREE GAMES - If one or more WILD substitutes in a win the pay for that win is multiplied by 5 or 18<br>15 FREE GAMES - If one or more WILD substitutes in a win the pay for that win is multiplied by 8 or 38<br>8 FREE GAMES - If one or more WILD substitutes in a win the pay for that win is multiplied by 18 or 88<br>4 FREE GAMES - If one or more WILD substitutes in a win the pay for that win is multiplied by 88<br>Feature can also be triggered randomly at the end of any spin<br>Feature can be triggered again during the free games.<br>The number of features remaining is indicated by the number next to re-trigger icon"}
	],
	[
		{x:0,y:40,"name":"Dice Feature","background":"more_info"},
		{x:460,y:100,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"DICE FEATURE playing 'EXTRA CHOICE'"},
		{x:50,y:150,align:"left",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"3 dice games are awarded.<br>Each dice game starts with the 8 outer dice being rolled.<br>If one or more `8` is rolled then all the `8`'s are held and the remaining outer dice are rolled again.<br>This continues until no more `8`'s are rolled or 8 `8`'s appear.<br>Prizes are multiplied by the bet per line on the game that triggered the feature as shown on the screen.<br>At the completion of any 3 dice games the middle die is rolled and if `3 more games` is rolled another<br> 3 dice games are played.<br>"},
	],
	[
		{x:0,y:40,"name":"Feature","background":"more_info"},
		{x:460,y:100,align:"center",color:"#FFFFFF",size:25,"stroke":"","family":"Calibri","text":"FREE GAMES FEATURE - not playing 'EXTRA CHOICE'"},
		{x:50,y:150,align:"left",color:"#FFFFFF",size:20,"stroke":"","family":"Calibri","text":"Feature is triggered with 3 or more scattered LAMP<br>Feature can also be triggered randomly at the end of any spin<br>Choose your feature by selecting the corresponding scroll:<br>20 FREE GAMES - If one or more WILD substitutes in a win the pay for that win is multiplied by 5 or 18<br>10 FREE GAMES - If one or more WILD substitutes in a win the pay for that win is multiplied by 8 or 38<br>3 FREE GAMES - If one or more WILD substitutes in a win the pay for that win is multiplied by 18 or 88<br>Feature can be triggered again during the free games<br>The number of features remaining is indicated by the number next to re-trigger icon"}
	],
	
	[
		{x:0,y:40,"name":"Pay Lines","background":"more_info"},
		{x:40,y:100,width:800,height:450,type:'image',image:'paytable_2'},
	],
	[
		{x:0,y:40,"name":"Gamble Option","background":"more_info"},
		{x:460,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"To gamble any win press GAMBLE then select RED/BLACK or a SUIT.<br><br><br>Bet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br><br>EBet is QUADRUPLED (x4) if SUIT choice is correct.<br><br><br>Winnings may be gambled up to 5 times.<br>Permitted Gamble Amount calculated as ((Maximum Game Payout - Current Winnings) / 4).<br><br><br>The maxiumum amount is 31250.00<br><br><br>Any winnings above this threshold are held in GAMBLE RESERVE. <br><br>This is used to top-up the Gamble Amount up to the permitted limit."}
	],
	[
		{x:0,y:40,"name":"Instructions","background":"more_info"},
		{x:460,y:100,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in:Select how much of your existing balance you would like to take into the game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, <br>your total bet will be calculated asCLines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>MISS KITTY  2003 - 2011 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED<br>"}
	]
]