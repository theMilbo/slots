game.language.text=[
	'Welcome to Lucky Count!',
	'Three CASTLE triggers feature.',
	'BAT is Wild',
];

game.language['payTable']={};
game.language['payTable']['pages']=[
	[
		{x:0,y:30,"name":"Feature","background":"more_info"},
		{x:450,y:80,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Free Games Feature with Triple Repeat Pay.<br><br>Win 15,25 or 40 free games with any 3,4 or 5 scattered CASTLE respectively.<br>Feature can be triggered again during the feature.<br><br>Wins repeated up to 15 times.<br><br>Whenever a VAMPIRE appears, total win is 3x line win for each VAMPIRE or BAT in view."}
	],
	[
		{x:0,y:30,"name":"Pay Table","background":"paytable"},
		{x:450,y:145,align:"center",color:"#FFFFFF",size:"15","stroke":"","family":"Calibri","text":"Whenever a VAMPIRE appears, all wins are repeated by the number<br>of VAMPIRE and BAT in the window.<br><br><br>VAMPIRE and BAT are WILDS and substitute for all symbols except scatters.<br>BAT does not substitute for VAMPIRE to trigger a repeat pay.<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>All wins left to right only except scatter which pay any. All wins are multiplied by BET PER LINE<br>"},
		{x:430,y:555,align:"center",color:"#FFFFFF",size:"16","stroke":"","family":"Calibri","text":"All wins shown multiplied by the number on the BET PER LINE button except Scatters. Scatter <br>wins shown multiplied by the number on the bet per line button and the number of lines played."},
	],
	[
		{x:0,y:30,"name":"Game Rules","background":"more_info"},
		{x:450,y:80,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Choose your bet per line. Choose your number of lines.<br><br>All wins on lit lines only except Scatters.<br>All wins begin with leftmost reel and pay left to right on adjacent reels, except Scatters.<br>Wins on different lines are added.<br><br>Highest win only on each line. Highest WILD win pays only.<br>Scatter wins are added to the win lines.<br>Lines win multiplied by credits bet per line.<br>Scatter wins are multiplied by the total credits bet.<br>Whenever a VAMPIRE appears, all wins repeated for each VAMPIRE and BAT in the window.<br><br>If the game window is closed during FEATURE when real money is in play the game state will be<br>stored and may be resumed at later date for a period fo 90 days. Funds attached to games<br>which remain incomplete after 90 days will be void for the player and donated to charity.<br><br>This game has a return to player of 94.98%.<br>Malfunction voids all pays and plays."}
	],
	[
		{x:0,y:30,"name":"Pay Lines","background":"paytable_1"}
	],
	[
		{x:0,y:30,"name":"Gamble Option","background":"more_info"},
		{x:450,y:80,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"To gamble a win press GAMBLE then select RED/BLACK or a SUIT.<br><br>Bet is DOUBLED (x2) if RED/BLACK choice is correct.<br><br>Bet is QUADRUPLED (x4) if SUIT choice is correct.<br><br>Winnings may be gambled up to 5 times.<br><br>Permitted Gamble Amount calculated as ((Max Win per Spin)- Current WinningsF)/3).<br>The maximum amount is u040437550.00.<br><br>Any winnings above this threshold are held in GAMBLE RESERVE. This is used to top-up the <br>Gamble Amount up to the permitted limit.<br>"}
	],
	[
		{x:0,y:30,"name":"Instructions","background":"more_info"},
		{x:450,y:80,align:"center",color:"#FFFFFF",size:"20","stroke":"","family":"Calibri","text":"Spacebar: Can be used to spin the reels.<br><br>Settings: Enable / disable sounds effects, ambient sound and the spacebar spin button.<br>Help: View games rules, paytables and paylines.<br>Buy-in: Select how much of your existing balance you would like to take into the  game.<br>Cash out: Cash your balance back to your main gaming account and close the game window.<br><br>Lines: Use the + and - buttons to select the number of lines you wish to bet on<br>Bet Per Line: Use the + and - buttons to select the amount you wish to stake per line, your totsl <br>bet will be calculated as Lines bet x Bet per line.<br>Gamble: Select the gamble feature when activated for your chance to gamble your return.<br><br>Play: Confirm your bet and start a new game.<br>Auto: Use the + and - buttons to select the number of times you wish to Autospin.<br>Stop: Stop any Autospin whilst in progress. Also stop spinning reels and game animations.<br><br>Game history and results published on cashing out of the game.<br><br>Aristocrat products are protected by patents.<br>LUCKY COUNT 2014 ARISTOCRAT TECHNOLOGIES AUSTRALIA PTY LIMITED.<br> "}
	]
]
	